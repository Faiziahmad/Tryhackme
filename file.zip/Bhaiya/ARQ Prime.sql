use OnlineEngine
SELECT top 1000 * FROM [OnlineEngine_Team]. [dbo].[UP_ARQPrime_Subscription] where party_code='S'


----select * from  [OnlineEngine].[dbo].[AJ_OffersCardClick_updated] where clicked_on like '%ARQ%' and convert(date,left(ts,8),106) >= '2021-01-01'
----select * from [OnlineEngine].[dbo].[AJ_Offers_Metadata] where offer_name like '%ARQ%'

drop table #AJ_OffersClick
Select * Into #AJ_OffersClick from
(Select Distinct Clicked_on,profile_identity,ts,convert(date,left(ts,8),106) as Click_Date,
convert(datetime,stuff(stuff(stuff(ts, 9, 0, ' '), 12, 0, ':'), 15, 0, ':')) as Click_DateTime From [OnlineEngine].[dbo].[AJ_OffersCardClick_updated]
where convert(date,left(ts,8),106) >= '2021-01-01'
and convert(date,left(ts,8),106) <= '2021-03-02'
and Clicked_on like 'Special ARQ Prime Offer Yearly Plan @Rs 99 only Renew Now'
)ab

---select * from #AJ_OffersClick

Select distinct Party_Code,SubscriptionDate,SubscriptionPlan
--into #tempARQRenewal
from  [OnlineEngine_Team]. [dbo].[UP_ARQPrime_Subscription] A,#AJ_OffersClick B
where A.Party_Code = B.profile_identity
and A.SubscriptionDate = B.Click_date




----select * from [Communication]. [dbo]. [UP_Expired_ARQPrime]
