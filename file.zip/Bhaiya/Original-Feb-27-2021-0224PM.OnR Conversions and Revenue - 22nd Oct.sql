-------drop table
drop table #AJ_OffersClick
drop table #AJ_Metadata
drop table #AM_Click
drop table #AM_Click_Unique
Drop table #B2CCampaign_Revenue
Drop table #FNO_B2CCampaign_Revenue
Drop table #B2BCampaign_UC
Drop table #FNO_B2BCampaign_UC
Drop table #B2CCampaign_UC
Drop table #Curr_B2CCampaign
Drop table #Curr_B2CCampaign_UC
Drop table #Curr_B2CCampaign_Revenue
Drop table #FNO_B2CCampaign_UC
Drop table #B2BCampaign_Revenue
Drop table #FNO_B2BCampaign_Revenue
Drop table #B2C_CommCampaign_UC
Drop table #B2C_CommCampaign_Revenue
Drop table #B2B_CommCampaign_UC
Drop table #B2B_CommCampaign_Revenue
Drop table #AM_Campaign_UC
Drop table #AM_Campaign_Revenue
Drop table #merdge_RG_CampaignSet
Drop table #AM_Click
Drop table #AM_Click_Unique
Drop table #B2CCampaign
Drop table #FNO_B2CCampaign
Drop table #B2BCampaign
Drop table #FNO_B2BCampaign
Drop table #B2C_CommCampaign
Drop table #B2B_CommCampaign
Drop table #MTFCampaign_Revenue
Drop table #MTFCampaign_UC
Drop table #MTFCampaign
Drop table #Final_MTF_Clicks
Drop table #DayDiffTable
Drop table #AM_MTF_Clicks

Use Communication
Select * Into #AJ_OffersClick
From
(Select Distinct Clicked_on,profile_identity,ts,convert(date,left(ts,8),106) as Click_Date,
convert(datetime,stuff(stuff(stuff(ts, 9, 0, ' '), 12, 0, ':'), 15, 0, ':')) as Click_DateTime From [OnlineEngine].[dbo].[AJ_OffersCardClick_updated]
Where profile_identity is not NULL
and Clicked_on not like 'test%'
and convert(date,left(ts,8),106) > '2021-02-01'	
--and convert(date,left(ts,8),106) <= '2021-02-15'
)a

-----drop table #AJ_OffersClick
-----drop table AM_Metadata
----select * from [OnlineEngine].[dbo].[AJ_OffersCardClick_updated] where convert(date,left(ts,8),106) = '2020-10-13' and event_props_code IS NULL
----select * from #AJ_OffersClick
------select * from [OnlineEngine].[dbo].[AJ_OffersCardClick] where convert(date,left(ts,8),106) = '2020-10-13'
------select * from [OnlineEngine].[dbo].[AJ_OffersCardClick] where Clicked_on like 'Offer for You Zero Brokerage in FnO On 5 Trades'
Select offer_name ,Concat(offer_message_what,' ',offer_message_howmuch,' ',offer_message_action) as merdge,created_by Into #AJ_Metadata
From [OnlineEngine].[dbo].[AJ_Offers_Metadata]
------Select * from #AJ_Metadata
------select * from [OnlineEngine].[dbo].[AJ_Offers_Metadata]
------select * from OnlineEngine.dbo.AJ_Offers_Metadata where created_by like '%ushma%'
----drop table #AJ_Metadata

----drop table #AM_Click
select * into #AM_Click 
from (select * from #AJ_OffersClick
left join #AJ_Metadata 
on clicked_on like merdge + '%' ) abc

---select * from #AM_Click
----drop table #AM_Click_Unique
Select * into #AM_Click_Unique from
	(
		Select Distinct profile_identity,Clicked_on,Created_by as Owner_Name,min (Click_Date)MinClick_Date,min (Click_DateTime)MinClick_DateTime   -------issue
		from #AM_Click
		group by profile_identity,Clicked_on,Created_by
	)C
----select * from #AM_Click_Unique where profile_identity='JOD21368'
-----------------------------------------------B2C Campaign (Suman Nayak) ------------------------------------
Select profile_identity as Party_code, Clicked_on,Min(B.sauda_date) as minsaudadate,minclick_date,minclick_datetime,'B2C_Campaign' [Type]
	Into #B2CCampaign from  #AM_Click_Unique A
	 left outer join OnlineEngine.dbo.AS_OrderCountData B (nolock)
	 on A.profile_identity = B.Party_code
			Where Owner_Name in ('Suman','Suman Nayak','Anshul')
			and Clicked_on not like '%MTF%'
			and Clicked_on not like '%COMM%' 
			and Clicked_on not like '%Currency%'
			and Clicked_on not like '%prepaid%' 
			and Clicked_on not like '%FnO%'      
			and convert(date,MinClick_DateTime,106) <= sauda_date
			and Datediff(day,MinClick_DateTime,B.sauda_Date) < 2
			and Datediff(day,MinClick_DateTime,B.sauda_Date) >= 0
Group by A.profile_identity, Clicked_on,minclick_date,minclick_datetime
---select top 100 * from OnlineEngine.dbo.AS_OrderCountData order by sauda_date desc
----select * from #B2CCampaign
------Drop table #B2CCampaign_UC-----
Select party_code, minsaudadate,minclick_date,minclick_datetime,Clicked_on,UC,[Type],owner_name Into #B2CCampaign_UC 
	From
	(
	Select distinct Party_code,minsaudadate,minclick_date,minclick_datetime,Clicked_on,Count(Distinct Party_code) UC,[Type],'Suman Nayak' owner_name From #B2CCampaign  
	Group by Party_code,minsaudadate,minclick_date,minclick_datetime,Clicked_on,[Type]
	)b2C_Client
--Group by Party_code, minsaudadate,minclick_date,minclick_datetime,Clicked_on,UC,[Type],owner_name
-------select * from #B2CCampaign_UC ----1766 clients
---Drop table #B2CCampaign_Revenue
/*Select Sauda_Date,Clicked_on,sum(clientcount) as clientcount,sum(Revenues) as Revenues,[Type]
	Into #B2CCampaign_Revenue
	From
	(
		Select Sauda_Date,Clicked_on, count(distinct(A.Party_code)) as clientcount,sum(brokerage) as Revenues, [Type]
		from #B2CCampaign A, onlineengine.dbo.AS_OrderCountData  B (nolock)
		where A.Party_code = B.Party_code
		and A.minsaudadate <= B.sauda_date
		group by Sauda_Date, Clicked_on,[Type]
	)B2C_revenue
group by Sauda_Date, Clicked_on,[Type] */
-----select * from #B2CCampaign_Revenue order by sauda_date

-----------------------------------------------B2C Campaign (Akhilesh Sharma -FNO) ------------------------------------
Select profile_identity as Party_code, Clicked_on,Min(B.sauda_date) as minsaudadate,minclick_date,minclick_datetime,'FNO_B2C_Campaign' [Type]
	Into #FNO_B2CCampaign from  #AM_Click_Unique A
	 left outer join OnlineEngine.dbo.AS_OrderCountData B (nolock)
	 on A.profile_identity = B.Party_code
			Where Owner_Name in ('Divya','Akhilesh Sharma','Akhilesh')
			And INST_Type in ('FUTIDX', 'FUTSTK', 'OPTIDX', 'OPTSTK')
			and Clicked_on not like '%COMM%' 
			and Clicked_on not like '%Currency%'
			and Clicked_on not like '%prepaid%'            
			and convert(date,MinClick_DateTime,106) <= sauda_date
			and Datediff(day,MinClick_DateTime,B.sauda_Date) < 2
			and Datediff(day,MinClick_DateTime,B.sauda_Date) >= 0
Group by A.profile_identity, Clicked_on,minclick_date,minclick_datetime
---select top 100 * from OnlineEngine.dbo.AS_OrderCountData order by sauda_date desc
----select * from #FNO_B2CCampaign
---Drop table #FNO_B2CCampaign_UC
--------Select minsaudadate,Clicked_on,UC,[Type] Into #B2CCampaign_UC 
Select Party_code,minsaudadate,minclick_date,minclick_datetime,Clicked_on,UC,[Type],owner_name Into #FNO_B2CCampaign_UC
	From
	(
	Select distinct party_code,minsaudadate,minclick_date,minclick_datetime,Clicked_on,Count(Distinct Party_code) UC,[Type],'Akhilesh Sharma' owner_name From #FNO_B2CCampaign
	Group by party_code,minsaudadate,minclick_date,minclick_datetime,Clicked_on,[Type]
	)FNO_B2C_Client
--Group by party_code,minsaudadate,minclick_date,minclick_datetime,Clicked_on,UC,[Type],owner_name
---Drop table #FNO_B2CCampaign_Revenue
/*Select Sauda_Date,Clicked_on,sum(clientcount) as clientcount,sum(Revenues) as Revenues,[Type]
	Into #FNO_B2CCampaign_Revenue
	From
	(
		Select Sauda_Date,Clicked_on, count(distinct(A.Party_code)) as clientcount,sum(brokerage) as Revenues, [Type]
		from #FNO_B2CCampaign A, onlineengine.dbo.AS_OrderCountData  B (nolock)
		where A.Party_code = B.Party_code
		And INST_Type in ('FUTIDX', 'FUTSTK', 'OPTIDX', 'OPTSTK')
		and A.minsaudadate <= B.sauda_date
		group by Sauda_Date, Clicked_on,[Type]
	)FNO_B2C_revenue
group by Sauda_Date, Clicked_on,[Type]
*/
-----select * from #FNO_B2CCampaign_Revenue


-----------------------------------------------B2C Campaign (Akhilesh Sharma -Currency) ------------------------------------
Select profile_identity as Party_code, Clicked_on,Min(B.sauda_date) as minsaudadate,minclick_date,minclick_datetime,'Curr_B2C_Campaign' [Type]
	Into #Curr_B2CCampaign from  #AM_Click_Unique A
	 left outer join OnlineEngine.dbo.AS_OrderCountData B (nolock)
	 on A.profile_identity = B.Party_code
			Where Owner_Name in ('Divya','Akhilesh Sharma','Akhilesh')
			And INST_Type in ('Currency')
			and Clicked_on not like '%COMM%'
			and Clicked_on not like '%FnO%' 
			and Clicked_on not like '%prepaid%'       
			and convert(date,MinClick_DateTime,106) <= sauda_date
			and Datediff(day,MinClick_DateTime,B.sauda_Date) < 2
			and Datediff(day,MinClick_DateTime,B.sauda_Date) >= 0
Group by A.profile_identity, Clicked_on,minclick_date,minclick_datetime
---select top 100 * from OnlineEngine.dbo.AS_OrderCountData order by sauda_date desc
----select * from #FNO_B2CCampaign
---Drop table #Curr_B2CCampaign_UC
--------Select minsaudadate,Clicked_on,UC,[Type] Into #B2CCampaign_UC 
Select party_code,minsaudadate,minclick_date,minclick_datetime,Clicked_on,UC,[Type],owner_name Into #Curr_B2CCampaign_UC
	From
	(
	Select distinct party_code,minsaudadate,minclick_date,minclick_datetime,Clicked_on,Count(Distinct Party_code) UC,[Type],'Akhilesh Sharma' owner_name From #Curr_B2CCampaign
	Group by party_code,minsaudadate,minclick_date,minclick_datetime,Clicked_on,[Type]
	)Curr_B2C_Client
--Group by party_code,minsaudadate,minclick_date,minclick_datetime,Clicked_on,UC,[Type],owner_name
---Drop table #Curr_B2CCampaign_Revenue
/*Select Sauda_Date,Clicked_on,sum(clientcount) as clientcount,sum(Revenues) as Revenues,[Type]
	Into #Curr_B2CCampaign_Revenue
	From
	(
		Select Sauda_Date,Clicked_on, count(distinct(A.Party_code)) as clientcount,sum(brokerage) as Revenues, [Type]
		from #Curr_B2CCampaign A, onlineengine.dbo.AS_OrderCountData  B (nolock)
		where A.Party_code = B.Party_code
		And INST_Type in ('Currency')
		and A.minsaudadate <= B.sauda_date
		group by Sauda_Date, Clicked_on,[Type]
	)Curr_B2C_revenue
group by Sauda_Date, Clicked_on,[Type]  */
-----select * from #Curr_B2CCampaign_Revenue
-----------------------------------------------B2B Campaign ------------------------------------
Select profile_identity as Party_code, Clicked_on,Min(B.sauda_date) as minsaudadate,minclick_date,minclick_datetime,'B2B_Campaign' [Type]
	Into #B2BCampaign from  #AM_Click_Unique A
	 left outer join OnlineEngine.dbo.UP_B2B_OrderCountData B (nolock)
	 on A.profile_identity = B.Party_code
			Where Owner_Name in ('Ushma Parikh','Ushma')
			and Clicked_on not like '%COMM%'
			and Clicked_on not like '%F&O%'
			and Clicked_on not like '%Currency%'
			and Clicked_on not like '%ARQ%'
			and convert(date,MinClick_DateTime,106) <= sauda_date
			and Datediff(day,MinClick_DateTime,B.sauda_Date) < 2
			and Datediff(day,MinClick_DateTime,B.sauda_Date) >= 0
Group by A.profile_identity, Clicked_on,minclick_date,minclick_datetime
---Drop table #B2BCampaign_UC

Select party_code,minsaudadate,minclick_date,minclick_datetime,Clicked_on,UC,[Type],owner_name Into #B2BCampaign_UC
	From
	(
	Select distinct party_code, minsaudadate,minclick_date,minclick_datetime,Clicked_on,Count(Distinct Party_code) as UC,[Type],'Ushma Parikh' owner_name From #B2BCampaign
	Group by party_code, minsaudadate,minclick_date,minclick_datetime,Clicked_on,[Type]
	)B2B_Client
--Group by party_code,minsaudadate,minclick_date,minclick_datetime,Clicked_on,UC,[Type],owner_name
---Drop table #B2BCampaign_Revenue
/*Select Sauda_Date,Clicked_on,sum(clientcount) as clientcount,sum(Revenues) as Revenues,[Type]
	Into #B2BCampaign_Revenue
	From
	(
		Select Sauda_Date,Clicked_on, count(distinct(A.Party_code)) as clientcount,sum(brokerage) as Revenues, [Type]
		from #B2BCampaign A, onlineengine.dbo.UP_B2B_OrderCountData  B (nolock)
		where A.Party_code = B.Party_code
		and A.minsaudadate <= B.sauda_date
		group by Sauda_Date, Clicked_on,[Type]
	)B2B_revenue
group by Sauda_Date, Clicked_on,[Type] */
​
-----------------------------------------------FNO_B2B FNO Campaign ------------------------------------
Select profile_identity as Party_code, Clicked_on,Min(B.sauda_date) as minsaudadate,minclick_date,minclick_datetime,'FNO_B2B_Campaign' [Type]
	Into #FNO_B2BCampaign from  #AM_Click_Unique A
	 left outer join OnlineEngine.dbo.UP_B2B_OrderCountData B (nolock)
	 on A.profile_identity = B.Party_code
			Where Owner_Name in ('Ushma Parikh','Ushma')
			and Clicked_on like '%F&O%'
			and Clicked_on not like '%ARQ%'
			And INST_Type in ('FUTIDX', 'FUTSTK', 'OPTIDX', 'OPTSTK')
			and convert(date,MinClick_DateTime,106) <= sauda_date
			and Datediff(day,MinClick_DateTime,B.sauda_Date) < 2
			and Datediff(day,MinClick_DateTime,B.sauda_Date) >= 0
Group by A.profile_identity, Clicked_on,minclick_date,minclick_datetime
---Drop table #FNO_B2BCampaign_UC
Select party_code,minsaudadate,minclick_date,minclick_datetime,Clicked_on,UC,[Type],owner_name Into #FNO_B2BCampaign_UC
	From
	(
	Select distinct party_code,minsaudadate,minclick_date,minclick_datetime,Clicked_on,Count(Distinct Party_code) UC,[Type],'Ushma Parikh' owner_name From #FNO_B2BCampaign
	Group by party_code,minsaudadate,minclick_date,minclick_datetime,Clicked_on,[Type]
	)FNO_B2B_Client
--Group by party_code,minsaudadate,minclick_date,minclick_datetime,Clicked_on,UC,[Type],owner_name
---Drop table #FNO_B2BCampaign_Revenue
/*Select Sauda_Date,Clicked_on,sum(clientcount) as clientcount,sum(Revenues) as Revenues,[Type]
	Into #FNO_B2BCampaign_Revenue
	From
	(
		Select Sauda_Date,Clicked_on, count(distinct(A.Party_code)) as clientcount,sum(brokerage) as Revenues, [Type]
		from #FNO_B2BCampaign A, onlineengine.dbo.UP_B2B_OrderCountData  B (nolock)
		where A.Party_code = B.Party_code
		And INST_Type in ('FUTIDX', 'FUTSTK', 'OPTIDX', 'OPTSTK')
		and A.minsaudadate <= B.sauda_date
		group by Sauda_Date, Clicked_on,[Type]
	)FNO_B2B_revenue
group by Sauda_Date, Clicked_on,[Type] */
-----------------------------------------------B2C_Commodity Campaign ------------------------------------
Select profile_identity as Party_code, Clicked_on,Min(B.sauda_date) as minsaudadate,minclick_date,minclick_datetime,'B2C_Comm_Campaign' [Type]
	Into #B2C_CommCampaign from  #AM_Click_Unique A
	 left outer join OnlineEngine.dbo.AS_OrderCountData B (nolock)
	 on A.profile_identity = B.Party_code
			Where Owner_Name in ('Divya','Akhilesh Sharma','Akhilesh')
			and Clicked_on like '%COMM%'
			And INST_Type = 'COMM'
			and convert(date,MinClick_DateTime,106) <= sauda_date
			and Datediff(day,MinClick_DateTime,B.sauda_Date) < 2
			and Datediff(day,MinClick_DateTime,B.sauda_Date) >= 0
Group by A.profile_identity, Clicked_on,minclick_date,minclick_datetime
---Drop table #B2C_CommCampaign_UC
Select party_code,minsaudadate,minclick_date,minclick_datetime,Clicked_on,UC,[Type],owner_name Into #B2C_CommCampaign_UC 
	From
	(
	Select distinct party_code,minsaudadate,minclick_date,minclick_datetime,Clicked_on,Count(Distinct Party_code) UC,[Type],'Akhilesh Sharma' owner_name From #B2C_CommCampaign
	Group by party_code,minsaudadate,minclick_date,minclick_datetime,Clicked_on,[Type]
	)B2C_Comm_Client
--Group by party_code,minsaudadate,minclick_date,minclick_datetime,Clicked_on,UC, [Type],owner_name
---Drop table #B2C_CommCampaign_Revenue
/*Select Sauda_Date,Clicked_on,sum(clientcount) as clientcount,sum(Revenues) as Revenues,[Type]
	Into #B2C_CommCampaign_Revenue
	From
	(
		Select Sauda_Date,Clicked_on, count(distinct(A.Party_code)) as clientcount,sum(brokerage) as Revenues, [Type]
		from #B2C_CommCampaign A, onlineengine.dbo.AS_OrderCountData  B (nolock)
		where A.Party_code = B.Party_code
		and A.minsaudadate <= B.sauda_date
		And INST_Type = 'COMM'
		group by Sauda_Date, Clicked_on,[Type]
	)B2C_Comm_revenue
group by Sauda_Date, Clicked_on,[Type] */
-----------------------------------------------B2B_Commodity Campaign ------------------------------------
Select profile_identity as Party_code, Clicked_on,Min(B.sauda_date) as minsaudadate,minclick_date,minclick_datetime,'B2B_Comm_Campaign' [Type]
	Into #B2B_CommCampaign from  #AM_Click_Unique A
	 left outer join OnlineEngine.dbo.UP_B2B_OrderCountData B (nolock)
	 on A.profile_identity = B.Party_code
			Where Owner_Name in ('Ushma Parikh','Ushma')
			and Clicked_on like '%COMM%'
			And INST_Type = 'COMM'
			and convert(date,MinClick_DateTime,106) <= sauda_date
			and Datediff(day,MinClick_DateTime,B.sauda_Date) < 2
			and Datediff(day,MinClick_DateTime,B.sauda_Date) >= 0
Group by A.profile_identity, Clicked_on,minclick_date,minclick_datetime
---Drop table #B2B_CommCampaign_UC
Select party_code,minsaudadate,minclick_date,minclick_datetime,Clicked_on, UC,[Type],owner_name Into #B2B_CommCampaign_UC -------ushma calculates at 100 %
	From
	(
	Select distinct party_code,minsaudadate,minclick_date,minclick_datetime,Clicked_on,Count(Distinct Party_code) UC,[Type],'Ushma Parikh'owner_name From #B2B_CommCampaign
	Group by party_code,minsaudadate,minclick_date,minclick_datetime,Clicked_on,[Type]
	)B2B_Comm_Client
/*Group by party_code,minsaudadate,minclick_date,minclick_datetime,Clicked_on,UC,[Type],owner_name
---Drop table #B2B_CommCampaign_Revenue
Select Sauda_Date,Clicked_on,sum(clientcount) as clientcount,sum(Revenues) as Revenues,[Type]
	Into #B2B_CommCampaign_Revenue
	From
	(
		Select Sauda_Date,Clicked_on, count(distinct(A.Party_code)) as clientcount,sum(brokerage) as Revenues, [Type]
		from #B2B_CommCampaign A, onlineengine.dbo.UP_B2B_OrderCountData  B (nolock)
		where A.Party_code = B.Party_code
		and A.minsaudadate <= B.sauda_date
		And INST_Type = 'COMM'
		group by Sauda_Date, Clicked_on,[Type]
	)B2B_Comm_revenue
group by Sauda_Date, Clicked_on,[Type] */


-------------------------------------------------------------------------------------------
---------------------------------Union all-------------------------------------------------
-------------------------------------------------------------------------------------------
Select * Into #AM_Campaign_UC
From
(	Select * From #B2CCampaign_UC
	Union All
	--Select * From #MTFCampaign_UC
	--Union All
	Select * From #FNO_B2CCampaign_UC
	Union All
	Select * From #B2BCampaign_UC
	Union All
	select * from #Curr_B2CCampaign_UC
	Union All
	Select * From #FNO_B2BCampaign_UC
	Union All
	Select * From #B2C_CommCampaign_UC
	Union All
	Select * From #B2B_CommCampaign_UC
)AMUC
​
Select * Into #AM_Campaign_Revenue
From
(	Select * From #B2CCampaign_Revenue
	Union All
	--Select * From #MTFCampaign_Revenue
	--Union All
	Select * From #FNO_B2CCampaign_Revenue
	Union All
	select * from #Curr_B2CCampaign_Revenue
	Union All
	Select * From #B2BCampaign_Revenue
	Union All
	Select * From #FNO_B2BCampaign_Revenue
	Union All
	Select * From #B2C_CommCampaign_Revenue
	Union All
	Select * From #B2B_CommCampaign_Revenue
)AMRevenue
---------------------------------Final UC & Revenue -----------------------------
Select distinct * From #AM_Campaign_UC Order by minsaudadate 

select * from AM_OnR_Conversions order by minclick_date desc

Insert into AM_OnR_Conversions 
Select distinct * From #AM_Campaign_UC



---------------------------------Drop tables -----------------------------
Drop table #B2CCampaign_Revenue
Drop table #FNO_B2CCampaign_Revenue
Drop table #B2BCampaign_UC
Drop table #FNO_B2BCampaign_UC
Drop table #B2CCampaign_UC
Drop table #Curr_B2CCampaign
Drop table #Curr_B2CCampaign_UC
Drop table #Curr_B2CCampaign_Revenue
Drop table #FNO_B2CCampaign_UC
Drop table #B2BCampaign_Revenue
Drop table #FNO_B2BCampaign_Revenue
Drop table #B2C_CommCampaign_UC
Drop table #B2C_CommCampaign_Revenue
Drop table #B2B_CommCampaign_UC
Drop table #B2B_CommCampaign_Revenue
Drop table #AM_Campaign_UC
Drop table #AM_Campaign_Revenue
Drop table #merdge_RG_CampaignSet
Drop table #AM_Click
Drop table #AM_Click_Unique
Drop table #B2CCampaign
Drop table #FNO_B2CCampaign
Drop table #B2BCampaign
Drop table #FNO_B2BCampaign
Drop table #B2C_CommCampaign
Drop table #B2B_CommCampaign
Drop table #MTFCampaign_Revenue
Drop table #MTFCampaign_UC
Drop table #MTFCampaign
Drop table #Final_MTF_Clicks
Drop table #DayDiffTable
Drop table #AM_MTF_Clicks


----------------------------Revenue Calculations------------------
--select * from AM_OnR_Conversions order by minclick_date desc
------select distinct INST_Type from OnlineEngine.dbo.AS_OrderCountData
---select top 100 * from OnlineEngine.dbo.AS_OrderCountData order by sauda_date desc (with no lock)


-------Recheck Revenue for a selected party_code---------
Select * from OnlineEngine.dbo.AS_OrderCountData
where party_code ='C45398' and sauda_date >= '2020-07-23' and INST_Type like '%comm%'

---------------------------------------------PER TRANSACTION BROKERAGE-------------------
---------------------------B2C Campaign Revenue-----------------
Select party_code,minclick_date,sauda_date,Clicked_on,[Type],owner_Name,OC,Revenue into #AM_B2C_Revenue
from
(Select C.party_code,C.minclick_date,C.minsaudadate,C.Clicked_on,C.[Type],C.owner_Name,O.sauda_date,o.OC, o.Brokerage as Revenue
from AM_OnR_Conversions_Unique C, OnlineEngine.dbo.AS_OrderCountData O
where C.party_code = O.party_code
and C.[Type] = 'B2C_Campaign'
and C.minsaudadate <= o.sauda_date) abc
---select * from #AM_B2C_Revenue
---drop table #AM_B2C_Revenue
---select top 100 * from OnlineEngine.dbo.AS_OrderCountData

----------------------------B2C Comm Campaign Revenue-------------
Select party_code,minclick_date,sauda_date,Clicked_on,[Type],owner_Name,OC,Revenue into #AM_B2CComm_Revenue
from
(Select C.party_code,C.minclick_date,C.minsaudadate,C.Clicked_on,C.[Type],C.owner_Name,O.sauda_date,o.OC, o.Brokerage as Revenue
from AM_OnR_Conversions_Unique C, OnlineEngine.dbo.AS_OrderCountData O
where C.party_code = O.party_code
and C.[Type] = 'B2C_Comm_Campaign'
and C.minsaudadate <= o.sauda_date
and o.INST_Type like 'COMM') abc
---select * from #AM_B2CComm_Revenue

----------------------------B2C FNO Campaign Revenue-------------
Select party_code,minclick_date,sauda_date,Clicked_on,[Type],owner_Name,OC,Revenue into #AM_FNOB2C_Revenue
from
(Select C.party_code,C.minclick_date,C.minsaudadate,C.Clicked_on,C.[Type],C.owner_Name,O.sauda_date,o.OC, o.Brokerage as Revenue
from AM_OnR_Conversions_Unique C, OnlineEngine.dbo.AS_OrderCountData O
where C.party_code = O.party_code
and C.[Type] = 'FNO_B2C_Campaign'
and C.minsaudadate <= o.sauda_date
And INST_Type in ('FUTIDX', 'FUTSTK', 'OPTIDX', 'OPTSTK')) abc
---select * from #AM_FNOB2C_Revenue

----------------------------B2C Currency Campaign Revenue-------------
Select party_code,minclick_date,sauda_date,Clicked_on,[Type],owner_Name,OC,Revenue into #AM_CurrB2C_Revenue
from
(Select C.party_code,C.minclick_date,C.minsaudadate,C.Clicked_on,C.[Type],C.owner_Name,O.sauda_date,o.OC, o.Brokerage as Revenue
from AM_OnR_Conversions_Unique C, OnlineEngine.dbo.AS_OrderCountData O
where C.party_code = O.party_code
and C.[Type] = 'Curr_B2C_Campaign'
and C.minsaudadate <= o.sauda_date
And INST_Type like 'Currency') abc
---select * from #AM_CurrB2C_Revenue

---------------------------B2B Campaign Revenue-----------------
Select party_code,minclick_date,sauda_date,Clicked_on,[Type],owner_Name,OC,Revenue into #AM_B2B_Revenue
from
(Select C.party_code,C.minclick_date,C.minsaudadate,C.Clicked_on,C.[Type],C.owner_Name,O.sauda_date,o.OC, o.Brokerage as Revenue
from AM_OnR_Conversions_Unique C, onlineengine.dbo.UP_B2B_OrderCountData O
where C.party_code = O.party_code
and C.[Type] = 'B2B_Campaign'
and C.minsaudadate <= o.sauda_date) abc
---select * from #AM_B2B_Revenue
-----select top 100 * from onlineengine.dbo.UP_B2B_OrderCountData

----------------------------B2B Comm Campaign Revenue-------------
Select party_code,minclick_date,sauda_date,Clicked_on,[Type],owner_Name,OC,Revenue into #AM_B2BComm_Revenue
from
(Select C.party_code,C.minclick_date,C.minsaudadate,C.Clicked_on,C.[Type],C.owner_Name,O.sauda_date,o.OC, o.Brokerage as Revenue
from AM_OnR_Conversions_Unique C, onlineengine.dbo.UP_B2B_OrderCountData O
where C.party_code = O.party_code
and C.[Type] = 'B2B_Comm_Campaign'
and C.minsaudadate <= o.sauda_date
and o.INST_Type like 'COMM') abc
---select * from #AM_B2BComm_Revenue

----------------------------B2B FNO Campaign Revenue-------------
Select party_code,minclick_date,sauda_date,Clicked_on,[Type],owner_Name,OC,Revenue into #AM_FNOB2B_Revenue
from
(Select C.party_code,C.minclick_date,C.minsaudadate,C.Clicked_on,C.[Type],C.owner_Name,O.sauda_date,o.OC, o.Brokerage as Revenue
from AM_OnR_Conversions_Unique C, onlineengine.dbo.UP_B2B_OrderCountData O
where C.party_code = O.party_code
and C.[Type] = 'FNO_B2B_Campaign'
and C.minsaudadate <= o.sauda_date
And INST_Type in ('FUTIDX', 'FUTSTK', 'OPTIDX', 'OPTSTK')) abc
---select * from #AM_FNOB2B_Revenue

Select * Into #AM_Campaign_Rev
From
(	Select * From #AM_B2C_Revenue
	Union All
	--Select * From #MTFCampaign_Revenue
	--Union All
	Select * From #AM_B2CComm_Revenue
	Union All
	select * from #AM_FNOB2C_Revenue
	Union All
	Select * From #AM_CurrB2C_Revenue
	Union All
	Select * From #AM_FNOB2B_Revenue
	Union All
	Select * From #AM_B2BComm_Revenue
	Union All
	Select * From #AM_B2B_Revenue
)AMRevenue
select * from #AM_Campaign_Rev where sauda_date >'2020-09-28'

Drop Table #AM_Campaign_Rev
Drop Table #AM_B2CComm_Revenue
Drop Table #AM_FNOB2C_Revenue
Drop Table #AM_CurrB2C_Revenue
Drop Table #AM_FNOB2B_Revenue
Drop Table #AM_B2BComm_Revenue
Drop Table #AM_B2B_Revenue

----------------------------------
---------------------------------Query to delete duplicate conversions---------
/*
Select * into #tempA from AM_OnR_Conversions
select * from #tempA

select * into #tempB
from
(Select distinct * ,ROW_NUMBER() Over
(order by party_code, minclick_date, clicked_on) as rowno
from #tempA
)abc
*/

---select * from #tempB
---drop table #tempA
---select * from AM_OnR_Conversions where minclick_date >= '2020-11-01'

select *,  ROW_NUMBER() Over (partition by party_code,[type],owner_name
order by minclick_date asc) as Duplicate
into AM_OnR_Conversions_Unique
--into #tempA
from AM_OnR_Conversions
where minsaudadate >= '2020-11-23'

select distinct party_code from AM_OnR_Conversions_Unique where minsaudadate >= '2020-11-01'

delete from AM_OnR_Conversions_Unique where Duplicate > 1
and minsauda
--delete from #tempA where Duplicate > 1
----Select * from #tempA where party_code='H49087'
--drop table AM_OnR_Conversions_Unique
----select * from AM_OnR_Conversions_Unique order by minsaudadate desc where minsaudadate >= '2020-10-02'

select * into #tempB from
(select * from AM_OnR_Conversions)ab
select* from #tempB


----------------------------
---------------------New query to delete duplicates--------------
Select * into #temp1 from
(select * from AM_OnR_Conversions where minsaudadate>='2020-11-24')ab

select *,  ROW_NUMBER() Over (partition by party_code,[type],owner_name
order by minclick_date asc) as Duplicate
into #temp2
from #temp1

select top 10 * from #temp2

delete from #temp2 where Duplicate > 1

drop table #temp1

------------------Activation & Reactivation Split--------------
drop table #Conversion_Brkup
drop table #mintradeddate
-----select * from AM_OnR_Conversions_Unique
------select top 100 * from OnlineEngine.dbo.AS_OrderCountData
Select * into #Conversion_Brkup from
(select * , cast(NULL as datetime) firsttraded_date, Contype = cast('NULL' as varchar(40)) from #temp2) abc
--AM_OnR_Conversions_Unique)abc

select top 10 * from #Conversion_Brkup

select * into #SA_AR_Data from
(select * from OffersCard_Revenue_and_Conversion
    where minsaudadate >='2021-01-01'
	and minsaudadate <'2021-01-31'
	and Owner_Name like 'Suman%'
	and CampaignName not like 'Reactivation%'
	and rowid in (select max(rowid) from OffersCard_Revenue_and_Conversion)) a

select distinct party_code,max (ROWID)
 from OffersCard_Revenue_and_Conversion
    where minsaudadate >='2021-01-01'
	and minsaudadate <'2021-01-31'
	and Owner_Name like 'Suman%'
	and CampaignName not like 'Reactivation%'
 GROUP BY Party_Code
 
 ,sauda_date,minsaudadate,campaign,revenues,owner_name,CampaignName,TargetSet

 select top 10 * from OffersCard_Revenue_and_Conversion

-----select * from #Conversion_Brkup

select * into #mintradeddate from
(select distinct party_code, min (sauda_date) minsaudadate from OnlineEngine.dbo.AS_OrderCountData with(nolock)
where party_code in
(select distinct party_code
from #temp2)
--from AM_OnR_Conversions_Unique)
group by party_code)a

----select * from #mintradeddate

update #Conversion_Brkup
set firsttraded_date = B.minsaudadate
from  #Conversion_Brkup A, #mintradeddate B
where A.party_code = B.party_code
--and A.owner_name in ('Suman Nayak')
Select * from #Conversion_Brkup

update #Conversion_Brkup
set Contype =
Case When datediff(day,minsaudadate,cast(firsttraded_date as date)) = 0 Then 'Activation'
     When datediff(day,cast(firsttraded_date as date),minsaudadate) > 0 Then 'Reactivation'
	 Else 'NULL'
	 END

	select * from #Conversion_Brkup where minsaudadate >= '2020-10-02'


	select * from AM_OnR_Conversions_Unique
	Select distinct party_code from OffersCard_Revenue_and_Conversion
	select * from OffersCard_Revenue_and_Conversion
	select distinct targetset from OffersCard_Revenue_and_Conversion


	------------------------------Rams Tables
	select top 10 * from OffersCard_Revenue_and_Conversion
	
	------B2C activation conversions------------
	select distinct party_code from OffersCard_Revenue_and_Conversion
    where minsaudadate >='2021-01-01'
	and minsaudadate <'2021-01-31'
	and Owner_Name like 'Suman%'
	and CampaignName not like 'Reactivation%'


	------B2C Reactivation conversions------------
	select distinct party_code from OffersCard_Revenue_and_Conversion
    where minsaudadate >='2021-01-01'
	and minsaudadate <'2021-01-31'
	and Owner_Name like 'Suman%'
	and CampaignName like 'Reactivation%'
	
select top 10 * from AM_OnR_B2C
select count(distinct(party_code)),campaignname,targetset from  OffersCard_Revenue_and_Conversion
where minsaudadate >='2021-01-02'
	and minsaudadate <'2021-01-15'
	and Owner_Name like 'Suman%'
group by campaignname,targetset 

	-------------Segment Conversions--------------
	select distinct party_code from OffersCard_Revenue_and_Conversion
    where minsaudadate >='2021-02-01'
	and minsaudadate <'2021-02-15'
	and Owner_Name like 'Akhilesh%'
	

	select distinct party_code from SN_CampaignRevenue_FY2021 
	where minsaudadate >='2021-01-01'
	and minsaudadate <='2021-01-15'
	and [Type] like 'First Activation%'

	select distinct [Type] from SN_CampaignRevenue_FY2021

select top 10 * from SN_CampaignClientsConverted_FY2021