use onlineengine

select max(sauda_date) from AS_OrderCountData