USE [OnlineEngine]
GO

INSERT INTO [dbo].[SN_ClientKYC_Bkp]
           ([Party_Code]
           ,[B2C]
           ,[City]
           ,[State]
           ,[Nation]
           ,[ZIP]
           ,[Branch_cd]
           ,[Credit_Limit]
           ,[Bank_Name]
           ,[Ac_Type]
           ,[Family]
           ,[Penalty]
           ,[Sub_Broker]
           ,[Mobilevalidatedby]
           ,[MobilevalidatedOn]
           ,[trader]
           ,[Region]
           ,[Area]
           ,[PerDay]
           ,[TradeDays]
           ,[YearBrok]
           ,[Trend]
           ,[EbrokingClient]
           ,[NbFcClient]
           ,[EbrokingTerminal]
           ,[Clrating]
           ,[AngelClRating]
           ,[PastClient]
           ,[ClientFlag]
           ,[BlockSms]
           ,[Birthdate]
           ,[Gender]
           ,[TradingPlatform]
           ,[IsActiveForEbrokingProduct]
           ,[RiskCategory]
           ,[Zone]
           ,[TotalMargin_Capped]
           ,[ActiveFrom]
           ,[ActiveFrom_Broking]
           ,[InActiveFrom]
           ,[ActiveFromEq]
           ,[InactiveFromEq]
           ,[ActiveFromComm]
           ,[InactiveFromComm]
           ,[ActiveFromCurr]
           ,[InactiveFromCurr]
           ,[CTActiveFrom]
           ,[CTInactiveFrom]
           ,[ActiveFromMcxNcx]
           ,[InActiveFromMcxNcx]
           ,[NbFcActivefrom]
           ,[NbFcInactiveFrom]
           ,[BSEMFSSActiveFrom]
           ,[BSEMFSSInActiveFrom]
           ,[FirstTrade]
           ,[LastTrade]
           ,[FirstTradeComm]
           ,[LastTradeComm]
           ,[FirstTradeCurr]
           ,[LastTradeCurr]
           ,[FirstTradeMcxNcx]
           ,[LastTradeMcxNcx]
           ,[BSEMFSSFirstTrade]
           ,[BSEMFSSLastTrade]
           ,[FirstLedger]
           ,[FirstLedgerDate]
           ,[FirstledgerdateEq]
           ,[FirstledgerdateComm]
           ,[FirstledgerdateCurr]
           ,[LastCommunication]
           ,[Scrutiny_Allocation_Date]
           ,[Scrutiny_Completion_Date]
           ,[MobileHashKey]
           ,[FirstTradeEq]
           ,[LastTradeEq]
           ,[OnlineCat]
           ,[IncomeDetails]
           ,[Occupation]
           ,[PartyCode_GenDate]
           ,[ActiveFromFO]
           ,[InActiveFromFO]
           ,[SCHEME_NAME]
           ,[BrokeragePlanDate]
           ,[LastTrade_FO]
           ,[POA_Status]
           ,[MarkettingChannel]
           ,[IsClosed]
           ,[MTF_From_Date]
           ,[MTF_To_Date]
           ,[introducer_id]
           ,[Cust_Support])
     VALUES
           (<Party_Code, varchar(10),>
           ,<B2C, char(1),>
           ,<City, varchar(40),>
           ,<State, varchar(50),>
           ,<Nation, varchar(15),>
           ,<ZIP, varchar(10),>
           ,<Branch_cd, varchar(10),>
           ,<Credit_Limit, numeric(13,2),>
           ,<Bank_Name, varchar(50),>
           ,<Ac_Type, varchar(10),>
           ,<Family, varchar(10),>
           ,<Penalty, numeric(6,0),>
           ,<Sub_Broker, varchar(10),>
           ,<Mobilevalidatedby, varchar(20),>
           ,<MobilevalidatedOn, datetime,>
           ,<trader, varchar(20),>
           ,<Region, varchar(50),>
           ,<Area, varchar(10),>
           ,<PerDay, money,>
           ,<TradeDays, int,>
           ,<YearBrok, money,>
           ,<Trend, char(10),>
           ,<EbrokingClient, char(1),>
           ,<NbFcClient, char(1),>
           ,<EbrokingTerminal, varchar(20),>
           ,<Clrating, varchar(10),>
           ,<AngelClRating, char(10),>
           ,<PastClient, varchar(10),>
           ,<ClientFlag, char(1),>
           ,<BlockSms, char(1),>
           ,<Birthdate, datetime,>
           ,<Gender, varchar(2),>
           ,<TradingPlatform, varchar(10),>
           ,<IsActiveForEbrokingProduct, varchar(1),>
           ,<RiskCategory, varchar(10),>
           ,<Zone, varchar(20),>
           ,<TotalMargin_Capped, money,>
           ,<ActiveFrom, datetime,>
           ,<ActiveFrom_Broking, datetime,>
           ,<InActiveFrom, datetime,>
           ,<ActiveFromEq, datetime,>
           ,<InactiveFromEq, datetime,>
           ,<ActiveFromComm, datetime,>
           ,<InactiveFromComm, datetime,>
           ,<ActiveFromCurr, datetime,>
           ,<InactiveFromCurr, datetime,>
           ,<CTActiveFrom, datetime,>
           ,<CTInactiveFrom, datetime,>
           ,<ActiveFromMcxNcx, datetime,>
           ,<InActiveFromMcxNcx, datetime,>
           ,<NbFcActivefrom, datetime,>
           ,<NbFcInactiveFrom, datetime,>
           ,<BSEMFSSActiveFrom, datetime,>
           ,<BSEMFSSInActiveFrom, datetime,>
           ,<FirstTrade, datetime,>
           ,<LastTrade, datetime,>
           ,<FirstTradeComm, datetime,>
           ,<LastTradeComm, datetime,>
           ,<FirstTradeCurr, datetime,>
           ,<LastTradeCurr, datetime,>
           ,<FirstTradeMcxNcx, datetime,>
           ,<LastTradeMcxNcx, datetime,>
           ,<BSEMFSSFirstTrade, datetime,>
           ,<BSEMFSSLastTrade, datetime,>
           ,<FirstLedger, money,>
           ,<FirstLedgerDate, datetime,>
           ,<FirstledgerdateEq, datetime,>
           ,<FirstledgerdateComm, datetime,>
           ,<FirstledgerdateCurr, datetime,>
           ,<LastCommunication, datetime,>
           ,<Scrutiny_Allocation_Date, datetime,>
           ,<Scrutiny_Completion_Date, datetime,>
           ,<MobileHashKey, nvarchar(50),>
           ,<FirstTradeEq, datetime,>
           ,<LastTradeEq, datetime,>
           ,<OnlineCat, varchar(20),>
           ,<IncomeDetails, varchar(50),>
           ,<Occupation, varchar(100),>
           ,<PartyCode_GenDate, datetime,>
           ,<ActiveFromFO, datetime,>
           ,<InActiveFromFO, datetime,>
           ,<SCHEME_NAME, varchar(100),>
           ,<BrokeragePlanDate, datetime,>
           ,<LastTrade_FO, datetime,>
           ,<POA_Status, varchar(5),>
           ,<MarkettingChannel, varchar(50),>
           ,<IsClosed, varchar(5),>
           ,<MTF_From_Date, datetime,>
           ,<MTF_To_Date, datetime,>
           ,<introducer_id, varchar(50),>
           ,<Cust_Support, nvarchar(50),>)
GO

select top 100 * from CT_Campaign

USE [OnlineEngine]
GO

INSERT INTO [dbo].[CT_Campaign]
           ([CampaignID]
           ,[CampaignName]
           ,[JourneyID]
           ,[Channel]
           ,[ActionID]
           ,[CampaignIntent]
           ,[StartDate]
           ,[Comments]
           ,[DayTag])
     VALUES
           (<CampaignID, bigint,>
           ,<CampaignName, varchar(max),>
           ,<JourneyID, bigint,>
           ,<Channel, varchar(20),>
           ,<ActionID, int,>
           ,<CampaignIntent, varchar(15),>
           ,<StartDate, datetime,>
           ,<Comments, text,>
           ,<DayTag, varchar(15),>)
GO

