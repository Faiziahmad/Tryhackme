Use Communication
select * from #MTF_Click
select * from #MTF_Click_Unique 
Select distinct * into #MTF_Click
from [OnlineEngine].[dbo].[AJ_OffersCardClick_updated]
where Clicked_on like '%MTF%' 
and profile_identity IS NOT NULL
and convert(date,left(ts,8),106) >= '2021-06-01'
---select distinct * from [OnlineEngine].[dbo].[AJ_OffersCardClick] where profile_identity IS NOT NULL
----drop table #MTF_Click 
----select * from #MTF_Click
Select * into #MTF_Click_Unique from
	(
		Select Distinct profile_identity,Clicked_on,convert(date,left(ts,8),106) as ts, 
		Row_Number() Over (partition by profile_identity,Clicked_on,ts order by ts) as Duplicate
		from #MTF_Click
		group by profile_identity,Clicked_on,ts
	)C

----drop table #MTF_Click_Unique
---select * from #MTF_Click_Unique

select Distinct [Month],TradingDay,ROW_NUMBER() OVER(ORDER BY TradingDay ASC) AS Numbering 
	Into #DayDiffTable 
from OnlineEngine.dbo.SN_TradingDays 
----select * from OnlineEngine.dbo.SN_TradingDays order by tradingday desc
---drop table #daydifftable
-----select * from #DayDiffTable 

-----Trading day count is numbering; for MTF logic, we have taken numbering  + 2
Select Distinct *,Case When MinClick_Date = TradingDay then Numbering + 2  end  as MTF_Logic_Mapping ------NOT CLEAR
	Into #AM_MTF_Clicks 
	From  #AM_Click_Unique A
	Left Join #DayDiffTable B
	On A.MinClick_Date = B.TradingDay
-----select * from #AM_MTF_Clicks

Select Distinct  A.profile_identity,A.Clicked_on, A.Owner_Name,A.MinClick_Date,A.MinClick_DateTime,B.TradingDay as Final_MTF_Date
	Into #Final_MTF_Clicks
	From #AM_MTF_Clicks A , #DayDiffTable B
	Where  A.MTF_Logic_Mapping = B.Numbering
	And Clicked_on like '%MTF%' 
-----select * from #Final_MTF_Clicks

Select profile_identity as Party_code, Clicked_on,Min(B.balancedate) as minsaudadate,'MTF_Campaign' [Type]
	Into #MTFCampaign from  #Final_MTF_Clicks A
	left outer join onlineengine.dbo.SN_DaywiseDPC B with (nolock)
	on A.profile_identity = B.Party_code
			Where Clicked_on like '%MTF%'        
			and convert(date,Final_MTF_Date,106) <= B.balancedate
			and Datediff(day,Final_MTF_Date,B.balancedate) < 2
			and Datediff(day,Final_MTF_Date,B.balancedate) >= 0
Group by A.profile_identity, Clicked_on
------Select * from #MTFCampaign


Select minsaudadate,Clicked_on,Count(Distinct Party_code) UC,[Type] 
	Into #MTFCampaign_UC 
	From #MTFCampaign  
Group by minsaudadate,Clicked_on,[Type]
------Select * from #MTFCampaign_UC 
-------select * from onlineengine.dbo.SN_DaywiseDPC
--Select Distinct  B.balancedate as Sauda_Date,Clicked_on, count(distinct(A.Party_code)) as clientcount,sum(NetDebit) as Revenues, [Type]
Select Distinct  B.balancedate as Sauda_Date,Clicked_on, count(distinct(A.Party_code)) as clientcount,sum(DPC) as Revenues, [Type]	
	Into #MTFCampaign_Revenue 
	from #MTFCampaign A, onlineengine.dbo.SN_DaywiseDPC B with (nolock)
	where A.Party_code = B.Party_code
	and A.minsaudadate <= B.balancedate
	--and Datediff(day,minsaudadate,B.balancedate) < 2
	--and Datediff(day,minsaudadate,B.balancedate) >= 0
group by B.balancedate, Clicked_on,[Type]
---------select * from ​#MTFCampaign_Revenue




----------------------------------------------------
-------------------OVERALL MTF QUERY-------------------------
-----------------------------------------------MTF Campaign --------------------------------------------------
/*
select Distinct [Month],TradingDay,ROW_NUMBER() OVER(ORDER BY TradingDay ASC) AS Numbering 
	Into #DayDiffTable 
from OnlineEngine.dbo.SN_TradingDays 
----select * from OnlineEngine.dbo.SN_TradingDays order by tradingday desc
-----select * from #DayDiffTable 

-----Trading day count is numbering; for MTF logic, we have taken numbering  + 2
Select Distinct *,Case When MinClick_Date = TradingDay then Numbering + 2  end  as MTF_Logic_Mapping ------NOT CLEAR
	Into #AM_MTF_Clicks 
	From  #AM_Click_Unique A
	Left Join #DayDiffTable B
	On A.MinClick_Date = B.TradingDay
-----select * from #AM_MTF_Clicks

Select Distinct  A.profile_identity,A.Clicked_on, A.Owner_Name,A.MinClick_Date,A.MinClick_DateTime,B.TradingDay as Final_MTF_Date
	Into #Final_MTF_Clicks
	From #AM_MTF_Clicks A , #DayDiffTable B
	Where  A.MTF_Logic_Mapping = B.Numbering
	And Clicked_on like '%MTF%' 
-----select * from #Final_MTF_Clicks

Select profile_identity as Party_code, Clicked_on,Min(B.balancedate) as minsaudadate,'MTF_Campaign' [Type]
	Into #MTFCampaign from  #Final_MTF_Clicks A
	left outer join onlineengine.dbo.SN_DaywiseDPC B with (nolock)
	on A.profile_identity = B.Party_code
			Where Clicked_on like '%MTF%'        
			and convert(date,Final_MTF_Date,106) <= B.balancedate
			and Datediff(day,Final_MTF_Date,B.balancedate) < 2
			and Datediff(day,Final_MTF_Date,B.balancedate) >= 0
Group by A.profile_identity, Clicked_on
----select top 1000 * from onlineengine.dbo.SN_DaywiseDPC with(nolock)
------Select * from #MTFCampaign


Select minsaudadate,Clicked_on,Count(Distinct Party_code) UC,[Type] 
	Into #MTFCampaign_UC 
	From #MTFCampaign  
Group by minsaudadate,Clicked_on,[Type]
------Select * from #MTFCampaign_UC 
-------select * from onlineengine.dbo.SN_DaywiseDPC
--Select Distinct  B.balancedate as Sauda_Date,Clicked_on, count(distinct(A.Party_code)) as clientcount,sum(NetDebit) as Revenues, [Type]
Select Distinct  B.balancedate as Sauda_Date,Clicked_on, count(distinct(A.Party_code)) as clientcount,sum(DPC) as Revenues, [Type]	
	Into #MTFCampaign_Revenue 
	from #MTFCampaign A, onlineengine.dbo.SN_DaywiseDPC B with (nolock)
	where A.Party_code = B.Party_code
	and A.minsaudadate <= B.balancedate
	--and Datediff(day,minsaudadate,B.balancedate) < 2
	--and Datediff(day,minsaudadate,B.balancedate) >= 0
group by B.balancedate, Clicked_on,[Type]
---------select * from ​#MTFCampaign_Revenue
*/


----------------------------------------------------
-------------------SUMANS QUERY--------------------

drop table #SN_MTFClicks

use Communication
​
-------------*****************************************************************************----------------
----- MTF Campaigns Revenue Query
-------------*****************************************************************************----------------
​
---******************* last 10 days MTF campaigns clicks data

------select * from onlineengine.dbo.SN_DaywiseDPC
--drop table #SN_MTFClicks
select campaign_name, party_code, mode, click_date,
convert(date,Executiondate,105) Executiondate, CampaignID, cast(NULL as datetime) mindate, cast(NULL as datetime) maxdate 
into #SN_MTFClicks
from RJ_Performance_set
where Campaign_Name like '%mtf%'
and ExecutionDate >= convert(date,getdate()-10,106) and ExecutionDate<GETDATE()-1
----​select top 100 * from RJ_Performance_set
--- update the min and max conversion date 
----select * from #SN_MTFClicks
update a
set mindate=b.tradingday 
from #SN_MTFClicks a left outer join onlineengine.dbo.DK_DaysoftradingfromDate_all b
on convert(Date,a.click_date,106) = b.DateList
where b.DayofTrading=2
and a.mindate is null
----select top 100 * from ​onlineengine.dbo.DK_DaysoftradingfromDate_all
update a
set maxdate=b.tradingday 
from #SN_MTFClicks a left outer join onlineengine.dbo.DK_DaysoftradingfromDate_all b
on convert(Date,a.click_date,106) = b.DateList
where b.DayofTrading=3
and a.maxdate is null
​
-- to check if min and max date updated
select distinct executiondate, convert(Date,click_date,106) clickdate, mindate, maxdate, campaignid, campaign_name 
from #SN_MTFClicks
order by Executiondate
​
​
---------- query to get converted clients 
​
--drop table #temp
Select * into #Temp from 
(
Select B.party_code, c.Campaign_Name, min(cast(balancedate as datetime))  minbalancedate, c.campaignid, 
	max(c.click_date) clickdate, cast(c.ExecutionDate as datetime) ExecutionDate, Mode 
from onlineengine.dbo.SN_DaywiseDPC B with (nolock) Inner Join #SN_MTFClicks C
ON B.Party_code = C.Party_code
Where BalanceDate >= convert(date,mindate,106)
and convert(date,BalanceDate,105) <= convert(date,maxdate,106)
and c.maxdate >= getdate()-10
Group by B.party_code, Campaign_Name, c.campaignid, c.Executiondate, Mode
)AA
---select top 100000 * from ​onlineengine.dbo.SN_DaywiseDPC with(nolock)
--drop table #temp2
----select * from #Temp
--drop table #temp2
Select * into #Temp2 from 
(
Select party_code, Campaign_Name,  minbalancedate, campaignid, clickdate, ExecutionDate, Mode, ROWID = ROW_NUMBER() OVER (PARTITION BY  party_code ORDER BY minbalancedate asc)
from #Temp
)C
​
Delete from #Temp2 where rowid > 1
​
​
---************* insert converted clients into table ---------
insert into #ConvertedClientsTable (party_code, convertdate,campaignid,campaignname, actiondate, [Action], ExecutionDate  )
select distinct party_code, minbalancedate, campaignid, campaign_name, clickdate, Mode, ExecutionDate
from #temp2
where party_code not in (select party_code from #ConvertedClientsTable) 
​
---------------------------------------------------------------------
-------------- update revenue data for converted clients --------------
---------------------------------------------------------------------
​
insert into #RevenueTable (Balancedate, Party_code, netdebit, dpc, [action], actiondate, campaignid, CampaignName, Is_converted, convertdate)
select b.balancedate, a.Party_code, b.netdebit, b.dpc, a.[action],a.actiondate, a.campaignid, a.CampaignName, 1, a.convertdate
from #ConvertedClientsTable A inner join	onlineengine.dbo.SN_DaywiseDPC B with (nolock)
on A.Party_code = B.Party_code
where B.BalanceDate >=A.convertdate
and BalanceDate>(select max(balancedate) from #RevenueTable)
and BalanceDate<convert(date,getdate(),105)
​
Drop table #SN_MTFClicks
Drop table #Temp
Drop table #Temp2
​

-----------------------------NEW QUERY  use this !-------------------------
Use Communication


select * from [OnlineEngine].[dbo].[AJ_OffersCardClick_updated]

drop table #MTF_Click
drop table #MTF_Click_Unique
drop table #temp
drop table #ConvertedClientsTable
drop table #temp2

select distinct clicked_on from [OnlineEngine].[dbo].[AJ_OffersCardClick_updated]

Select profile_identity,Clicked_on,ts into #MTF_Click
from [OnlineEngine].[dbo].[AJ_OffersCardClick_updated]
where Clicked_on like '%MTF%' 
and profile_identity IS NOT NULL
and convert(date,left(ts,8),106) >= '2021-03-01'
---select distinct * from [OnlineEngine].[dbo].[AJ_OffersCardClick] where profile_identity IS NOT NULL
----drop table #MTF_Click 
----select * from #MTF_Click
---select * from 
Select * into #MTF_Click_Unique from
	(
		Select Distinct profile_identity,Clicked_on,convert(date,left(ts,8),106) as ts, 
		Row_Number() Over (partition by profile_identity,Clicked_on,ts order by ts) as Duplicate,
		cast(NULL as datetime) mindate, cast(NULL as datetime) maxdate 
		from #MTF_Click
		group by profile_identity,Clicked_on,ts
	)C
-----select * from #MTF_Click_Unique
-----drop table #MTF_Click_Unique
update a
set mindate=b.tradingday 
from #MTF_Click_Unique a left outer join onlineengine.dbo.DK_DaysoftradingfromDate_all b
on convert(Date,a.ts,106) = b.DateList
where b.DayofTrading=2
and a.mindate is null
----select * from ​onlineengine.dbo.DK_DaysoftradingfromDate_all
update a
set maxdate=b.tradingday 
from #MTF_Click_Unique a left outer join onlineengine.dbo.DK_DaysoftradingfromDate_all b
on convert(Date,a.ts,106) = b.DateList
where b.DayofTrading=3
and a.maxdate is null

select * from #MTF_Click_Unique order by ts


Select * into #Temp from 
(
Select B.party_code, c.Clicked_on, min(cast(balancedate as datetime)) minbalancedate, max(c.ts) clickdate 
from onlineengine.dbo.SN_DaywiseDPC B with (nolock) Inner Join #MTF_Click_Unique C
ON B.Party_code = C.profile_identity
Where BalanceDate >= convert(date,mindate,106)
and convert(date,BalanceDate,105) <= convert(date,maxdate,106)
--and c.maxdate >= getdate()-10
Group by B.party_code,c.Clicked_on
)AA

--select * from #Temp
--select distinct party_code from #Temp
----drop table #temp


Select * into #Temp2 from 
(
Select party_code, Clicked_on,  minbalancedate, clickdate, ROWID = ROW_NUMBER() OVER (PARTITION BY  party_code ORDER BY minbalancedate asc)
from #Temp
)C
​
Delete from #Temp2 where rowid > 1
----select * from #Temp2 where clickdate >'2021-01-01'

insert into #ConvertedClientsTable (party_code, convertdate,Clicked_on, actiondate  )
select distinct party_code, minbalancedate, Clicked_on, clickdate
from #temp2
where party_code not in (select party_code from #temp2) 

-------------- update revenue data for converted clients --------------
---------------------------------------------------------------------
---select top 100 * from onlineengine.dbo.SN_DaywiseDPC​ with(nolock)
--insert into #RevenueTable2 (Balancedate, Party_code, netdebit, dpc, minbalancedate, clickdate, Clicked_on)

select * into #revenuetable2 from
(select b.balancedate, a.Party_code, b.netdebit, b.dpc, a.minbalancedate, a.clickdate, a.Clicked_on
from #Temp2 A inner join onlineengine.dbo.SN_DaywiseDPC B with (nolock)
on A.Party_code = B.Party_code
where B.BalanceDate >=A.minbalancedate
)rev

select * from #revenuetable2 

select cast(minbalancedate as date),count(distinct party_code) from #revenuetable2
group by cast(minbalancedate as date)
where clickdate > '2020-
--and BalanceDate>(select max(balancedate) from #RevenueTable2)
--and BalanceDate<convert(date,getdate(),105)


use communication
Select * from OffersCard_Revenue_and_Conversion

select max(sauda_date) from OffersCard_Revenue_and_Conversion_21