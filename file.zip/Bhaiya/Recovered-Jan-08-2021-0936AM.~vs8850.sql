use OnlineEngine

select top 5000 * from dbo.CT_buy_order where ts in (select max(ts) from dbo.CT_buy_order) 

select * from dbo.AS_TradeData where SAUDA_DATE='2020-12-31 00:00:00.000'

select max(sauda_date) from dbo.as_tradedata


 

cast(convert(datetime,stuff(stuff(stuff(ts, 9, 0, ' '), 12, 0, ':'), 15, 0, ':')) as Date) >= 'T-1'

select max(cast(convert(datetime,stuff(stuff(stuff(sauda_date, 9, 0, ' '), 12, 0, ':'), 15, 0, ':')) as Date)) 
from dbo.AS_OrderCountData

select max(sauda_date) from dbo.AS_OrderCountData


select top 100 * from dbo.AS_OrderCountData

select distinct inst_type from dbo.AS_OrderCountData



use onlineengine
select cast(convert(datetime,stuff(stuff(stuff(ts, 9, 0, ' '), 12, 0, ':'), 15, 0, ':')) as Date) as ts,  count(distinct profile_identity) as EngagedUsers
from CT_clicked
where utm_campaign in (7110)
and cast(convert(datetime,stuff(stuff(stuff(ts, 9, 0, ' '), 12, 0, ':'), 15, 0, ':')) as Date) >= '2020-04-01'
group by cast(convert(datetime,stuff(stuff(stuff(ts, 9, 0, ' '), 12, 0, ':'), 15, 0, ':')) as Date)
order by cast(convert(datetime,stuff(stuff(stuff(ts, 9, 0, ' '), 12, 0, ':'), 15, 0, ':')) as Date) desc