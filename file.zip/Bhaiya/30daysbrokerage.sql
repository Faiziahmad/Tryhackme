﻿---First Activation----
​
select party_code, minsaudatdate, campaign, targetset, Campaign_Type
from communication.dbo.RJ_FNO_CampaignClients_2122
where minsaudatdate between '2021-06-01' and '2021-06-30'
and campaign in ('30 Days Free_FA_30-60', '30 Days Free_FA_60-90', '30 Days Free_FA_90-365')
​
​
----Reactivation----
​
select party_code, minsaudatdate, campaign, targetset, Campaign_Type
from communication.dbo.RJ_FNO_CampaignClients_2122
where minsaudatdate between '2021-05-01' and '2021-05-31'
and campaign = '30 Days Free_RA_90-730'


use communication
select top 10 * from RJ_FNO_CampaignRevenue_2122 where campaign like '30 Days%'
where 



select * from RJ_FNO_CampaignRevenue_2122
where campaign in ('30 Days Free_RA_90-730', '30 Days Free_FA_30-60', '30 Days Free_FA_60-90', '30 Days Free_FA_90-365')
and minsaudatdate >= '2021-06-01'

select distinct campaign from RJ_FNO_CampaignRevenue_2122
