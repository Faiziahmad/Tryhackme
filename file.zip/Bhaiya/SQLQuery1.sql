Select RequestName from [OnlineEngine].[dbo].[SH_API_Automation_Reporting] group by RequestName


use onlineengine
select * from SH_API_Automation_Reporting

SELECT * FROM [OnlineEngine].[dbo].[SH_API_Automation_Reporting] 
where Dates = convert(varchar, getdate(), 23) AND ReponseTime >= 3000 
AND Times >= convert(varchar(5), DATEADD(HH,-1,getdate()), 8) order By Times DESC


Select  cast (ProcessDate as date) AS date,count(FFM_Message_ID) as clients,COUNT(DISTINCT Party_code) Engagement ,
SUM(CASE WHEN IsURLClicked='Y' THEN 1 ELSE 0 END) URL_Clicks
--into #Download_App
FROM [196.1.115.207].CRM.dbo.Vw_WhatsApp_Onboarding_Log_Keywords WITH(NOLOCK)
where --Keyword_Name='Download App' and 
Party_code!='K96681 ' and Party_code!='F4557 ' and ClientType='B2C' 
and DATEDIFF(day,Convert(DATE,ActivationDate), Convert(DATE,ProcessDate))>15
and cast (ProcessDate as date)>'2021-01-10'
group by cast (ProcessDate as date)
order by  cast (ProcessDate as date) DESC

 select distinct A.profile_identity,CONVERT(date,SUBSTRING(CAST(TS AS VARCHAR),1,8)) as date
  from [OnlineEngine].[dbo].[CT_clicked] A
  where utm_campaign = '1000790010'
  order by date desc


select AA.party_code, AA.Partycode_gendate, AA.Min_sauda_time, BB.B2C, Cast('Null' as varchar(40)) as Campaign
into #temmp
from
(select A.party_code, A.Partycode_gendate, B.Min_sauda_time
from
(select Client_code as party_code, cast(AddedOn as date) as Partycode_gendate, Control_flag
from [OnlineEngine].[dbo].[tbl_KYC_OB_Clients] with (nolock)
where AddedOn >= '2021-01-08 00:00:00' and Control_flag = 0) A
left join
(select party_code, min(cast(sauda_date as datetime) + cast(MinsaudaTime as datetime)) as Min_sauda_time
from SN_MinSaudaTime
where cast(sauda_date as datetime) >= '2021-01-08 00:00:00'
group by party_code
) B
on A.party_code = B.party_code) AA 
left join SN_clientkyc BB
on AA.party_code = BB.party_code

update A
set Campaign = 'DRA'
from #temp A, SN_ClientKYC B
where A.party_code = B.Party_Code and B.Branch_cd in ('RFRL')

update A
set Campaign = (case when B.Campaign in ('ABMA', 'ABMA_Organic', 'SSGoogleSearch', 'Web') then B.Campaign
										when B.Campaign is null then 'Referral'
										else 'Other' end ) 
from #temp A, SN_SalesSource_Intent B
where A.party_code = B.Party_Code and A.Campaign not in ('DRA')


select AA.Campaign AS "action::filter",cast(AA.Partycode_gendate as date) as Dates, AA.Activation_type, CounT(AA.party_code) as Users
from 
(select A.Campaign,A.party_code, A.Partycode_gendate, A.Min_sauda_time, B.Day0,B.Day1, B.Day2, B.Day3, B.Day4,
(case when cast(A.Min_sauda_time as date) = B.Day0 then 'Day0'
	when cast(A.Min_sauda_time as date) = B.Day1 then 'Day1'
	when cast(A.Min_sauda_time as date) = B.Day2 then 'Day2'
	when cast(A.Min_sauda_time as date) = B.Day3 then 'Day3'
	when cast(A.Min_sauda_time as date) = B.Day4 then 'Day4'
	else 'Not Traded' end) as Activation_type
from #temp A left join AD_Trading_Day B
on A.Partycode_gendate = B.OnBDate
where A.B2C = 'Y') AA
group by AA.Campaign, cast(AA.Partycode_gendate as date) , AA.Activation_type
order by cast(AA.Partycode_gendate as date)

drop table #temmp


select top 10 * from [OnlineEngine].[dbo].[CT_clicked]  where utm_campaign='1000790010'

select top 100 * from onlineengine.dbo.CT_campaign_map_daily where message_name like '%tata%'

select top 10 * from communication.dbo.Exe_Summary 


select distinct B.campaign_Name,C.TargetSet,C.Execution_Date,C.ExecutedOnClient,A.channel as channel, sent,clicked from 
 onlineengine.dbo.CT_campaign_map_daily A
 left join communication.dbo.rg_campaignset B on A.message_name = B.campaign_Name
 left join communication.dbo.Exe_Summary C on B.targetset = C.TargetSet
 where B.Campaign_name like 'iprotect%'
 and A.channel = 'Push'
 and B.owner_name = 'Ashwati Menon'
 and cast(start_date as date) = C.Execution_Date
 and  cast(start_date as date) >= '2021-02-01'



 use onlineengine


select A.PartyCode_GenDate,A.Party_Code, B.MinFunding, 
(case when datediff(DAY,A.PartyCode_GenDate, B.MinFunding) = 0 then 'Day0'
      when datediff(DAY,A.PartyCode_GenDate, B.MinFunding) = 1 then 'Day1'
	  when datediff(DAY,A.PartyCode_GenDate, B.MinFunding) = 2 then 'Day2'
	  when datediff(DAY,A.PartyCode_GenDate, B.MinFunding) = 3 then 'Day3'
	  when datediff(DAY,A.PartyCode_GenDate, B.MinFunding) = 4 then 'Day4'
	  when datediff(DAY,A.PartyCode_GenDate, B.MinFunding) >= 5 then 'Day4+' 
	  else 'Yet to Fund' end) as Funding_Cat into #temp
from
(select Party_Code, PartyCode_GenDate
from SN_clientkyc
where PartyCode_GenDate >= '2021-01-01' and B2C = 'Y' ) A
left join
(select ClientCode, min(RequestDateTime) as MinFunding
from AJ_FundTransferSource
where [Status] = 'SUCCESS' and RequestDateTime>= '2021-01-01'
group by ClientCode) B
on A.Party_Code = B.ClientCode


select cast(PartyCode_GenDate as date) as Dates, Funding_Cat,count(party_code) as Users 
from #temp
group by cast(PartyCode_GenDate as date), Funding_Cat

drop table #temp

USE ONLINEENGINE

select top 10 * from CT_campaign --where channel='InApp'

select top 10 * from dbo.b2ccampaignclicks where campaign_name like '%Reward%'

select top 10 * from dbo.tbl_CleverTapEvents