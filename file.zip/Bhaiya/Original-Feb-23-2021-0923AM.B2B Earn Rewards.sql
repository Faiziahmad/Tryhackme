Use OnlineEngine
--drop table #temp1
Select * into #temp1 from
(
SELECT CampaignType,isnull(COUNT(distinct RefereeClientCode),0) as ClientConverted,datename(month,CreationDate) as NameOfMonth
FROM [OnlineEngine].[dbo].[PR_GetRefEarnABMARerralDetails_B2B]
--where campaignType != 'CAMP'
group by CampaignType,datename(month,CreationDate)
--order by COUNT(RefereeClientCode) desc
)a
 PIVOT(
   sum(ClientConverted)
    FOR NameOfMonth IN ( [January],[February],[March],[April],[May],[June],[July],[August],[September],[October],[November])
) AS pivot_table
select campaignType, isnull(January,0) as Jan, isnull(February,0)as Feb,isnull(March,0)as March, isnull(April,0)as April ,
isnull(May,0)as May ,isnull(June,0)as June , isnull(July,0)as July,isnull(August,0)as August ,isnull(September,0)as September,
isnull(October,0)as October,isnull(November,0)as November
from #temp1

---select * from #temp1


-------------------------
----------------Daywise converts-----------------

Select Cast(Creationdate as date) as Convertdate,count(RefereeClientCode) as ClientCount from 
[OnlineEngine].[dbo].[PR_GetRefEarnABMARerralDetails_B2B]
where campaigntype = 'hamburgermenu'
and Cast(Creationdate as date) >= '2021-02-01'
and Cast(Creationdate as date) <= '2021-02-16'
group by Cast(Creationdate as date)
order by Cast(Creationdate as date)

-------------------------------USE THIS QUERY !!---------------

select month(creationdate),count(RefereeClientCode) as Clientcount from [OnlineEngine].[dbo].[PR_GetRefEarnABMARerralDetails_B2B]
where campaigntype = 'hamburgermenu'
group by month(creationdate)

select * from [OnlineEngine].[dbo].[PR_GetRefEarnABMARerralDetails_B2B]