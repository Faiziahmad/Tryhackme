select top 10 * from [196.1.115.167].[KYC_CI].dbo.[VW_Campaign_ClientInfo]


select distinct pushedfrom from [196.1.115.167].[KYC_CI].dbo.[VW_Campaign_ClientInfo]

DIYWEBB2C

declare @Existingdate datetime
Set @Existingdate=GETDATE()
select top 10 * from [196.1.115.167].[KYC_CI].dbo.[VW_Campaign_ClientInfo] where PushedFrom = 'DIYWEBB2C'
--and logdate between '2021-01-01 00:00:00.001' and '2021-04-30 23:59:59.999'

and CONVERT(varchar,@Existingdate,105)>='2021-01-01'
and CONVERT(varchar,@Existingdate,105)<='2021-04-30'


and convert(date,left(logdate,10),103)>='01-01-2021'
and convert(date,left(logdate,10),103)>='30-04-2021'

and convert(varchar,logdate,103)>='2021-01-01'
and convert(varchar,logdate,103)>='2021-04-30'

as [DD/MM/YYYY]