select * from [OnlineEngine].[dbo].[VW_Bundled_Plan_ClientInfo]
select * from [OnlineEngine].[dbo].[AJ_OffersCardClick_updated] order by ts 

drop table #AJ_OffersClick
drop table #AJ_Metadata
drop table #AM_Click
drop table #tempa
/*
Select * Into #AJ_OffersClick
From
(Select Distinct Clicked_on,profile_identity,ts,convert(date,left(ts,8),106) as Click_Date,
convert(datetime,stuff(stuff(stuff(ts, 9, 0, ' '), 12, 0, ':'), 15, 0, ':')) as Click_DateTime From [OnlineEngine].[dbo].[AJ_OffersCardClick_updated]
--convert(datetime,stuff(stuff(stuff(ts, 9, 0, ' '), 12, 0, ':'), 15, 0, ':')) as Click_DateTime From [OnlineEngine].[dbo].[AJ_OffersCardClick]
Where profile_identity is not NULL
and Clicked_on like '%ARQ%'
and convert(date,left(ts,8),106) >= '2021-02-01'
)a
*/

Select * Into #AJ_OffersClick from
(Select Distinct Clicked_on,profile_identity,ts,convert(date,left(ts,8),106) as Click_Date,
convert(datetime,stuff(stuff(stuff(ts, 9, 0, ' '), 12, 0, ':'), 15, 0, ':')) as Click_DateTime From 
[OnlineEngine].[dbo].[AJ_OffersCardClick_updated]
--convert(datetime,stuff(stuff(stuff(ts, 9, 0, ' '), 12, 0, ':'), 15, 0, ':')) as 
--Click_DateTime From [OnlineEngine].[dbo].[AJ_OffersCardClick]
Where profile_identity is not NULL
and convert(date,left(ts,8),106) >= '2021-01-01'
and convert(date,left(ts,8),106) <= '2021-02-28'
and Clicked_on like '%30 days ARQ Prime%'
)ab
----use communication select * from AM_ONR_Bundled

Select offer_name ,Concat(offer_message_what,' ',offer_message_howmuch,' ',offer_message_action) as merdge,created_by 
Into #AJ_Metadata
From [OnlineEngine].[dbo].[AJ_Offers_Metadata]
where created_by like '%sapna%'
and offer_message_howmuch like '%ARQ%'

select * From [OnlineEngine].[dbo].[AJ_Offers_Metadata]

------Select * from #AJ_Metadata
----drop table #AJ_Metadata

----drop table #AM_Click
select * into #AM_Click 
from (select distinct Clicked_on, profile_identity, Click_Date from #AJ_OffersClick
left join #AJ_Metadata 
on clicked_on like merdge + '%'
) abc


drop table #tempA 
Select * into #tempA from
	(SELECT  distinct ClientCode,
		   convert(date,ConsentDate,106) as DateofPurchase
		  ,[VoucherPlanOpted]
		  ,[OrderLimit]
		  ,[ARQActivated]
		  ,[No_of_trades_after_plan_activated]
		  ,[SubSource]
	  FROM [OnlineEngine].[dbo].[VW_Bundled_Plan_ClientInfo] A
	  join #AM_Click B
	  on A. ClientCode = B.profile_identity
	  and convert(date,A.ConsentDate,106) = B.Click_date
	  and convert(date,ConsentDate,106) between '2021-01-01' and '2021-01-31') ab

insert into AM_OnR_Bundled
select * from #tempA

-------Total Bundled offers conversions MOM-------
Select month(consentdate), count(distinct clientcode) from [OnlineEngine].[dbo].[VW_Bundled_Plan_ClientInfo]
group by month(consentdate)

--select * from #tempA

select distinct(subsource), count(subsource) from #tempA
group by subsource

---------
insert into AM_OnR_Bundled
Select * from #tempA

---select * from AM_OnR_Bundled
--------- Use This QUERY ---------------------
select * from [OnlineEngine].[dbo].[VW_Bundled_Plan_ClientInfo] 
 where cast (consentdate as date) >='2021-02-01'
and cast (consentdate as date) <='2021-02-28'
 and SubSource like 'onr'
 
 select * from [OnlineEngine].[dbo].[VW_Bundled_Plan_ClientInfo] 
 where ConsentDate>='2021-02-01' and consentdate<='2021-02-28'

 ---- day wise data ------
 select cast (consentdate as date),count(clientcode) from [OnlineEngine].[dbo].[VW_Bundled_Plan_ClientInfo]
 where  SubSource like 'onr'
and cast (consentdate as date) >='2021-02-01'
group by cast (consentdate as date)
order by cast (consentdate as date) asc
 

 select * from AM_OnR_Bundled
 where cast (DateofPurchase as date) >='2021-02-01'
 and cast (DateofPurchase as date) <='2021-02-15'

use OnlineEngine 
Create Table AM_OnR_Bundled
(party_code varchar(40),DateofPurchase datetime,VoucherPlanOpted int,OrderLimit int,
ARQActivated int, No_of_trades_after_plan_activated int,SubSource varchar(40))



Select month(DateofPurchase) , COUNT(distinct ClientCode) from #tempA
group by month(DateofPurchase)


/*Select month(consentdate),count(distinct clientcode) from [OnlineEngine].[dbo].[VW_Bundled_Plan_ClientInfo]
group by month(consentdate)
order by month(consentdate) */

select * from [OnlineEngine].[dbo].[VW_Bundled_Plan_ClientInfo]


use communication
select * from [Communication].[dbo].[RG_CampaignSet] where Execution_Date>='2021-02-01' and Execution_Date<='2021-02-23'
order by Execution_Date asc

select top 10 * from [OnlineEngine].[dbo].[AJ_OffersCardClick_updated] 
where convert(date,left(ts,8),106) >= '2021-02-01' order by ts 
