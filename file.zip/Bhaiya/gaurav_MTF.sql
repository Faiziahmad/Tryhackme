	select top 10 * from  [onlineengine].[dbo].[VW_MTF_Plan_ClientInfo]
[196.1.115.167].KYC.dbo.VW_Campaign_Consent_ALL with(nolock)

with Revenue_OnR(Clientcode, PushedSource) as
(
Select ClientCode, PushedSource
From [196.1.115.167].KYC.dbo.VW_Campaign_Consent_ALL with(nolock)
Where Clientcode in (Select clientcode from [onlineengine].[dbo].[VW_MTF_Plan_ClientInfo]) and Pushedsource = 'onr'and CampaignType = 'MTFPLAN'
)
Select B.consentDate, A.Clientcode, Pushedsource, B.VoucherPlanOpted
From Revenue_OnR as A inner join [onlineengine].[dbo].[VW_MTF_Plan_ClientInfo] as B
on A.ClientCode = B.ClientCode
Where cast(B.consentDate as Date) between '2021-06-01' and '2021-06-30'

select * from [onlineengine].[dbo].[VW_MTF_Plan_ClientInfo]

select * from [196.1.115.167].KYC.dbo.VW_Campaign_Consent_ALL/l

select distinct campaigntype from [196.1.115.167].KYC.dbo.VW_Campaign_Consent_ALL where campaigntype like 
'%MTF%'

'MTFBUNDLED'

select distinct campaigntype from [196.1.115.167].KYC.dbo.VW_Campaign_Consent_ALL 
where campaigntype like '%INT%'

--------------------------------------------------------------------------
with Revenue_OnR(Clientcode, PushedSource) as
(
Select ClientCode, PushedSource
From [196.1.115.167].KYC.dbo.VW_Campaign_Consent_ALL with(nolock)
Where Clientcode in (Select clientcode from [onlineengine].[dbo].[VW_MTF_Plan_ClientInfo]) and Pushedsource = 'onr'and CampaignType = 'MTFPLAN'
)
Select B.consentDate, A.Clientcode, Pushedsource, B.VoucherPlanOpted
From Revenue_OnR as A inner join [onlineengine].[dbo].[VW_MTF_Plan_ClientInfo] as B
on A.ClientCode = B.ClientCode
Where cast(B.consentDate as Date) between '2021-05-01' and '2021-06-30'

---------------------------------------------------------------------------------------------------
drop table #uniqueclicks
Select DateAdd(Day,1,EOMonth(creationdate,-1)) as Months, Count(distinct ClientCode) as Clicks
into #uniqueclicks
FROM [196.1.115.167].KYC.dbo.VW_Campaign_Consent_ALL
Where CampaignType IN ('MTFPLAN','SCMTFPLAN99') and pushedsource = 'onr'
Group by DateAdd(Day,1,EOMonth(creationdate,-1))
Order by DateAdd(Day,1,EOMonth(creationdate,-1))
drop table #uniqueconverted
select DateAdd(Day,1,EOMonth(consentdate,-1)) as Months,
       count(case when voucherplanopted = 99 then a.ClientCode End)as Plan1,
	   count(case when voucherplanopted = 249 then a.ClientCode End)as Plan2,
	   count(case when voucherplanopted = 499 then a.ClientCode End)as Plan3,
	   count(case when voucherplanopted = 999 then a.ClientCode End)as Plan4,
	   count (a.clientcode) as Total,
	   Sum (VoucherPlanOpted) as Total_Revenue
	   into #uniqueconverted
From [onlineengine].[dbo].[VW_MTF_Plan_ClientInfo] as A 
Left join [196.1.115.167].KYC.dbo.VW_Campaign_Consent_ALL as B
on A.Clientcode = B. Clientcode
WHERE b.CampaignType In ('MTFPLAN','SCMTFPLAN99') and pushedsource = 'onr'
Group by DateAdd(Day,1,EOMonth(consentdate,-1))
order by DateAdd(Day,1,EOMonth(consentdate,-1))
Select A.Months, B.Clicks, Plan1 as '99', Plan2 as '249', Plan3 as '499', Plan4 as '999', Total, Total_Revenue
From #uniqueconverted as A
inner join #uniqueclicks as B
on A.Months = B.Months


with Revenue_OnR(Clientcode, PushedSource) as
(
Select ClientCode, PushedSource
From [196.1.115.167].KYC.dbo.VW_Campaign_Consent_ALL with(nolock)
Where Clientcode in (Select clientcode from [onlineengine].[dbo].[VW_MTF_Plan_ClientInfo]) and Pushedsource = 'onr'and CampaignType in ('MTFPLAN','SCMTFPLAN99')
)
Select B.consentDate, A.Clientcode, Pushedsource, B.VoucherPlanOpted
From Revenue_OnR as A inner join [onlineengine].[dbo].[VW_MTF_Plan_ClientInfo] as B
on A.ClientCode = B.ClientCode
Where cast(B.consentDate as Date) between '2021-06-01' and '2021-06-30'

select convert(date,consentdate) as Dates,
       count(case when voucherplanopted = 99 then a.ClientCode End)as '99',
	   count(case when voucherplanopted = 249 then a.ClientCode End)as '249',
	   count(case when voucherplanopted = 499 then a.ClientCode End)as '499',
	   count(case when voucherplanopted = 999 then a.ClientCode End)as '999',
	   count(case when voucherplanopted = 1499 then a.ClientCode End)as '1499',
	   count (a.clientcode) as Total,
	   Sum (VoucherPlanOpted) as Total_Revenue
From [onlineengine].[dbo].[VW_MTF_Plan_ClientInfo] as A 
Left join [196.1.115.167].KYC.dbo.VW_Campaign_Consent_ALL as B
on A.Clientcode = B. Clientcode
WHERE b.CampaignType In ('MTFPLAN','SCMTFPLAN99') and pushedsource = 'onr'
Group by convert(date,consentdate)
order by convert(date,consentdate) desc


select * from #margin

select * into #margin from
(select ClientCode,c.*
from [196.1.115.167].kyc.[dbo].TBL_CAMPAIGN_MarginFunding_InterestFree c with(nolock)
INNER JOIN [196.1.115.167].kyc.[dbo].[tbl_Campaign_ClientInfo] a with(nolock) on c.ClientId = a.ClientId
where  c.CampaignType = 'INTFREEMAR_50000' and
cast(c.CreatedDate as date) >= '2021-06-19'
and cast(c.CreatedDate as date) <= '2021-06-30')abc

select * from #marginonrvisit 
select * into #marginonrvisit from
(select * from [OnlineEngine].[dbo].[AJ_OffersCardClick_updated]
where convert(date,left(ts,8),106)>= '2021-06-21'
and convert(date,left(ts,8),106)<= '2021-06-30'
and clicked_on like '%0 Interest MTF for 7 days%') abd

Datewise conversion
select * into #marginonrconversion from
(select distinct clientcode,campaigntype,cast(CreatedDate as date) as createddate,profile_identity,convert(date,left(ts,8),106) as dt
from #margin a, #marginonrvisit b
where a.clientcode=b.profile_identity
--and cast(a.CreatedDate as date)=convert(date,left(b.ts,8),106)
and cast(a.CreatedDate as date) >= '2021-06-19'
and cast(a.CreatedDate as date) <= '2021-06-30') abe
order by createddate asc

select * from #marginonrconversion

select createddate,count(distinct clientcode) from #marginonrconversion
group by createddate


Select Party_code, MTFactivedate as convertdate,
       cast(Max(Campaign_Open_Date) as Date) as ClickDate
From
(
Select distinct Campaign_Open_Date, C.Party_code,  MTFactivedate,
       Case when MTFactivedate in (Select Tradingday From (Select cast(Tradingday as date) as Tradingday, ROW_NUMBER()
                                   OVER ( PARTITION BY datename(yy,month) order by TradingDay ) as rank
                                   from Onlineengine.dbo.SN_Tradingdays where TradingDay >= Campaign_Open_Date
                                   ) as G where rank = 2)
	        then 'Convert'
	        when MTFactivedate in (Select Tradingday From (Select cast(Tradingday as date) as Tradingday, ROW_NUMBER()
                                   OVER ( PARTITION BY datename(yy,month) order by TradingDay ) as rank
                                   from Onlineengine.dbo.SN_Tradingdays where TradingDay >= Campaign_Open_Date
                                   ) as G where rank = 3)
	        then 'Convert' End as Converted
From
(
Select Campaign_Open_Date,Party_Code
From Communication.dbo.NN_MTF_Aware_Inactive
) as C
inner join
(
Select Party_Code, Cast(min(balancedate) as Date) as MTFActiveDate
From Onlineengine.dbo.SN_DaywiseDPC
where Party_Code in (Select distinct Party_Code From Communication.dbo.NN_MTF_Aware_Inactive
              )
Group by party_code
) as D
on C.party_code = D.party_code
Group by Campaign_Open_Date, C.Party_code, MTFactivedate
) as E
where converted = 'convert'
and Party_code not in (Select Party_code From Communication.dbo.KG_ConversionsTable with(nolock))
Group by Party_code, MTFactivedate, converted



Select Party_Code, MTFactivedate as convertdate, cast(Max(Clickdate) as Date) as Datelateclick
From
(
Select distinct Clickdate, C.party_code,  MTFactivedate,
       Case when MTFactivedate in (Select Tradingday From (Select cast(Tradingday as date) as Tradingday, ROW_NUMBER()   
                                   OVER ( PARTITION BY datename(yy,month) order by TradingDay ) as rank 
                                   from Onlineengine.dbo.SN_Tradingdays where TradingDay >= clickdate
                                   ) as G where rank = 2)
	        then 'Convert'
	        when MTFactivedate in (Select Tradingday From (Select cast(Tradingday as date) as Tradingday, ROW_NUMBER()   
                                   OVER ( PARTITION BY datename(yy,month) order by TradingDay ) as rank 
                                   from Onlineengine.dbo.SN_Tradingdays where TradingDay >= clickdate
                                   ) as G where rank = 3)
	        then 'Convert' End as Converted
From
(
Select convert(date,left(ts,8),106) as ClickDate, profile_identity as party_code from Onlineengine.dbo.AJ_OffersCardClick_updated
Where Clicked_on like 'On Your next Margin Trade 0 Interest MTF for 7 days on Funding upto Rs.50000'
) as C
inner join
(
Select Party_Code, Cast(min(balancedate) as Date) as MTFActiveDate
From Onlineengine.dbo.SN_DaywiseDPC
where party_code in (Select distinct party_code From Onlineengine.dbo.AJ_OffersCardClick_updated 
              )
Group by party_code
) as D
on C.party_code = D.party_code
Group by clickdate, C.Party_code, MTFactivedate
) as E
where converted = 'convert'
and Party_code not in (Select Party_code From Communication.dbo.KG_ConversionsTable with(nolock)) 
Group by Party_code, MTFactivedate, converted



----Margin Conversion and Revenue ---

drop table #50krevenue
select * into #50krevenue from
(Select * from Onlineengine.dbo.SN_DaywiseDPC
Where Party_Code in (
Select profile_identity as party_code from OnlineEngine.dbo.AJ_OffersCardClick_updated
Where Clicked_on like 'On Your next Margin Trade 0 Interest MTF for 7 days on Funding upto Rs.25000'
and convert(date,left(ts,8),106) > '2020-04-01')
and BalanceDate > '2021-06-01'
and Party_code not in (Select Party_code From Communication.dbo.KG_ConversionsTable with(nolock)))ae

Select * from Onlineengine.dbo.SN_DaywiseDPC
Where Party_Code in (
Select profile_identity as party_code from OnlineEngine.dbo.AJ_OffersCardClick_updated
Where Clicked_on like 'On Your next Margin Trade 0 Interest MTF for 7 days on Funding upto Rs.50000'
and convert(date,left(ts,8),106) > '2020-04-01')
and BalanceDate > '2021-06-01'
and Party_code not in (Select Party_code From Communication.dbo.KG_ConversionsTable with(nolock))
and party_code not in (Select Party_code From #50krevenue)