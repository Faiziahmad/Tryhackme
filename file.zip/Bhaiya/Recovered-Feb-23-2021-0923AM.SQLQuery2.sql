use onlineengine
select * from AJ_Offers_Metadata where offer_name like 'ARQ%'
expiry_date>='2021-02-17'
--where expiry_date>='T'

select count(*) as count,created_by from aj_offers_metadata
group by created_by
order by count desc

use onlineengine

select top 10 * from aj_fundtransfersource

select distinct status from aj_fundtransfersource

select * from aj_offers_metadata

use onlineengine

select top 10 * from SH_API_Automation_Reporting where parentAPI='offersAndRewards' and 

SELECT TOP 10 * FROM [196.1.115.132].EBroking.dbo.tbl_all_tradeFile_hist WITH (NOLOCK)
where sdate='19/02/2021'