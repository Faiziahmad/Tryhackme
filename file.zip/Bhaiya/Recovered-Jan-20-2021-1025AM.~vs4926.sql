use onlineengine

select top 100 * from [dbo].[CT_clicked] where convert(datetime,stuff(stuff(stuff(ts, 9, 0, ' '), 12, 0, ':'), 15, 0, ':'))>='2021-01-14 00:00:00'


select top 10 profile_identity, convert(datetime,stuff(stuff(stuff(ts, 9, 0, ' '), 12, 0, ':'), 15, 0, ':')) as clicktime
from [dbo].[CT_clicked]
where utm_campaign = '21767' or utm_campaign ='21768'
group by profile_identity, convert(datetime,stuff(stuff(stuff(ts, 9, 0, ' '), 12, 0, ':'), 15, 0, ':')) 


select top 100 * from [dbo].[CT_clicked] where campaign_type='Email' and convert(datetime,stuff(stuff(stuff(ts, 9, 0, ' '), 12, 0, ':'), 15, 0, ':'))>='2021-01-14 00:00:00'
and profile_identity='S516409'

where convert(datetime,stuff(stuff(stuff(ts, 9, 0, ' '), 12, 0, ':'), 15, 0, ':'))>='2021-01-14 00:00:00'


select top 100 * from dbo.CleverTap_tbl_CleverTapEventDataBroking

select * from dbo.CT_Campaign where channel='Email'

select * from dbo.CleverTap_tbl_CleverTapEvents