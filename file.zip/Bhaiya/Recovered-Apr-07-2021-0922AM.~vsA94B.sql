Select distinct profile_identity,Clicked_on,ts,convert(date,left(ts,8),106) as Click_Date,
convert(datetime,stuff(stuff(stuff(ts, 9, 0, ' '), 12, 0, ':'), 15, 0, ':')) as Click_DateTime From [OnlineEngine].[dbo].[AJ_OffersCardClick_updated]
--convert(datetime,stuff(stuff(stuff(ts, 9, 0, ' '), 12, 0, ':'), 15, 0, ':')) as Click_DateTime From [OnlineEngine].[dbo].[AJ_OffersCardClick]
Where profile_identity is not NULL
and Clicked_on like '%Sensibull%'
and convert(date,left(ts,8),106) >= '2021-03-01'
and convert(date,left(ts,8),106) <= '2021-03-31'
             