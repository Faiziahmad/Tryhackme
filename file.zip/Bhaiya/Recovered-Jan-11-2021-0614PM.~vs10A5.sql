use onlineengine
select top 100 * from SN_ClientKYC

select * from trade