Use OnlineEngine

drop table #temp_OnB_Campaigns
drop table #temp_othercampaigns
drop table #temp_WA_Campaigns
drop table #temp_users


select party_code, PartyCode_GenDate, Activefrom into #temp_users
from SN_clientkyc
where B2C = 'Y' and Activefrom >= '2020-01-01' and Activefrom < getdate()



select A.profile_identity, A.ts, A.utm_medium ,B.Activefrom, DATEDIFF(DAY,B.Activefrom, cast(A.ts as date)) as TAT into #temp_othercampaigns
from
(select profile_identity, convert(datetime,stuff(stuff(stuff(ts, 9, 0, ' '), 12, 0, ':'), 15, 0, ':')) as ts, utm_medium
from CT_clicked with (nolock)
where utm_campaign in (select CampaignID from AD_OnB_other_Campaigns) and profile_identity in (select party_code from #temp_users)
and convert(datetime,stuff(stuff(stuff(ts, 9, 0, ' '), 12, 0, ':'), 15, 0, ':')) >= '2020-01-01') A
left join
(select party_code, PartyCode_GenDate, Activefrom
from #temp_users) B
on A.profile_identity = B.Party_Code


select A.profile_identity, A.ts, A.utm_medium , B.Activefrom, DATEDIFF(DAY,B.Activefrom, cast(A.ts as date)) as TAT into #temp_OnB_Campaigns
from
(select profile_identity, convert(datetime,stuff(stuff(stuff(ts, 9, 0, ' '), 12, 0, ':'), 15, 0, ':')) as ts, utm_medium
from CT_clicked with (nolock)
where utm_campaign in (select CampaignID from CT_campaign where ActionID in (1,2,3)) and profile_identity in (select party_code from #temp_users)
and convert(datetime,stuff(stuff(stuff(ts, 9, 0, ' '), 12, 0, ':'), 15, 0, ':')) >= '2020-01-01') A
left join
(select party_code, PartyCode_GenDate, Activefrom
from #temp_users) B
on A.profile_identity = B.Party_Code


select A.Party_code, A.URLClickDate, A.utm_medium, B.Activefrom, DATEDIFF(DAY,B.Activefrom, cast(A.URLClickDate as date)) as TAT into #temp_WA_Campaigns
from
(SELECT Party_code, MsgIdentity, URLClickDate, cast('Whatsapp' as varchar(40)) as utm_medium
FROM [Communication].[dbo].[KP_WA_OB_Messages_Clicks_Logs] with (nolock)
where URLClickDate!='1900-01-01 00:00:00.000' and URLClickDate >= '2020-01-01' and Party_code in (select party_code from #temp_users)) A
left join
(select party_code, PartyCode_GenDate, Activefrom
from #temp_users) B
on A.Party_Code = B.Party_Code

drop table AD_OnB_Campaigns_Engagement
drop table AD_OnB_Other_Campaigns_Engagement
drop table AD_OnB_WA_Campaigns_Engagement

select * into AD_OnB_Campaigns_Engagement from #temp_OnB_Campaigns
select * into AD_OnB_Other_Campaigns_Engagement from #temp_othercampaigns
select * into AD_OnB_WA_Campaigns_Engagement from #temp_WA_Campaigns
