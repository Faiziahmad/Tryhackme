use OnlineEngine_Team

--select top 10 * from onlineengine.dbo.sn_clientkyc with (nolock)
--select top 10 * from onlineengine.dbo.AS_OrderCountData with (nolock)
--select top 10 * from OnlineEngine.dbo.SN_SalesSource_Intent
--select top 10 * from onlineengine.dbo.DK_DaysoftradingfromDate_all

Select * into #TempAcq from 
(
Select distinct Party_code, convert(date,Activefrom,106) Activefrom,  DateAdd(Day,1,EOMonth(activefrom,-1)) as ACqMonth, 
AcqWeek = Datepart(week, Activefrom),
firsttrade, 
SourceName = Cast(case when branch_cd in ('RFRL') and ActiveFrom >='2019-07-01' then 'DRA' else 'B2C' end as varchar(100)),
Channel = Cast(NULL as varchar(100)),
Campaign = Cast(NULL as varchar(100))
from onlineengine.dbo.sn_clientkyc with (nolock)
where b2c = 'y' 
and Activefrom >= '2020-04-01' 
and activefrom < '2021-06-01'
)AA



------- update channel in table -------------------------------------------
update a
set a.Channel=b.Channel, a.campaign=b.campaign
from #TempAcq a, OnlineEngine.dbo.SN_SalesSource_Intent b
where a.party_code=b.party_code
and a.Channel is null and a.Activefrom>='2020-01-01'

update #TempAcq 
set sourcename='DRA'
where Activefrom>='2020-04-01' and sourcename='B2C' and channel='DRA' 

update #TempAcq
set sourcename='B2C'
where Activefrom>='2020-04-01' and channel <>'DRA' 

update #TempAcq
set Channel='Online' 
where SourceName='B2C' and Activefrom>='2020-01-01' and Channel in ('Other')  and Campaign is not null

update #TempAcq
set campaign = 'Referral', Channel='Referral'
where campaign is null and Activefrom>='2020-01-01' and SourceName='B2C' 

----check
--select distinct SourceName, channel, campaign  from #TempAcq where Activefrom>='2020-01-01'
--order by SourceName, channel, campaign

----------- Revenue Data ------------------------------------------------
----------- Completed Months Revenue Data ----------------

Select 
Acqmonth, sourcename, Campaign, Channel
DayofTrading, 
MonthTrading = (DayofTrading-1) / 20,
count(distinct(A.party_code)) clients, 
sum(OC) ordercounts, 
sum(T_O)/10000000 turnover,  
cast(sum(brokerage)/100000 as float) as rev, 
count(distinct (sauda_date)) as daystradedavailable
into #Rev_Mth
from
	(select party_code, sauda_Date, T_O, OC, brokerage from onlineengine.dbo.AS_OrderCountData with (nolock)
	where Inst_Type is not null 
	) A, 
#TempAcq B, onlineengine.dbo.DK_DaysoftradingfromDate_all C
where B.activefrom = C.DateList
and C.TradingDay = A.sauda_date
and A.party_code = b.party_code
and acqmonth < '2021-05-01'
Group by Acqmonth, sourcename, Channel, Campaign


-------------Revenue data for last month clients ------------------------
Select Acqmonth, b.activefrom, sourcename, Campaign, Channel,
DayofTrading, 
MonthTrading = (DayofTrading-1) / 20,
count(distinct(A.party_code)) clients, 
sum(OC) ordercounts, 
sum(T_O)/10000000 turnover,  
cast(sum(brokerage)/100000 as float) as rev, 
count(distinct (sauda_date)) as daystradedavailable
into #CurrMthRev
from 
	(select party_code, sauda_Date, T_O, OC, brokerage from onlineengine.dbo.AS_OrderCountData 
	where Inst_Type is not null 
	) A, 
#TempAcq B, onlineengine.dbo.DK_DaysoftradingfromDate_all C
where B.activefrom = C.DateList
and C.TradingDay = A.sauda_date
and A.party_code = b.party_code
and acqmonth >= '2021-04-01' and Acqmonth < '2021-06-01'
Group by Acqmonth, b.activefrom, sourcename, Campaign, Channel


-------------*****************************************************************************----------------
-------------*****************************************************************************----------------
---- data for EXCEL calculations
--Revenue data
select Acqmonth,  sourcename, MonthTrading, channel, SUM(rev) Rev--, SUM(ordercounts) ordercounts, SUM(turnover) turnover 
from #RevMth
where Acqmonth >='2020-01-01' and sourcename='B2C'
group by Acqmonth, channel, sourcename, MonthTrading

--- Clients
Select Acqmonth,  sourcename, channel, COUNT(Distinct party_code) Clients from #TempAcq 
where ACqMonth>='2020-01-01' and SourceName='B2C' and channel is not null
group by Acqmonth,  sourcename, channel

--Revenue data Latest month
select Acqmonth, activefrom, sourcename, DayofTrading, channel, max(daystradedavailable) daystradedavailable,
	 SUM(rev) Rev, SUM(ordercounts) ordercounts, SUM(turnover) turnover 
from #CurrMthRev
where Activefrom >='2021-05-01'
group by Acqmonth, activefrom, sourcename, channel, DayofTrading

--- Clients Latest Month
Select Acqmonth, activefrom, sourcename, channel, COUNT(Distinct party_code) Clients from #TempAcq 
where ACqMonth>='2021-05-01' and SourceName='B2C' and channel is not null
group by Acqmonth,  sourcename, channel


drop table #TempAcq
drop table #Rev_Mth
drop table #CurrMthRev


select cltcode,sum( case when drcr = 'C' then VAMT else -VAMT end) as Amount 
from [196.1.115.196].[ACCOUNT].dbo.LEDGER	with (NOLOCK) where ltrim(rtrim(cltcode)) = 'S516409' 
and VDT >= '2021-04-01' group by cltcode

select top 10 * from [196.1.115.196].[ACCOUNT].dbo.LEDGER	with (NOLOCK) 

select vdt,drcr,vamt from [196.1.115.196].[ACCOUNT].dbo.LEDGER	with (NOLOCK) 
where ltrim(rtrim(cltcode)) = 'S516409' 
and VDT >= '2020-04-01'
