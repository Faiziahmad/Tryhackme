use OnlineEngine

/*** Get party code details***/
select A.Party_Code, A.ActiveFrom as Partycode_gendate, 
case when B.Channel in ('Referral', 'DRA') then B.Channel
     when B.Channel in ('Online') then 
	 (case when B.Campaign in ('ABMA_Organic', 'Web') then 'Organic'
	 else 'Paid' end) end as Campaign into #temp
from SN_clientkyc A left join SN_SalesSource_Intent B
on A.Party_Code = B.Party_code
where A.ActiveFrom >= '2020-04-01' and A.ActiveFrom < getdate()
and A.B2C = 'Y'


update #temp
set Campaign = 'Referral'
where Campaign is null

alter table #temp
add Sauda_date datetime, Activation_Cat varchar(40)

update A
set Sauda_date = B.Sauda_time
from #temp A,
(select party_code, min(cast(sauda_date as datetime) + cast(MinsaudaTime as datetime)) as Sauda_time from SN_MinSaudaTime group by party_code) B
where A.Party_Code = B.party_code



/*** Get activation category ***/
update A
set Activation_Cat = case when cast(A.sauda_date as date) = B.Day0 then 'Day0'
						when cast(A.sauda_date as date) = B.Day1 then 'Day1'
						when cast(A.sauda_date as date) = B.Day2 then 'Day2'
						when cast(A.sauda_date as date) = B.Day3 then 'Day3'
						when cast(A.sauda_date as date) = B.Day4 then 'Day4'
						when cast(A.sauda_date as date) = B.Day5 then 'Day5'
						when cast(A.sauda_date as date) = B.Day6 then 'Day6'
						when cast(A.sauda_date as date) = B.Day7 then 'Day7'
						when cast(A.sauda_date as date) = B.Day8 then 'Day8'
						when cast(A.sauda_date as date) = B.Day9 then 'Day9'
						when cast(A.sauda_date as date) = B.Day10 then 'Day10'
						when cast(A.sauda_date as date) = B.Day11 then 'Day11'
						when cast(A.sauda_date as date) = B.Day12 then 'Day12'
						when cast(A.sauda_date as date) = B.Day13 then 'Day13'
						when cast(A.sauda_date as date) = B.Day14 then 'Day14'
						when cast(A.sauda_date as date) = B.Day15 then 'Day15'
						when cast(A.sauda_date as date) > B.Day15 and cast(A.sauda_date as date) <= B.Day30 then 'Day30' 
						when cast(A.sauda_date as date) > B.Day30 then 'Day30+'
						else 'Not Traded' end
from #temp A, AD_trading_day_final B
where cast(A.PartyCode_GenDate as date) = B.OnB_date 


select format(partycode_gendate, 'yyyy-MM-dd') as Dates,
Campaign, count(party_code) as Users into #temp3
from #temp
where Partycode_gendate <getdate()
--where format(partycode_gendate, 'yyyy-MM') = format(getdate(), 'yyyy-MM')
group by format(partycode_gendate, 'yyyy-MM-dd'), Campaign
order by format(partycode_gendate, 'yyyy-MM-dd') desc

-- select * from #temp


select format(partycode_gendate, 'yyyy-MM-dd') as Dates,
Activation_cat,campaign, count(party_code) as Users into #temp8
from #temp
where Activation_Cat not in ('Day30+', 'Not Traded') and Partycode_gendate <getdate()
--and format(partycode_gendate, 'yyyy-MM') = format(getdate(), 'yyyy-MM')
group by format(partycode_gendate, 'yyyy-MM-dd'), Activation_Cat, campaign
order by format(partycode_gendate, 'yyyy-MM-dd') desc

-- select * from #temp8 order by Dates asc

select AAA.Dates, AAA.Users,
round(cast(BBB.Day0 as float)*100.00/ cast(AAA.Users as float),1)  as Day0, 
round(cast(BBB.Day1 as float)*100.00/ cast(AAA.Users as float),1)  as Day1, 
round(cast(BBB.Day2 as float)*100.00/ cast(AAA.Users as float),1)  as Day2, 
round(cast(BBB.TillDay2 as float)*100.00/ cast(AAA.Users as float),1)  as TillDay2, 
round(cast(BBB.Day3 as float)*100.00/ cast(AAA.Users as float),1)  as Day3,
round(cast(BBB.Day4 as float)*100.00/ cast(AAA.Users as float),1)  as Day4,
round(cast(BBB.Day5 as float)*100.00/ cast(AAA.Users as float),1)  as Day5,
round(cast(BBB.Day6 as float)*100.00/ cast(AAA.Users as float),1)  as Day6,
round(cast(BBB.Day7 as float)*100.00/ cast(AAA.Users as float),1)  as Day7,
round(cast(BBB.TillDay7 as float)*100.00/ cast(AAA.Users as float),1)  as TillDay7,
round(cast(BBB.Day8 as float)*100.00/ cast(AAA.Users as float),1)  as Day8,
round(cast(BBB.Day9 as float)*100.00/ cast(AAA.Users as float),1)  as Day9,
round(cast(BBB.Day10 as float)*100.00/ cast(AAA.Users as float),1)  as Day10,
round(cast(BBB.Day11 as float)*100.00/ cast(AAA.Users as float),1)  as Day11,
round(cast(BBB.Day12 as float)*100.00/ cast(AAA.Users as float),1)  as Day12,
round(cast(BBB.Day13 as float)*100.00/ cast(AAA.Users as float),1)  as Day13,
round(cast(BBB.Day14 as float)*100.00/ cast(AAA.Users as float),1)  as Day14,
round(cast(BBB.Day15 as float)*100.00/ cast(AAA.Users as float),1)  as Day15,
round(cast(BBB.TillDay15 as float)*100.00/ cast(AAA.Users as float),1)  as TillDay15,
round(cast(BBB.TillDay30 as float)*100.00/ cast(AAA.Users as float),1)  as TillDay30
from 
(select A.Dates, (A.Referral+A.Organic+A.Paid+A.DRA) as Users
from 
(select Dates,[Organic],[Paid],[Referral],[DRA]
from #temp3 
pivot(
		sum(Users)
		for [Campaign]
		IN ([Organic],[Paid],[Referral],[DRA])
  ) As PivotTable) A) AAA
left join
(select AA.Dates,isnull(AA.Day0,0) as Day0, isnull(AA.Day1,0) as Day1, isnull(AA.Day2,0) as Day2, isnull(AA.Day0,0) + isnull(AA.Day1,0) + isnull(AA.Day2,0) as TillDay2,
	isnull(AA.Day3,0) as Day3, isnull(AA.Day4,0) as Day4, isnull(AA.Day5,0) as Day5, isnull(AA.Day6,0) as Day6, isnull(AA.Day7,0) as Day7,
	isnull(AA.Day0,0)+ isnull(AA.Day1,0)+ isnull(AA.Day2,0)+isnull(AA.Day3,0)+isnull(AA.Day4,0)+ isnull(AA.Day5,0)+ isnull(AA.Day6,0)+ isnull(AA.Day7,0) as TillDay7,
	isnull(AA.Day8,0) as Day8, isnull(AA.Day9,0) as Day9, isnull(AA.Day10,0) as Day10,isnull(AA.Day11,0) as Day11,isnull(AA.Day12,0) as Day12, isnull(AA.Day13,0) as Day13, isnull(AA.Day14,0) as Day14, isnull(AA.Day15,0) as Day15,
    isnull(AA.Day0,0)+ isnull(AA.Day1,0)+ isnull(AA.Day2,0)+isnull(AA.Day3,0)+isnull(AA.Day4,0)+ isnull(AA.Day5,0)+ isnull(AA.Day6,0)+ isnull(AA.Day7,0)
	+isnull(AA.Day8,0)+ isnull(AA.Day9,0)+ isnull(AA.Day10,0)+isnull(AA.Day11,0)+isnull(AA.Day12,0)+ isnull(AA.Day13,0)+ isnull(AA.Day14,0)+ isnull(AA.Day15,0) as TillDay15,
	isnull(AA.Day0,0)+ isnull(AA.Day1,0)+ isnull(AA.Day2,0)+isnull(AA.Day3,0)+isnull(AA.Day4,0)+ isnull(AA.Day5,0)+ isnull(AA.Day6,0)+ isnull(AA.Day7,0)
	+isnull(AA.Day8,0)+ isnull(AA.Day9,0)+ isnull(AA.Day10,0)+isnull(AA.Day11,0)+isnull(AA.Day12,0)+ isnull(AA.Day13,0)+ isnull(AA.Day14,0)+ isnull(AA.Day15,0)+ isnull(AA.Day30,0) as TillDay30 
from 
(select Dates,[Day0],[Day1],[Day2],[Day3],[Day4],[Day5],[Day6], 
		[Day7],[Day8],[Day9],[Day10],[Day11],[Day12],[Day13],
		[Day14],[Day15], [Day30]
from (select Dates, Activation_cat, sum(Users) as Users from #temp8 group by Dates, Activation_cat) A
pivot(
		sum(Users)
		for [Activation_cat]
		IN ([Day0],[Day1],[Day2],[Day3],[Day4],[Day5],[Day6], 
		[Day7],[Day8],[Day9],[Day10],[Day11],[Day12],[Day13],
		[Day14],[Day15], [Day30])
  ) As PivotTable) AA) BBB
on AAA.Dates = BBB.Dates
where AAA.Dates < cast(GETDATE() as date)
order by AAA.Dates desc


drop table #temp
drop table #temp3
drop table #temp8