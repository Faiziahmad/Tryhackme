use onlineengine
select cast(convert(datetime,stuff(stuff(stuff(ts, 9, 0, ' '), 12, 0, ':'), 15, 0, ':')) as Date) as ts,  count(distinct profile_identity) as EngagedUsers
from CT_clicked
where utm_campaign in (7110)
and cast(convert(datetime,stuff(stuff(stuff(ts, 9, 0, ' '), 12, 0, ':'), 15, 0, ':')) as Date) >= '2020-04-01'
group by cast(convert(datetime,stuff(stuff(stuff(ts, 9, 0, ' '), 12, 0, ':'), 15, 0, ':')) as Date)
order by cast(convert(datetime,stuff(stuff(stuff(ts, 9, 0, ' '), 12, 0, ':'), 15, 0, ':')) as Date) desc