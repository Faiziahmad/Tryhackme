USE onlineengine
SELECT *
INTO #result
FROM OPENQUERY([172.31.16.85], 'EXEC ABR_DW.dbo.usp_GetIPOPaymentPendingData Sonacoms;');

insert into #result
FROM OPENQUERY([172.31.16.85], 'EXEC ABR_DW.dbo.usp_GetIPOPaymentPendingData Sonacoms;');

select * from #result

SELECT * FROM 

INSERT INTO #result(IPO_Code,ClientID,ApplicationNo,BankRefNo,AllotmentStatus,ApplicationDateTime,SponsorBankPayStatus)
SELECT IPO_Code,ClientID,ApplicationNo,BankRefNo,AllotmentStatus,ApplicationDateTime,SponsorBankPayStatus
FROM OPENQUERY([172.31.16.85], 'EXEC ABR_DW.dbo.usp_GetIPOPaymentPendingData SHYMMETAL;');



select LogDate, ClientCode, control_flag2
from [196.1.115.167].[KYC_CI].dbo.[VW_Campaign_ClientInfo] with (nolock)
where control_flag2 = '2' and LogDate>= '2021-05-25' AND B2bOrB2c = 'Y'

insert into #result
EXEC [ServerName] .dbname.scheme.StoredProcedureName

EXEC [172.31.16.85].ABR_DW.dbo.usp_GetIPOPaymentPendingData 'SHYMMETAL'


insert into #result
EXEC [172.31.16.85].ABR_DW.dbo.usp_GetIPOPaymentPendingData 'Sonacoms' 

with raw_data as
(SELECT SPLIT_PART(event_metadata, '"', 4) as Reasons, replace(split_part(split_part(event_metadata,':',2),',',1),'"') as IPO_name,
dt,event_id,event_name,count(distinct(client_id)) as TotalUsers
FROM  dbo_clickstream_data.dp_clickstream_abma_android_real_time
where dt='2021-03-15'
and event_id in ('10.8.1.0.0.0',
'10.11.0.2.0.0',
'10.10.0.4.0.0',
'10.10.2.0.0.0',
'10.10.2.2.0.0',
'10.15.1.0.0.0',
'10.15.0.1.0.0')
group by 1,2,3,4,5)

SELECT dt,totalusers,Reasons,event_id,event_name,IPO_name from raw_data
order by 3,1,4

drop table IPO_Data
Create Table IPO_Data
(IPO_Code varchar(40),ClientID varchar(40), ApplicationNo varchar(40), BankRefNO varchar(40), AllotmentStatus varchar(40),
ApplicationDateTime varchar(40), SponsorBankPayStatus varchar(40))

SELECT * INTO #MyTempTable FROM OPENROWSET('SQLNCLI', 'Server=(172.31.16.85)\SQL2008;Trusted_Connection=yes;',
     'EXEC ABR_DW.dbo.usp_GetIPOPaymentPendingData IRCTC')


SELECT * FROM OPENQUERY([172.31.16.85].ABR_DW.dbo.usp_GetIPOPaymentPendingData)

SELECT *
INTO #result
FROM OPENQUERY([172.31.16.85], 'EXEC ABR_DW.dbo.usp_GetIPOPaymentPendingData IRCTC;');

select * from #result

declare @temp table
(IPO_Code varchar(40),ClientID varchar(40), ApplicationNo varchar(40), BankRefNO varchar(40), AllotmentStatus varchar(40),
ApplicationDateTime varchar(40), SponsorBankPayStatus varchar(40));

INSERT @temp  EXEC [172.31.16.85].ABR_DW.dbo.usp_GetIPOPaymentPendingData 'IRCTC';
select * from @temp;



use onlineengine
select * from Profile360TG

insert into Profile360TG (Party_Code,CreatedOn) values ('A196014','2021-05-27 10:39:18.073')

delete from Profile360TG where createdon<='2021-05-20 12:39:18.073'
















use onlineengine
select * into #ipodata from
EXEC [172.31.16.85].ABR_DW.dbo.usp_GetIPOPaymentPendingData 'IRCTC'

SELECT
  *
INTO
  #tmpSortedBooks
FROM
EXEC [172.31.16.85].ABR_DW.dbo.usp_GetIPOPaymentPendingData 'IRCTC'