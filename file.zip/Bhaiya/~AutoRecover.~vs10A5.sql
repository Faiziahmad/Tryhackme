use onlineengine
select top 100 * from SN_ClientKYC

select * from trade

use onlineengine
select top 100 * from AS_OrderCountData where sauda_date in (select max(sauda_date) from AS_OrderCountData)