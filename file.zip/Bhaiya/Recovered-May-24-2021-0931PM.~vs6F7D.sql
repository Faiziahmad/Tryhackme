select convert(date,left(ts,8),106),utm_campaign,count(profile_identity) as count,
--convert(date,left(ts,8),106) as clickdate,
from
[onlineengine].[dbo].[CT_clicked] a
left join [onlineengine].[dbo].[SN_ClientKYC] b
on a.profile_identity=b.party_code
where utm_campaign in ('1617271661','1617247352','1617185453')
and convert(date,left(ts,8),106)>='2021-04-07' and convert(date,left(ts,8),106)<='2021-04-30'
group by utm_campaign,campaign_type,b2c,convert(date,left(ts,8),106)
order by utm_campaign


select top 10 * from [onlineengine].[dbo].[CT_clicked]
select top 10 * from [onlineengine].[dbo].[CT_campaign_map_daily] where [message id]='1617271661'

use onlineengine
select utm_campaign,count(profile_identity)as viewed,utm_medium
from [onlineengine].[dbo].[CT_clicked]
where utm_campaign in ('1617271661','1617247352','1617185453') 
and convert(date,left(ts,8),106)>='2021-03-01' and convert(date,left(ts,8),106)<='2021-04-30'
group by utm_campaign,utm_medium

select [message id],message_name,start_date,clicked,errors,sent,viewed
from [onlineengine].[dbo].[CT_campaign_map_daily]
where [message id]='Market Update'
and convert(date,(start_date),106)>='2021-03-01' and convert(date,(start_date),106)<='2021-04-30'

select top 10 convert(date,(start_date),106) from [onlineengine].[dbo].[CT_campaign_map_daily] 
