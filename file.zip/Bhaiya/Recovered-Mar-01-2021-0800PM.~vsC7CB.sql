use onlineengine
select * from AD_Trading_Day
KD_spintrade_prc

use onlineengine
select top 10 * from AJ_OffersCardClick_updated where profile_identity='PAPO1097'

use onlineengine
select max(sauda_date) from as_ordercountdata