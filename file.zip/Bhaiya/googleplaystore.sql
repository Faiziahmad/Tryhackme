Select ClientCode, onboardingdate,ClientName, EmailId From [196.1.115.167].[KYC_CI].[dbo].[VW_Campaign_ClientInfo] with(nolock)
where convert(date,onboardingdate,105)>=('2021-02-12')
--and convert(date,onboardingdate,105) <='2020-10-05'
and b2borb2c ='Y'


Select ClientCode, onboardingdate,ClientName, EmailId From [196.1.115.167].[KYC_CI].[dbo].[VW_Campaign_ClientInfo] with(nolock)
where convert(date,onboardingdate,105) >= ('2021-07-08')
and convert(date,onboardingdate,105) <='2021-07-13'
and b2borb2c ='Y'


select top 100 * from [OnlineEngine].[dbo].[Vw_SB_REALTIME_KYCDATA] with(nolock)

select top 10 * From [196.1.115.167].[KYC_CI].[dbo].[VW_Campaign_ClientInfo] with(nolock)

select BOPARTYCODE , FNAME, LNAME, CORRES_EMAIL_ID from [OnlineEngine].[dbo].[Vw_SB_REALTIME_KYCDATA] with(nolock)
where convert(date,Created_date,105) ='2020-09-13'

Select top 10 * From [196.1.115.167].[KYC_CI].[dbo].[VW_Campaign_ClientInfo] with(nolock)
where Clientcode = 'V139657'

SELECT count (1) from [dbo].[vw_GetRefEarnABMARerralDetails] group by cast(creationdate as date) order by cast(creationdate as date) desc


select top 10 * from [ClevertapWebhook].[dbo].[wb_app_install]


use onlineengine
select max(sauda_date) from as_ordercountdata

