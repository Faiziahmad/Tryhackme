Use Communication
drop table #AJ_OffersClick
drop table #AJ_Metadata
drop table #AM_Click_Unique
drop table #AM_Click
drop table #tempprepaid

Select * Into #AJ_OffersClick
From
(Select Distinct Clicked_on,profile_identity,ts,convert(date,left(ts,8),106) as Click_Date,
convert(datetime,stuff(stuff(stuff(ts, 9, 0, ' '), 12, 0, ':'), 15, 0, ':')) as Click_DateTime From [OnlineEngine].[dbo].[AJ_OffersCardClick_updated]
Where profile_identity is not NULL
and Clicked_on like '%prepaid%'
and convert(date,left(ts,8),106) >= '2021-04-01'
and convert(date,left(ts,8),106) <= '2021-04-30'
)a

--- select * From [OnlineEngine].[dbo].[AJ_Offers_Metadata] where created_by like '%Suman%'----
-----drop table #AJ_OffersClick
----select * from #AJ_OffersClick
------select * from [OnlineEngine].[dbo].[AJ_OffersCardClick]
------select * from [OnlineEngine].[dbo].[AJ_OffersCardClick] where Clicked_on like 'Offer for You Zero Brokerage in FnO On 5 Trades'
Select offer_name ,Concat(offer_message_what,' ',offer_message_howmuch,' ',offer_message_action) as merdge,created_by Into #AJ_Metadata 
From [OnlineEngine].[dbo].[AJ_Offers_Metadata]
------Select * from #AJ_Metadata
----drop table #AJ_Metadata

----drop table #AM_Click
select * into #AM_Click 
from (select * from #AJ_OffersClick
left join #AJ_Metadata 
on clicked_on like merdge + '%' ) abc

---select * from #AM_Click
----drop table #AM_Click_Unique
Select * into #AM_Click_Unique from
	(
		Select Distinct profile_identity,Clicked_on,Created_by as Owner_Name,min (Click_Date)MinClick_Date,min (Click_DateTime)MinClick_DateTime   -------issue
		from #AM_Click
		group by profile_identity,Clicked_on,Created_by
	)C

--------select * from [196.1.115.167].KYC.[dbo].VW_PrePaid_Plan_ClientInfo 
drop table #tempPrepaid

Select distinct ClientCode,ConsentDate, cast(ConsentDate as date) ConDate,VoucherPlanOpted,orderlimit,tradeDoneCount,Total_Brokerage_Cashback,Plantype
into #tempPrepaid
from [196.1.115.167].KYC.[dbo].VW_PrePaid_Plan_ClientInfo where ClientCode in
(Select A.ClientCode From [196.1.115.167].KYC.[dbo].VW_PrePaid_Plan_ClientInfo A, #AM_Click B 
where A.ClientCode = B.profile_identity
and Cast (Consentdate as Date) = B.Click_Date
and B.Clicked_on like '%prepaid%')
order by consentdate desc

----select * from #tempPrepaid
select * from [196.1.115.167].KYC.[dbo].VW_PrePaid_Plan_ClientInfo order by consentdate desc
Select * from #AM_Click_Unique where clicked_on like '%prepaid%'

------------------Overall Prepaid Conversions MOM----
Select * from [196.1.115.167].KYC.[dbo].VW_PrePaid_Plan_ClientInfo 

Select month(consentdate),count(clientcode) from [196.1.115.167].KYC.[dbo].VW_PrePaid_Plan_ClientInfo
group by month(consentdate)
order by month(consentdate)
--------------------------------------------------
 Create Table AM_OnR_Prepaid
(ClientCode varchar(40),Consentdate datetime, Condate datetime,VoucherPlanOpted int,orderlimit int, tradeDoneCount int,
Total_Brokerage_Cashback float, plantype int)

insert into AM_OnR_Prepaid
select * from #tempPrepaid

select * from AM_OnR_Prepaid  where consentdate>='2021-03-01'

select max(consentdate) from AM_OnR_Prepaid 

select max(consentdate)from AM_OnR_Prepaid

--------------------------------------------------------------------------
--------------------PREPAID REVENUE-----------------------------------------

select ClientCode, Consentdate, sauda_date, datediff(day, ActiveFrom,consentdate)DaystoConsent, sum(brokerage) brokerage
from AM_OnR_Prepaid A,
onlineengine.dbo.AS_OrderCountData B,
onlineengine.dbo.SN_ClientKYC C
where A.Clientcode = b.Party_code
and  A.ClientCode = C.Party_Code
and sauda_date >= consentdate
and consentdate>='2021-01-04'
group by ClientCode, Consentdate, sauda_date, datediff(day, ActiveFrom,consentdate)


--------Traded first 30 days-------------
select A.ClientCode, convert(date,Consentdate,106)ConsentDate, sum(Brokerage) as Rev
From [196.1.115.167].KYC.[dbo].VW_PrePaid_Plan_ClientInfo A
left outer join onlineengine.dbo.AS_OrderCountData B
on A.Clientcode = b.Party_code
where  sauda_date < consentdate + 30  --and sauda_date < consentdate + 0
and sauda_date >= consentdate
group by A.ClientCode, convert(date,Consentdate,106)

select * from [196.1.115.167].KYC.[dbo].VW_PrePaid_Plan_ClientInfo