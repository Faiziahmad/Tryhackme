use onlineengine

select * from AD_Trading_Day

select * from AD_trading_day_final

select * from AD_TradingDay_OnB

select * from DK_DaysoftradingfromDate where datelist>='2021-04-01' 
and datelist<='2022-03-31'

select distinct tradingday from DK_DaysoftradingfromDate where datelist>='2021-04-01' 
and datelist<='2022-03-31'

select * from DK_DaysoftradingfromDate_All

select * from AJ_profile360_action

select * from Profile360TG where party_code='R134102'

use OnlineEngine
select LogDate, ClientCode, control_flag2 into #temp
from [196.1.115.167].[KYC_CI].dbo.[VW_Campaign_ClientInfo] with (nolock)
where LogDate>= '2021-05-29' AND B2bOrB2c = 'Y' and control_flag2 in ('2','3','4')

select A.LogDate,A.ClientCode, A.control_flag2, B.PartyCode_GenDate into #temp1
from #temp A LEFT JOIN [OnlineEngine].[dbo].[SN_ClientKYC] B
on A.ClientCode = B.Party_Code

SELECT A.PartyCode_GenDate as onbdate,A.LogDate,A.ClientCode as clientid,case when A.control_flag2 in ('2') then 'Cashback'
                                         when A.control_flag2 in ('3','4') then 'Scratch_card' end as Offer_Type,
B.RequestDateTime AS Fund_date,B.Amount,B.[Status],Cast('Not_Funded' as varchar(40)) as Funding into #temp2
FROM #temp1 A LEFT JOIN [OnlineEngine].[dbo].[AJ_FundTransferSource] B
ON A.ClientCode = B.ClientCode


update #temp2
set Funding = case when Status = 'SUCCESS' AND datediff(day,cast(onbdate as date),cast(Fund_date as date)) = 0 then 'Day0'
                   WHEN Status = 'SUCCESS' AND datediff(day,cast(onbdate as date),cast(Fund_date as date)) = 1 then 'Day1'
				   WHEN Status = 'SUCCESS' AND datediff(day,cast(onbdate as date),cast(Fund_date as date)) = 2 then 'Day2'
				   WHEN Status = 'SUCCESS' AND datediff(day,cast(onbdate as date),cast(Fund_date as date)) = 3 then 'Day3'
				   WHEN Status = 'SUCCESS' AND datediff(day,cast(onbdate as date),cast(Fund_date as date)) = 4 then 'Day4'
				   WHEN Status = 'SUCCESS' AND datediff(day,cast(onbdate as date),cast(Fund_date as date)) = 5 then 'Day5'
				   WHEN Status = 'SUCCESS' AND datediff(day,cast(onbdate as date),cast(Fund_date as date)) = 6 then 'Day6'
				   WHEN Status = 'SUCCESS' AND datediff(day,cast(onbdate as date),cast(Fund_date as date)) = 7 then 'Day7'
				   WHEN Status = 'SUCCESS' AND datediff(day,cast(onbdate as date),cast(Fund_date as date)) = 8 then 'Day8'
				   WHEN Status = 'SUCCESS' AND datediff(day,cast(onbdate as date),cast(Fund_date as date)) = 9 then 'Day9'
				   WHEN Status = 'SUCCESS' AND datediff(day,cast(onbdate as date),cast(Fund_date as date)) = 10 then 'Day10'
				   WHEN Status = 'SUCCESS' AND datediff(day,cast(onbdate as date),cast(Fund_date as date)) = 11 then 'Day11'
				   WHEN Status = 'SUCCESS' AND datediff(day,cast(onbdate as date),cast(Fund_date as date)) = 12 then 'Day12'
				   WHEN Status = 'SUCCESS' AND datediff(day,cast(onbdate as date),cast(Fund_date as date)) = 13 then 'Day13'
				   WHEN Status = 'SUCCESS' AND datediff(day,cast(onbdate as date),cast(Fund_date as date)) = 14 then 'Day14'
				   WHEN Status = 'SUCCESS' AND datediff(day,cast(onbdate as date),cast(Fund_date as date)) = 15 then 'Day15'
				   WHEN Status = 'SUCCESS' AND datediff(day,cast(onbdate as date),cast(Fund_date as date)) > 15 and  
				   datediff(day,cast(onbdate as date),cast(Fund_date as date)) <= 30 then 'Days15-30'
				   else 'NOT_Funded' end

--ENGAGEMENT-- 
SELECT profile_identity, ts into #temp3
from CT_clicked
where ts >= '20210528000000' and utm_campaign in (select CampaignID from CT_Campaign where ActionID = '2')


select A.onbdate,A.clientid,A.Offer_Type,A.Fund_date,A.Funding, A.Amount,A.[Status],convert(datetime,stuff(stuff(stuff(B.ts, 9, 0, ' '), 12, 0, ':'), 15, 0, ':')) as clicktime,
Cast('Not_Engaged' as varchar(40)) as EngagedDay,Cast('Not_Converted' as varchar(40)) as Convertday  INTO #temp4
FROM #temp2 A LEFT JOIN #temp3 B
ON A.clientid = B.profile_identity

update #temp4
set EngagedDay = case when datediff(day,cast(onbdate as date),cast(clicktime as date)) = 0 then 'Day0'
                   WHEN datediff(day,cast(onbdate as date),cast(clicktime as date)) = 1 then 'Day1'
				   WHEN datediff(day,cast(onbdate as date),cast(clicktime as date)) = 2 then 'Day2'
				   WHEN datediff(day,cast(onbdate as date),cast(clicktime as date)) = 3 then 'Day3'
				   WHEN datediff(day,cast(onbdate as date),cast(clicktime as date)) = 4 then 'Day4'
				   WHEN datediff(day,cast(onbdate as date),cast(clicktime as date)) = 5 then 'Day5'
				   WHEN datediff(day,cast(onbdate as date),cast(clicktime as date)) = 6 then 'Day6'
				   WHEN datediff(day,cast(onbdate as date),cast(clicktime as date)) = 7 then 'Day7'
				   WHEN datediff(day,cast(onbdate as date),cast(clicktime as date)) = 8 then 'Day8'
				   WHEN datediff(day,cast(onbdate as date),cast(clicktime as date)) = 9 then 'Day9'
				   WHEN datediff(day,cast(onbdate as date),cast(clicktime as date)) = 10 then 'Day10'
				   WHEN datediff(day,cast(onbdate as date),cast(clicktime as date)) = 11 then 'Day11'
				   WHEN datediff(day,cast(onbdate as date),cast(clicktime as date)) = 12 then 'Day12'
				   WHEN datediff(day,cast(onbdate as date),cast(clicktime as date)) = 13 then 'Day13'
				   WHEN datediff(day,cast(onbdate as date),cast(clicktime as date)) = 14 then 'Day14'
				   WHEN datediff(day,cast(onbdate as date),cast(clicktime as date)) = 15 then 'Day15'
				   else 'Not_Engaged' end

--CONVERSION--

update #temp4
set Convertday = case when Status = 'SUCCESS' AND datediff(day,cast(clicktime as date),cast(Fund_date as date)) <= 2 and datediff(day,cast(clicktime as date),cast(Fund_date as date))>= 0 then 'Converted' else 'Not_Converted' end


select cast(onbdate as date) as onbdate,Offer_Type,
ROUND(CAST(count(distinct (case when EngagedDay = 'Day0'  then clientid end)) AS FLOAT)*100/CAST(count(distinct clientid ) AS FLOAT),1) as 'DAY0', 
ROUND(CAST(count(distinct (case when EngagedDay = 'Day1'  then clientid end)) AS FLOAT)*100/CAST(count(distinct clientid ) AS FLOAT),1) as 'DAY1',
ROUND(CAST(count(distinct (case when EngagedDay = 'Day2'  then clientid end)) AS FLOAT)*100/CAST(count(distinct clientid ) AS FLOAT),1) as 'DAY2',
ROUND(CAST(count(distinct (case when EngagedDay = 'Day3'  then clientid end)) AS FLOAT)*100/CAST(count(distinct clientid ) AS FLOAT),1) as 'DAY3',
ROUND(CAST(count(distinct (case when EngagedDay = 'Day4'  then clientid end)) AS FLOAT)*100/CAST(count(distinct clientid ) AS FLOAT),1) as 'DAY4',
ROUND(CAST(count(distinct (case when EngagedDay IN ('Day0','Day1''Day2')    then clientid end)) AS FLOAT)*100/CAST(count(distinct clientid ) AS FLOAT),1) as 'DAY0-2',
ROUND(CAST(count(distinct (case when EngagedDay IN ('Day0','Day1','Day2','Day3','Day4')   then clientid end)) AS FLOAT)*100/CAST(count(distinct clientid ) AS FLOAT),1) as 'DAY0-4',
ROUND(CAST(count(distinct (case when EngagedDay IN ('Day0','Day1','Day2','Day3','Day4','Day5','Day6','Day7')   then clientid end)) AS FLOAT)*100/CAST(count(distinct clientid ) AS FLOAT),1) as 'DAY0-7',
ROUND(CAST(count(distinct (case when EngagedDay IN ('Day0','Day1','Day2','Day3','Day4','Day5','Day6','Day7','Day8','Day9','Day10','Day11','Day12','Day13','Day14','Day15')   then clientid end)) AS FLOAT)*100/CAST(count(distinct clientid ) AS FLOAT),1) as 'DAY0-15'
from #temp4
where cast(onbdate as date)>= '2021-05-29' and cast(onbdate as date)<= DATEADD(day,-1,cast(getdate() as date))
group by cast(onbdate as date),Offer_Type


drop table #temp
drop table #temp1
drop table #temp2
drop table #temp3
drop table #temp4

select format(AA.PartyCode_GenDate, 'yyyy-MM') as Months, AA.Month_Diff, count(distinct AA.party_code) as Users
from
(select A.Party_Code, A.PartyCode_GenDate, B.sauda_date, 
(case when DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Sauda_Date) <= 30 then 'A. 30Days'
     when DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Sauda_Date) > 30 and DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Sauda_Date) <= 60 then 'B. 31-60 Days'
     when DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Sauda_Date) > 60 and DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Sauda_Date) <= 90 then 'C. 61-90 Days'
     when DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Sauda_Date) > 90 and DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Sauda_Date) <= 120 then 'D. 91-120 Days'
     when DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Sauda_Date) > 120 and DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Sauda_Date) <= 150 then 'E. 121-150 Days'
     when DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Sauda_Date) > 150 and DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Sauda_Date) <= 180 then 'F. 151-180 Days'
     when DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Sauda_Date) > 180 and DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Sauda_Date) <= 210 then 'G. 181-210 Days'
     when DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Sauda_Date) > 210 and DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Sauda_Date) <= 240 then 'H. 211-240 Days'
     when DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Sauda_Date) > 240 and DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Sauda_Date) <= 270 then 'I. 241-270 Days'
     when DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Sauda_Date) > 270 and DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Sauda_Date) <= 300 then 'J. 271-300 Days'
     when DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Sauda_Date) > 300 and DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Sauda_Date) <= 330 then 'K. 301-330 Days'
     when DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Sauda_Date) > 330 and DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Sauda_Date) <= 360 then 'L. 331-360 Days'
     when DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Sauda_Date) > 360 then 'M. 360+ Days' end) as Month_Diff 
from (select Party_code, sauda_date
from AS_OrderCountData
where inst_type in ('OPTIDX','OPTSTK')
and sauda_date >= '2020-04-01' and Party_code in (select Party_code from SN_ClientKYC where PartyCode_GenDate >= '2020-04-01' and  PartyCode_GenDate <= GETDATE() and B2C = 'Y')) B left join SN_ClientKYC A
on A.Party_Code = B.Party_code
where A.PartyCode_GenDate >= '2020-04-01' and  A.PartyCode_GenDate <= GETDATE()
and A.B2C = 'Y' ) AA
group by format(AA.PartyCode_GenDate, 'yyyy-MM'), AA.Month_Diff


select A.Party_Code, A.PartyCode_GenDate, B.Min_Op_Sauda_Date, 
(case when DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Min_Op_Sauda_Date) <= 30 then '1. 30Days'
     when DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Min_Op_Sauda_Date) > 30 and DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Min_Op_Sauda_Date) <= 60 then '2. 31-60 Days'
     when DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Min_Op_Sauda_Date) > 60 and DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Min_Op_Sauda_Date) <= 90 then '3. 61-90 Days'
     when DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Min_Op_Sauda_Date) > 90 and DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Min_Op_Sauda_Date) <= 120 then '3. 91-120 Days'
     when DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Min_Op_Sauda_Date) > 120 and DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Min_Op_Sauda_Date) <= 150 then '4. 121-150 Days'
     when DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Min_Op_Sauda_Date) > 150 and DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Min_Op_Sauda_Date) <= 180 then '5. 151-180 Days'
     when DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Min_Op_Sauda_Date) > 180 and DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Min_Op_Sauda_Date) <= 210 then '6. 181-210 Days'
     when DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Min_Op_Sauda_Date) > 210 and DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Min_Op_Sauda_Date) <= 240 then '7. 211-240 Days'
     when DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Min_Op_Sauda_Date) > 240 and DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Min_Op_Sauda_Date) <= 270 then '8. 241-270 Days'
     when DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Min_Op_Sauda_Date) > 270 and DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Min_Op_Sauda_Date) <= 300 then '9. 271-300 Days'
     when DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Min_Op_Sauda_Date) > 300 and DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Min_Op_Sauda_Date) <= 330 then '10. 301-330 Days'
     when DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Min_Op_Sauda_Date) > 330 and DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Min_Op_Sauda_Date) <= 360 then '11. 331-360 Days'
     when DATEDIFF(DAY, cast(A.PartyCode_GenDate as date), B.Min_Op_Sauda_Date) > 360 then '13. 360+ Days'
     else '14. Not Active' end ) as Activation_Cat
into #temp
from SN_ClientKYC A left join 
(select party_code, min(sauda_date) as Min_Op_Sauda_Date
from SN_MinSaudaTime
where inst_type in ('OPTIDX','OPTSTK')
and sauda_date >= '2020-04-01'
group by party_code) B
on A.Party_Code = B.party_code
where A.PartyCode_GenDate >= '2020-04-01' and  A.PartyCode_GenDate <= GETDATE()
and A.B2C = 'Y'
select format(PartyCode_GenDate, 'yyyy-MM') as Months, Activation_Cat, Count(party_code) as Users
from #temp
group by format(PartyCode_GenDate, 'yyyy-MM'), Activation_Cat


select format(AA.PartyCode_GenDate, 'yyyy-MM') as Months, AA.Month_Diff, count(distinct AA.party_code) as Users
from
(select A.Party_Code, A.PartyCode_GenDate, B.sauda_date, datediff(MONTH, A.PartyCode_GenDate, B.sauda_date) as Month_Diff 
from SN_ClientKYC A , 
(select Party_code, sauda_date
from AS_OrderCountData
where inst_type in ('OPTIDX','OPTSTK')
and sauda_date >= '2020-04-01') B
where A.PartyCode_GenDate >= '2020-04-01' and  A.PartyCode_GenDate <= GETDATE()
and A.B2C = 'Y' and A.Party_Code = B.Party_code) AA
group by format(AA.PartyCode_GenDate, 'yyyy-MM'), AA.Month_Diff