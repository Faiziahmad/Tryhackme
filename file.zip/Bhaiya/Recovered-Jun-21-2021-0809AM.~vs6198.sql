Select top 100 * from [172.31.25.94].[ReplicatedData].dbo.[ANAND1MSAJAGClient_Details]

use onlineengine

select * from Profile360TG

insert into Profile360TG (party_code,createdon) values 
('A136769','2021-06-18 12:39:18.073')