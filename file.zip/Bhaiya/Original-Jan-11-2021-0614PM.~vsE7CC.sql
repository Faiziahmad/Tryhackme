use onlineengine

--Drop Table #temp
Select * into #temp from
(
Select Activefrom  , 
acqmonth = month(activefrom),
party_code, b2c, 
FirstTrade_KYC = firsttrade,
firsttrade_time = cast('Dec 01 2049' as datetime),
firsttrade_Amount = cast(0 as float),
campaign = cast('NA' as varchar),

Tradediff = cast(-100 as int), 
TradingDay_R = cast(0 as int),
FirstTransfer_DateTime = cast('Dec 01 2049' as datetime), 
FirstTransfer_Amount = cast(0 as float),
INstall_Datetime = cast('Dec 01 2049' as datetime)
 from SN_ClientKYC A 
where activefrom >= 'Jan 01 2020'
and activefrom < 'Jan 01 2021'
and b2c ='y'
and Branch_cd not in ('RFRL')
)A


Update A 
Set firsttrade_time = MisSaudadatetime
from #temp A,  (Select party_code, min(cast(Sauda_Date as datetime) + CAST(minSaudaTime AS DATETIME)) as MisSaudadatetime 
			   from SN_MinSaudaTime
			   Group by party_code
			   )B
where A.party_code = B.Party_code


Update A 
Set TradeDiff = DayofTrading
from #temp A,  DK_DaysoftradingfromDate B
where convert(date,Datelist,106) = convert(date,activefrom,106)
and convert(date,tradingday,106) = convert(date,firsttrade_time,106)

Update A 
Set TradingDay_R = 1 
from #temp A, OnlineEngine.dbo.SN_TradingDays B
Where convert(date,activefrom,106) = convert(date,TradingDay,106)

--Drop Table #temp_FT_AllRecords
select * into #temp_FT_AllRecords from
(
 SELECT
		ClientCode,
		MIN(RequestDateTime) as minVDT
  FROM
		[OnlineEngine].[dbo].[AJ_FundTransferSource]
  WHERE
		RequestDateTime >= '2020-01-01'
		AND
		[Status] = 'Success'
  GROUP BY ClientCode
)B

Update A
Set FirstTransfer_DateTime = MINVDT
from #temp A, #temp_FT_AllRecords B
where A.Party_code = B.ClientCode


Update A
Set INstall_Datetime = convert(date,left(ts,8),106)
from #temp A, [OnlineEngine].[dbo].[CT_app_install] B WITH(NOLOCK)
where A.party_code = B.[identity]

Update A
Set campaign = case when B.Campaign in ('ABMA', 'ABMA_Organic', 'SSGoogleSearch', 'Web' ) then B.Campaign
					when B.Campaign is null then 'Referral'
					when B.Campaign in ('Brand_Innovation', 'Discovery', 'SMS', 'SSFacebook' ,
					'SSGoogleDisplay','SSGoogleVideo','SSInnovation','Telesales Partner','Vendor_Mailer','Vendor_ORB')  then 'Others' end
from #temp A, SN_SalesSource_Intent B WITH(NOLOCK)
where A.party_code = B.Party_code


Update #temp
set Campaign = 'Referral'
where campaign = 'NA'

--select * from #temp

---------------Trade Analysis----------------------------------------
---------------------------------------------------------------------
--Drop Table #Temp_MinClickdiff_Trade
Select * into #Temp_MinClickdiff_Trade from 
(Select profile_identity,
channel,
Activefrom = cast('Dec 01 2049' as datetime),
InfoType = cast( 
			Case when actionid = 2 then 'FundTransfer'
				 ELse 'FirstTradeMsg+TriggerTrdMSg' end
		   as varchar(100)),
clickdatetime = (convert(datetime,stuff(stuff(stuff(ts, 9, 0, ' '), 12, 0, ':'), 15, 0, ':'))),
ClicktoTrade_MinDiff = cast(0 as int),
ClicktoTrade_DayDiff = cast(0 as int),
ActivefromtoTradeDayDiff = cast(0 as int),
FirstTrade_DateTime = cast('Dec 01 2049' as datetime), 
Chosen_Identity = COncat(profile_identity,'_',channel,'_',ts),
Is_Chosen = cast(0 as int),
IsTradingDay = cast(0 as int)
from [OnlineEngine].[dbo].[CT_clicked] A, [CT_Campaign] B
where A.UTM_Campaign = B.CampaignID
and ts > 20200101000000
and actionid in (2,3,5)
)A


Insert Into #Temp_MinClickdiff_Trade
Select A.party_code,
'WhatsApp',
Activefrom = cast('Dec 01 2049' as datetime),
InfoType = MSGIdentity,
clickdatetime = URLCLICKDATE,
ClicktoTrade_MinDiff = cast(0 as int),
ClicktoTrade_DayDiff = cast(0 as int),
ActivefromtoTradeDayDiff = cast(0 as int),
FirstTrade_DateTime = cast('Dec 01 2049' as datetime),
Chosen_Identity = COncat(A.party_code,'_','WhatsApp','_',MSGIdentity,'_',URLCLICKDATE),
Is_Chosen = 0,
IsTradingDay = 0
from [Communication].[dbo].[KP_WA_OB_Messages_Clicks_Logs] A, #temp B
where ActivationDate >='Jan 01 2020'
and A.party_code = B.party_code
and isURLCLICKED = 'y'
and MSGIdentity not like '%Download%'
and Datediff(day,activefrom, convert(date,URLCLICKDATE,106)) >= 0


update A
Set ClicktoTrade_MinDiff = datediff(minute,clickdatetime,B.firsttrade_time),
FirstTrade_DateTime= B.firsttrade_time,
ActivefromtoTradeDayDiff = TradeDiff,
Activefrom = b.activefrom,
IsTradingDay = TradingDay_R
From #Temp_MinClickdiff_Trade A, #temp B
Where A.profile_identity = B.Party_code
and b.firsttrade_time <getdate()



Update A 
Set ClicktoTrade_DayDiff = DayofTrading
from #Temp_MinClickdiff_Trade A,  DK_DaysoftradingfromDate B
where convert(date,Datelist,106) = convert(date,clickdatetime,106)
and convert(date,tradingday,106) = convert(date,FirstTrade_DateTime,106)


Update A
Set Is_Chosen = 0 
from #Temp_MinClickdiff_Trade A

Update A 
Set Is_Chosen = 1
from #Temp_MinClickdiff_Trade A
where Chosen_Identity in (
				SELECT Chosen_Identity
				 FROM
				 (
					 SELECT ROW_NUMBER() OVER (PARTITION BY profile_identity ORDER BY ClicktoTrade_MinDiff) as RowNum, *
					 FROM #Temp_MinClickdiff_Trade
					 where ClicktoTrade_MinDiff >=-10
				 ) X 
				 WHERE RowNum = 1
			  )

Update A 
Set Is_Chosen = 2
from #Temp_MinClickdiff_Trade A
where Chosen_Identity in (
				SELECT Chosen_Identity
				 FROM
				 (
					 SELECT ROW_NUMBER() OVER (PARTITION BY profile_identity ORDER BY ClicktoTrade_MinDiff desc) as RowNum, *
					 FROM #Temp_MinClickdiff_Trade
					 where profile_identity not in (Select profile_identity from #Temp_MinClickdiff_Trade where is_Chosen = 1)
					 and ClicktoTrade_MinDiff < -10
				 ) X 
				 WHERE RowNum = 1
			  )

----Trade Conversions-------------------------------

----FUll Data
--conversion
--Select  distinct Profile_identity, channel, infotype, activefrom, ActivefromtoTradeDayDiff, clickdatetime, firsttrade_datetime,
--ClicktoTrade_MinDiff, ClicktoTrade_DayDiff, is_Chosen
--from  #Temp_MinClickdiff_Trade --where profile_identity = 'J71495' 
--where FirstTrade_DateTime < getdate()
----and ((ActivefromtoTradeDayDiff <2) or ClicktoTrade_DayDiff in (0,1))
--and (((IsTradingDay = 1 and ActivefromtoTradeDayDiff <2) or (IsTradingDay = 0 and ActivefromtoTradeDayDiff = 0)) or (ClicktoTrade_DayDiff in (0,1)))
--and Is_Chosen in (1,2)
--and ActivefromtoTradeDayDiff >=0
----and FirstTrade_DateTime > clickdatetime
--and ((IsTradingDay = 1 and ClicktoTrade_DayDiff <2) or (IsTradingDay = 0 and ClicktoTrade_DayDiff = 0))
--order by ClicktoTrade_MinDiff

----Trade Conversions----------------------

alter table #Temp_MinClickdiff_Trade
add Campaign varchar(40)

update #Temp_MinClickdiff_Trade
set Campaign = B.campaign
from #Temp_MinClickdiff_Trade A, #temp B
where A.profile_identity = B.party_code


Select 
AA.Channel,AA.Campaign, AA.infotype, AA.acqmonth,AA.Activefrom, AA.Daywise , clicks, engagedclients, Convertedclients
from
	(Select  Channel,Campaign, infotype, DateAdd(Day,1,EOMonth(activefrom,-1)) acqmonth, Activefrom,
	Daywise = 	Case when (ActivefromtoTradeDayDiff - IsTradingDay + 1) in (0,1,2) then concat(ActivefromtoTradeDayDiff - IsTradingDay + 1,' day')
					 Else '2+ days' end ,
	count(distinct(Profile_identity)) as Convertedclients
	from  #Temp_MinClickdiff_Trade 
	where FirstTrade_DateTime < getdate()
	and (((IsTradingDay = 1 and ActivefromtoTradeDayDiff <2) or (IsTradingDay = 0 and ActivefromtoTradeDayDiff = 0)) or (ClicktoTrade_DayDiff in (0,1)))
	and Is_Chosen in (1,2)
	and ActivefromtoTradeDayDiff >=0
	and ((IsTradingDay = 1 and ClicktoTrade_DayDiff <2) or (IsTradingDay = 0 and ClicktoTrade_DayDiff = 0))
	Group by Channel,Campaign, infotype, DateAdd(Day,1,EOMonth(activefrom,-1)),activefrom, 
			 Case when (ActivefromtoTradeDayDiff - IsTradingDay + 1) in (0,1,2) then concat(ActivefromtoTradeDayDiff - IsTradingDay + 1,' day')
					 Else '2+ days' end 
	)AA,

	---Trade Engagement----------------
	(Select  Channel,Campaign, infotype, DateAdd(Day,1,EOMonth(activefrom,-1)) acqmonth, activefrom,
	Daywise = 	Case when (ActivefromtoTradeDayDiff - IsTradingDay + 1) in (0,1,2) then concat(ActivefromtoTradeDayDiff - IsTradingDay + 1,' day')
					 Else '2+ days' end ,
	count(1) clicks, count(distinct(Profile_identity)) as engagedclients
	from  #Temp_MinClickdiff_Trade --where profile_identity = 'J71495' 
	where 
	activefrom >= 'Jan 01 2020'and activefrom < getdate()
	and ((IsTradingDay = 1 and ClicktoTrade_DayDiff <2) or (IsTradingDay = 0 and ClicktoTrade_DayDiff = 0))
	Group by Channel,Campaign, infotype, DateAdd(Day,1,EOMonth(activefrom,-1)), activefrom,
			 Case when (ActivefromtoTradeDayDiff - IsTradingDay + 1) in (0,1,2) then concat(ActivefromtoTradeDayDiff - IsTradingDay + 1,' day')
					 Else '2+ days' end 
	)BB
where AA.Channel = BB.Channel
and AA.infotype = BB.infotype
and AA.acqmonth = BB.acqmonth
and AA.Daywise = BB.Daywise
and AA.Campaign = BB.Campaign
and AA.Activefrom = BB.Activefrom
order by AA.Channel, AA.infotype, AA.acqmonth, AA.Daywise


---------------FundTransfer Analysis----------------------------------------
---------------------------------------------------------------------


--Drop Table #Temp_MinClickdiff_Trade
Select * into #Temp_MinClickdiff_Funds from 
(Select profile_identity,
channel,
Activefrom = cast('Dec 01 2049' as datetime),
InfoType = cast( 
			Case when actionid = 2 then 'FundTransfer'
				 ELse 'FirstTradeMsg+TriggerTrdMSg' end
		   as varchar(100)),
clickdatetime = (convert(datetime,stuff(stuff(stuff(ts, 9, 0, ' '), 12, 0, ':'), 15, 0, ':'))),
ClicktoFunds_MinDiff = cast(0 as int),
ClicktoFunds_DayDiff = cast(0 as int),
ActivefromtoFundsDayDiff = cast(0 as int),
FirstFunds_DateTime = cast('Dec 01 2049' as datetime), 
Chosen_Identity = COncat(profile_identity,'_',channel,'_',ts),
Is_Chosen = cast(0 as int)
from [OnlineEngine].[dbo].[CT_clicked] A, [CT_Campaign] B
where A.UTM_Campaign = B.CampaignID
and ts > 20200101000000
and actionid in (2)
)A


Insert Into #Temp_MinClickdiff_Funds
Select A.party_code,
'WhatsApp',
Activefrom = cast('Dec 01 2049' as datetime),
InfoType = MSGIdentity,
clickdatetime = URLCLICKDATE,
ClicktoFunds_MinDiff = cast(0 as int),
ClicktoFunds_DayDiff = cast(0 as int),
ActivefromtoFundsDayDiff = cast(0 as int),
FirstFunds_DateTime = cast('Dec 01 2049' as datetime),
Chosen_Identity = COncat(A.party_code,'_','WhatsApp','_',MSGIdentity,'_',URLCLICKDATE),
Is_Chosen = 0
from [Communication].[dbo].[KP_WA_OB_Messages_Clicks_Logs] A, #temp B
where ActivationDate >='Jan 01 2020'
and A.party_code = B.party_code
and isURLCLICKED = 'y'
and MSGIdentity in ('Add_Fund Msg','Keyword Add Fund Msg','Trigger_Add_Fund_Msg')
and Datediff(day,activefrom, convert(date,URLCLICKDATE,106)) >= 0


update A
Set ClicktoFunds_MinDiff = datediff(minute,clickdatetime,B.FirstTransfer_DateTime),
ClicktoFunds_DayDiff = datediff(day,clickdatetime,B.FirstTransfer_DateTime),
FirstFunds_DateTime = B.firsttrade_time,
ActivefromtoFundsDayDiff = Datediff(day,b.activefrom,B.firsttrade_time),
Activefrom = b.activefrom
From #Temp_MinClickdiff_Funds A, #temp B
Where A.profile_identity = B.Party_code
and FirstTransfer_DateTime < getdate()

Update A
Set ClicktoFunds_MinDiff = -1000
from #Temp_MinClickdiff_Funds A
where FirstFunds_DateTime > getdate()

Update A
Set Is_Chosen = 0 
from #Temp_MinClickdiff_Funds A

Update A 
Set Is_Chosen = 1
from #Temp_MinClickdiff_Funds A
where Chosen_Identity in (
				SELECT Chosen_Identity
				 FROM
				 (
					 SELECT ROW_NUMBER() OVER (PARTITION BY profile_identity ORDER BY ClicktoFunds_MinDiff) as RowNum, *
					 FROM #Temp_MinClickdiff_Funds
					 where ClicktoFunds_MinDiff >=-10
				 ) X 
				 WHERE RowNum = 1
			  )

Update A 
Set Is_Chosen = 2
from #Temp_MinClickdiff_Funds A
where Chosen_Identity in (
				SELECT Chosen_Identity
				 FROM
				 (
					 SELECT ROW_NUMBER() OVER (PARTITION BY profile_identity ORDER BY ClicktoFunds_MinDiff desc) as RowNum, *
					 FROM #Temp_MinClickdiff_Funds
					 where profile_identity not in (Select profile_identity from #Temp_MinClickdiff_Funds where is_Chosen = 1)
					 and ClicktoFunds_MinDiff < -10
				 ) X 
				 WHERE RowNum = 1
			  )


alter table #Temp_MinClickdiff_Funds
add Campaign varchar(40)

update #Temp_MinClickdiff_Funds
set Campaign = B.campaign
from #Temp_MinClickdiff_Funds A, #temp B
where A.profile_identity = B.party_code


----Fund Conversions-------------------------------

----FUll Data

Select  distinct Profile_identity, channel,Campaign, infotype, activefrom, ActivefromtoFundsDayDiff, clickdatetime, FirstFunds_DateTime,
ClicktoFunds_MinDiff, ClicktoFunds_DayDiff, is_Chosen
from  #Temp_MinClickdiff_Funds 
where FirstFunds_DateTime < getdate()
and Is_Chosen in (1,2)
and ActivefromtoFundsDayDiff >=0
and ClicktoFunds_DayDiff in(0,1)
order by ClicktoFunds_MinDiff



----Funds Conversions----------------------

Select 
AA.Channel,AA.Campaign, AA.infotype, AA.acqmonth, AA.Daywise , clicks, engagedclients, Convertedclients
from
	(
	Select  Channel,Campaign, infotype, DateAdd(Day,1,EOMonth(activefrom,-1)) acqmonth, 
	Daywise = 	case when datediff(day,activefrom,clickdatetime) in (0,1,2) then datediff(day,activefrom,clickdatetime)
				Else 4 end,
	count(distinct(Profile_identity)) as Convertedclients
	from  #Temp_MinClickdiff_Funds 
	where FirstFunds_DateTime < getdate()
	and Is_Chosen in (1,2)
	and ActivefromtoFundsDayDiff >=0
	and ClicktoFunds_DayDiff in(0,1)
	Group by Channel,Campaign, infotype, DateAdd(Day,1,EOMonth(activefrom,-1)),
			case when datediff(day,activefrom,clickdatetime) in (0,1,2) then datediff(day,activefrom,clickdatetime)
				Else 4 end

	)AA,

	---Funds Engagement----------------
	(Select  Channel,Campaign, infotype, DateAdd(Day,1,EOMonth(activefrom,-1)) acqmonth, 
	Daywise = 	case when datediff(day,activefrom,clickdatetime) in (0,1,2) then datediff(day,activefrom,clickdatetime)
				Else 4 end,
	count(1) clicks, count(distinct(Profile_identity)) as engagedclients
	from  #Temp_MinClickdiff_Funds 
	where 
	activefrom >= 'Jan 01 2020'and activefrom < getdate()
	Group by Channel,Campaign, infotype, DateAdd(Day,1,EOMonth(activefrom,-1)), 
			 case when datediff(day,activefrom,clickdatetime) in (0,1,2) then datediff(day,activefrom,clickdatetime)
				Else 4 end 
	)BB
where AA.Channel = BB.Channel
and AA.infotype = BB.infotype
and AA.acqmonth = BB.acqmonth
and AA.Daywise = BB.Daywise
and AA.Campaign = BB.Campaign
order by AA.Channel, AA.infotype, AA.acqmonth, AA.Daywise,AA.Campaign


--Select acqmonth, count(distinct(party_code)) from #Temp group by acqmonth

-------------------Installs--------------------------------
------------------------CLicks Analysis-----------------------------------------------------------
--------------------------------------------------------------------------------------------------

Select * into #TempInstallClicks from
(
Select * from [Communication].[dbo].[KP_WA_OB_Messages_Clicks_Logs]
where MSGIdentity in ('APP_Download Msg','Keyword APP_Download Msg')
)A


Select AA.acqmonth, AA.DayOnboarded, Engagedclients, convertedclients
from
	(Select DateAdd(Day,1,EOMonth(activefrom,-1)) acqmonth,  
	DayOnboarded = Case when Datediff(day,activefrom, convert(date,URLCLICKDATE,106)) in (0,1,2)
						then  Datediff(day,activefrom, convert(date,URLCLICKDATE,106))
				   Else 4 end,
	count(Distinct(A.party_code)) convertedclients 
	from #TempInstallClicks A, #temp B
	where ActivationDate >='Jan 01 2020'
	and A.party_code = B.party_code
	and isURLCLICKED = 'y'
	and Datediff(day,activefrom, convert(date,URLCLICKDATE,106)) >= 0
	and Datediff(day,convert(date,URLCLICKDATE,106), Install_Datetime) = 0
	group by DateAdd(Day,1,EOMonth(activefrom,-1)), Case when Datediff(day,activefrom, convert(date,URLCLICKDATE,106)) in (0,1,2)
						then  Datediff(day,activefrom, convert(date,URLCLICKDATE,106))
						 Else 4 end
	)AA,

	------------------------Conversions Analysis-----------------------------------------------------------
	--------------------------------------------------------------------------------------------------
	(Select DateAdd(Day,1,EOMonth(activefrom,-1)) acqmonth,  
	DayOnboarded = Case when Datediff(day,activefrom, convert(date,URLCLICKDATE,106)) in (0,1,2)
						then  Datediff(day,activefrom, convert(date,URLCLICKDATE,106))
				   Else 4 end,
	count(Distinct(A.party_code)) Engagedclients 
	from #TempInstallClicks A, #temp B
	where ActivationDate >='Jan 01 2020'
	and A.party_code = B.party_code
	and isURLCLICKED = 'y'
	--and Datediff(day,activefrom, convert(date,URLCLICKDATE,106)) >= 0
	--and Datediff(day,convert(date,URLCLICKDATE,106), Install_Datetime) = 0
	group by DateAdd(Day,1,EOMonth(activefrom,-1)), Case when Datediff(day,activefrom, convert(date,URLCLICKDATE,106)) in (0,1,2)
						then  Datediff(day,activefrom, convert(date,URLCLICKDATE,106))
						 Else 4 end
	)BB
where AA.acqmonth = BB.acqmonth
and AA.DayOnboarded = BB.DayOnboarded
order by AA.acqmonth, AA.DayOnboarded

-------- Composition

--drop table #composition

  select A.acqmonth as Dates, count(A.Party_Code) as Users, A.campaign
  into #Composition from (select party_code,acqmonth,Campaign  from #temp) A
  group by A.acqmonth, A.Campaign
  

  select Dates,ABMA_Organic,SSGoogleSearch,Web, ABMA,Referral,Others
  from #Composition 
  pivot(
		sum(Users)
		for campaign
		IN (ABMA_Organic,SSGoogleSearch,Web, ABMA,Referral,Others)
  ) As PivotTable
  

  select * from Dk_Temp_Acq_13Apr20