use onlineengine
select party_code as clientid, partycode_gendate
from sn_clientkyc
where b2c = 'Y' AND partycode_gendate>='2020-12-17' and 
partycode_gendate<='2021-03-17'
group by party_code, partycode_gendate