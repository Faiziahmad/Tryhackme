select[196.1.115.167].[KYC_CI].dbo.[VW_Campaign_ClientInfo]
