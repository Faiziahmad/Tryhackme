Drop table #Sent
Drop table #Clicks
Drop table #Converted

---------------------------------Sent-------------------------------------------------------------------------

Select DateAdd(Day,1,EOMonth(start_date,-1)) as ClickMonth, sum(Sent) as sent
--into #Sent 
From Onlineengine.dbo.CT_campaign_map_daily 
where message_name = '7 Days Free upto 50k'
group by DateAdd(Day,1,EOMonth(start_date,-1))

---------------------------------clicks------------------------------------------------------------------------

Select DateAdd(Day,1,EOMonth(Clickdate,-1)) as ClickMonth, Count(Profile_identity) as Clicks
--into #Clicks
From
(
Select Cast(convert(datetime,stuff(stuff(stuff(ts, 9, 0, ' '), 12, 0, ':'), 15, 0, ':')) as Date) as ClickDate,
       Profile_identity
	   From Onlineengine.dbo.CT_Clicked as A
	   inner join Onlineengine.dbo.CT_campaign_map_daily as B
	   on A.utm_campaign = B.[message id]
	   where B.message_name = '7 Days Free upto 50k'
	   ) as C
	   Group By DateAdd(Day,1,EOMonth(Clickdate,-1))
	   Order By DateAdd(Day,1,EOMonth(Clickdate,-1))

--------------------------------convert-----------------------------------------------------------------
Select ClickMonth, count(distinct party_code) 
From (
Select DateAdd(Day,1,EOMonth(clickdate,-1)) as ClickMonth, campaignname, 
       party_code 
--into #Clicks
From Communication.dbo.KG_campaignrevenuetable
where campaignname = '7 Days Free upto 50k'
      and DateAdd(Day,1,EOMonth(clickdate,-1)) > '2021-03-01'
	  ) as A
Group by Clickmonth
------
select top 10 * from Communication.dbo.KG_campaignrevenuetable

select count(distinct party_code),clickdate
from Communication.dbo.KG_campaignrevenuetable
where campaignname = '7 Days Free upto 50k'
and clickdate>='2021-05-01'
group by clickdate

select top 10 * from Communication.dbo.KG_campaignrevenuetable
--------------------------------Convert----------------------------------------------------------------

Select DateAdd(Day,1,EOMonth(balancedate,-1)) as ConversionMonth, campaignname, 
       Round(Sum(Dpc)/30,0) as Revenue
--into #Converted
From Communication.dbo.KG_campaignrevenuetable
where campaignname = '7 Days Free upto 50k'
      and balancedate >= clickdate
Group by DateAdd(Day,1,EOMonth(balancedate,-1)), campaignname

------------------------------------Cohort Analysis----------------------------------

Select DateAdd(Day,1,EOMonth(Clickdate,-1)) as clickMonth, 
       DateAdd(Day,1,EOMonth(balancedate,-1)) as balanceMonth, 
	   count(distinct party_code) as Converted,
       round(Sum(Dpc)/30,0) as Revenue
From Communication.dbo.KG_campaignrevenuetable
where campaignname = '7 Days Free upto 50k'
Group by DateAdd(Day,1,EOMonth(Clickdate,-1)), DateAdd(Day,1,EOMonth(balancedate,-1))

