Drop table #AM_OnR_B2C
drop table #AM_OnR_B2CFNO
drop table #Revenue

Select * into #AM_OnR_B2C from
(select * from AM_OnR_B2C) a

Select * into #AM_OnR_B2CFNO from
(Select party_code, minsaudadate, minclick_date, minclick_datetime, clicked_on,
UC, Conversion_Type, owner_name, Duplicate,onboarded_date, Prev_Sauda_Category,
DayCat_any from AM_OnR_B2CFNO) ab 

Select * into #Revenue from
(Select * from #AM_OnR_B2C
union
Select * from #AM_OnR_B2CFNO) abc

/*Select * into #Revenue from
(Select distinct party_code, Conversion_Type, owner_name from #AM_OnR_B2C
union
Select party_code, Conversion_Type, owner_name from #AM_OnR_B2CFNO ) abc
*/
---Drop table #Revenue
----Select * from #Revenue
----select top 10 * from [OnlineEngine].[dbo].AS_OrderCountData

/*Select party_code, Conversion_type from 
#Revenue A,[OnlineEngine].[dbo].AS_OrderCountData B
where A.party_code=B.partycode
and B.sauda_date*/



------------------------------------------------------Revenue Calculation Categorywise----------------
Drop table #AM_B2C_Revenue
Drop table #AM_B2CComm_Revenue
Drop table #AM_FNOB2C_Revenue
Drop table #AM_CurrB2C_Revenue
Drop Table #AM_Campaign_Rev



Select party_code,minclick_date,minsaudadate,Clicked_on,Conversion_Type,owner_Name,datcat_any,sauda_date,OC,Revenue into #AM_B2C_Revenue
from
(Select C.party_code,C.minclick_date,C.minsaudadate,C.Clicked_on,C.Conversion_Type,C.owner_Name,C.datcat_any,o.sauda_date,o.OC, o.Brokerage as Revenue
from #Revenue C, OnlineEngine.dbo.AS_OrderCountData O
where C.party_code = O.party_code
and C.Conversion_Type = 'B2C_Campaign'
and C.minsaudadate <= o.sauda_date) abc
---select * from #AM_B2C_Revenue
---drop table #AM_B2C_Revenue
---select top 100 * from OnlineEngine.dbo.AS_OrderCountData

----------------------------B2C Comm Campaign Revenue-------------
Select party_code,minclick_date,minsaudadate,Clicked_on,Conversion_Type,owner_Name,datcat_any,sauda_date,OC,Revenue into #AM_B2CComm_Revenue
from
(Select C.party_code,C.minclick_date,C.minsaudadate,C.Clicked_on,C.Conversion_Type,C.owner_Name,C.datcat_any,o.sauda_date,o.OC, o.Brokerage as Revenue
from #Revenue C, OnlineEngine.dbo.AS_OrderCountData O
where C.party_code = O.party_code
and C.Conversion_Type = 'B2C_Comm_Campaign'
and C.minsaudadate <= o.sauda_date
and o.INST_Type like 'COMM') abc
---select * from #AM_B2CComm_Revenue

----------------------------B2C FNO Campaign Revenue-------------
Select party_code,minclick_date,minsaudadate,Clicked_on,Conversion_Type,owner_Name,datcat_any,sauda_date,OC,Revenue into #AM_FNOB2C_Revenue
from
(Select C.party_code,C.minclick_date,C.minsaudadate,C.Clicked_on,C.Conversion_Type,C.owner_Name,C.datcat_any,o.sauda_date,o.OC, o.Brokerage as Revenue
from #Revenue C, OnlineEngine.dbo.AS_OrderCountData O
where C.party_code = O.party_code
and C.Conversion_Type = 'FNO_B2C_Campaign'
and C.minsaudadate <= o.sauda_date
And INST_Type in ('FUTIDX', 'FUTSTK', 'OPTIDX', 'OPTSTK')) abc
---select * from #AM_FNOB2C_Revenue

----------------------------B2C Currency Campaign Revenue-------------
Select party_code,minclick_date,minsaudadate,Clicked_on,Conversion_Type,owner_Name,datcat_any,sauda_date,OC,Revenue into #AM_CurrB2C_Revenue
from
(Select C.party_code,C.minclick_date,C.minsaudadate,C.Clicked_on,C.Conversion_Type,C.owner_Name,C.datcat_any,o.sauda_date,o.OC, o.Brokerage as Revenue
from #Revenue C, OnlineEngine.dbo.AS_OrderCountData O
where C.party_code = O.party_code
and C.Conversion_Type = 'Curr_B2C_Campaign'
and C.minsaudadate <= o.sauda_date
And INST_Type like 'Currency') abc
---select * from #AM_CurrB2C_Revenue

/*
---------------------------B2B Campaign Revenue-----------------
Select party_code,minclick_date,minsaudadate,Clicked_on,Conversion_Type,owner_Name,datcat_any,sauda_date,OC,Revenue into #AM_B2B_Revenue
from
(Select C.party_code,C.minclick_date,C.minsaudadate,C.Clicked_on,C.Conversion_Type,C.owner_Name,C.datcat_any,o.sauda_date,o.OC, o.Brokerage as Revenue
from #Revenue C, onlineengine.dbo.UP_B2B_OrderCountData O
where C.party_code = O.party_code
and C.Conversion_Type= 'B2B_Campaign'
and C.minsaudadate <= o.sauda_date) abc
---select * from #AM_B2B_Revenue
-----select top 100 * from onlineengine.dbo.UP_B2B_OrderCountData

----------------------------B2B Comm Campaign Revenue-------------
Select party_code,minclick_date,sauda_date,Clicked_on,[Type],owner_Name,OC,Revenue into #AM_B2BComm_Revenue
from
(Select C.party_code,C.minclick_date,C.minsaudadate,C.Clicked_on,C.[Type],C.owner_Name,O.sauda_date,o.OC, o.Brokerage as Revenue
from AM_OnR_Conversions_Unique C, onlineengine.dbo.UP_B2B_OrderCountData O
where C.party_code = O.party_code
and C.[Type] = 'B2B_Comm_Campaign'
and C.minsaudadate <= o.sauda_date
and o.INST_Type like 'COMM') abc
---select * from #AM_B2BComm_Revenue

----------------------------B2B FNO Campaign Revenue-------------
Select party_code,minclick_date,sauda_date,Clicked_on,[Type],owner_Name,OC,Revenue into #AM_FNOB2B_Revenue
from
(Select C.party_code,C.minclick_date,C.minsaudadate,C.Clicked_on,C.[Type],C.owner_Name,O.sauda_date,o.OC, o.Brokerage as Revenue
from AM_OnR_Conversions_Unique C, onlineengine.dbo.UP_B2B_OrderCountData O
where C.party_code = O.party_code
and C.[Type] = 'FNO_B2B_Campaign'
and C.minsaudadate <= o.sauda_date
And INST_Type in ('FUTIDX', 'FUTSTK', 'OPTIDX', 'OPTSTK')) abc
---select * from #AM_FNOB2B_Revenue
*/
Select * Into #AM_Campaign_Rev
From
(	Select * From #AM_B2C_Revenue
	Union All
	Select * From #AM_B2CComm_Revenue
	Union All
	select * from #AM_FNOB2C_Revenue
	Union All
	Select * From #AM_CurrB2C_Revenue
)AMRevenue

Select * from #AM_Campaign_Rev

Create table AM_OnR_RevenueAll
(party_code varchar(40),minclick_date datetime, minsaudadate datetime, clicked_on varchar(200),
 Conversion_Type varchar(40), owner_name varchar(40), DayCat_any varchar(40),sauda_date datetime, OC float, Revenue float)

insert into AM_OnR_RevenueAll
select * from #AM_Campaign_Rev
----select * from AM_OnR_RevenueAll2
-----drop table AM_OnR_RevenueAll
----Select * from #AM_Campaign_Rev
-----drop table #AM_Campaign_Rev


select * from #AM_Campaign_Rev where sauda_date >'2020-09-28'

----------------------------------------
---------------Trading days a month-------------
select [month], count(1) from onlineengine.dbo.SN_TradingDays
where TradingDay>='2021-01-01' and TradingDay <'2022-03-31'
group by [month]
order by [month] 

-----------------------------------------
----------Sumans Query for Revenue--------
select b.sauda_Date, b.brokerage
into #OffersRevenue
from AM_OnR_B2C A,
onlineengine.[dbo].[AS_OrderCountData] B with (nolock)
where A.Party_code = B.Party_code
and A.minsaudadate <= B.sauda_date

select * from  #OffersRevenue

----------------------------------------------------------------------------------
-------------------------------------------Segment wise Revenue----------------

Select * from AM_OnR_RevenueAll
where Conversion_Type='B2C_Campaign'
and DayCat_any like 'Activation%'
and party_code not in (select distinct party_code from SN_CampaignClientsConverted_FY2021)

Select * from AM_OnR_RevenueAll
where Conversion_Type='B2C_Campaign'
and DayCat_any like 'Reactivation%'
and party_code not in (select distinct party_code from SN_CampaignClientsConverted_FY2021)

Select * from AM_OnR_RevenueAll
where Conversion_Type in ('B2C_Comm_Campaign','Curr_B2C_Campaign','FNO_B2C_Campaign')

-----> 30 days revenue------
Select * from AM_OnR_RevenueAll
where Conversion_Type='B2C_Campaign'
and DayCat_any in ('Activation 30-60 days','Activation 60-90days', 'Activation 90-180days','Activation >180days')
and party_code not in (select distinct party_code from SN_CampaignClientsConverted_FY2021)

Select * from AM_OnR_RevenueAll
where Conversion_Type in ('B2C_Comm_Campaign','Curr_B2C_Campaign','FNO_B2C_Campaign')
and DayCat_any not in ('Activation 5-30')


select top 10 * from AM_OnR_B2C

-----------------------------------------------------------------------------------------------------
----------------NON overlap revenue for B2C Activation, Reactivation, In app Reactivation------------

Select * from AM_ActReactInapp_unique_Nonoverlap

drop table #AM_B2C_Revenue

Select party_code,minsaudadate, daycat_any,sauda_date,OC,Revenue into #AM_B2C_Revenue
from
(Select C.party_code,C.minsaudadate,C.daycat_any,o.sauda_date,o.OC, o.Brokerage as Revenue
from AM_ActReactInapp_unique_Nonoverlap C, OnlineEngine.dbo.AS_OrderCountData O
where C.party_code = O.party_code
and C.minsaudadate <= o.sauda_date
and o.sauda_date <= '2020-12-31') abc

-----select * from #AM_B2C_Revenue

Create Table AM_ActReactInapp_unique_Nonoverlap_Rev
(party_code varchar(40), misaudadate datetime, daycat_any varchar(40), sauda_date date, OC int, Revenue float)
