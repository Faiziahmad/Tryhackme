Select offer_name ,Concat(offer_message_what,' ',offer_message_howmuch,' ',offer_message_action) as merdge,created_by 
From [OnlineEngine].[dbo].[AJ_Offers_Metadata]


select * from (select * from #AJ_OffersClick
left join #AJ_Metadata 
on clicked_on like merdge + '%' ) abc