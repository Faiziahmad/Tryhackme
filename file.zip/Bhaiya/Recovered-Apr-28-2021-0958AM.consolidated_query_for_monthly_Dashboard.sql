use communication
drop table #actdata
drop table #reactdata

select * from RJ_OffersCard_Revenue_and_Conversion_2122 where minsaudadate>='2021-04-01'

select max (minsaudadate) from RJ_OffersCard_Revenue_and_Conversion_2122

select * into #actdata from 
	------B2C activation conversions------------
	(select distinct party_code,category='Activation' from RJ_OffersCard_Revenue_and_Conversion_2122
    where minsaudadate >='2021-04-01'
	and minsaudadate <'2021-04-30'
	and Owner_Name like 'Suman%'
	and CampaignName like 'First Activation%' or Campaignname like 'FA_%') a


select * into #reactdata from 
	------B2C Reactivation conversions------------
	(select distinct party_code,category='ReActivation' from RJ_OffersCard_Revenue_and_Conversion_2122
    where minsaudadate >='2021-04-01'
	and minsaudadate <'2021-04-30'
	and Owner_Name like 'Suman%'
	and CampaignName like 'Reactivation%') b

drop table #inappdata 
select * into #inappdata from 
  (select distinct profile_identity as party_code,category='Inapp' from AM_Inapp_React where 
   min_saudadate between '2021-03-01' and '2021-03-31') c

drop table #nonoverlaponrwithinonr 

select *,ROW_NUMBER() Over (partition by party_code
order by category asc) as identical into #nonoverlaponrwithinonr from 
(select party_code,category from #inappdata
union ALL 
select party_code,category from #reactdata
union ALL
select party_code,category from #actdata) d
delete from #nonoverlaponrwithinonr where identical>1

select * from #nonoverlaponrwithinonr 
--- select * from #nonoverlaponrwithinonr where minsaudadate is not null----
--- Alter Table to match with AM_ONR_b2c schema ----
alter table #nonoverlaponrwithinonr
add minsaudadate datetime,minclick_date datetime, minclick_datetime datetime,clicked_on datetime,uc varchar(40),
owner_name varchar(40),onboarded_date datetime,prev_sauda_any datetime,datcat_any varchar(40)

--- Updating Minsaudate and Owner_name -----
update A
set minsaudadate = B.minsaudadate, owner_name = b.Owner_Name
from #nonoverlaponrwithinonr A, OffersCard_Revenue_and_Conversion B
where A.party_code = B.Party_code

--- deleting inapp data as inapp is getting stored in AM_Inapp_Data table --- 
delete from #nonoverlaponrwithinonr where category='Inapp'

--- Fetching Blank Sauda Date ---- 
select * from #nonoverlaponrwithinonr where minsaudadate is null

---- Updating Minclick_date,Minclick_datetime,clicked_on data ---- 
update A
set minclick_datetime = B.clickdate, minclick_date = convert(date,left(b.clickdate,8),106)
from #nonoverlaponrwithinonr A, SN_CampaignClientsConverted_FY2021 B
where A.party_code = B.Party_code

---- Updating Onboarding Date ---- 
update A
set onboarded_date = B.ActiveFrom
from #nonoverlaponrwithinonr A, [OnlineEngine].[dbo].[SN_ClientKYC] b
where A.party_code = B.Party_code

select * from #nonoverlaponrwithinonr
select * from am_onr_b2c
---- Updating Previous Sauda Date ---- 
update A
set prev_sauda_any = LAG(b.sauda_date, 1) over(partition by b.party_code order by row_no asc)
from #nonoverlaponrwithinonr A, #aat b
where A.party_code = B.Party_code

----
(select party_code, LAG(sauda_date,1) over(partition by party_code order by Row_No asc) as Prev_Sauda, sauda_date into #Any_Trade
from

select * into #aat from
(select distinct(party_code),max(sauda_date),ROW_NUMBER() Over (partition by party_code order by sauda_date asc) as Row_No
from [OnlineEngine].[dbo].AS_OrderCountData
where party_code in (select distinct party_code from #nonoverlaponrwithinonr) group by party_code,sauda_date)ae

select distinct party_code,max(sauda_date), lag(sauda_date,1) over (partition by party_code order by row_no asc) as prev_sauda
from #aat
group by party_code,sauda_date,row_no

---
(select distinct(party_code),max(sauda_date), lag(sauda_date,1) over (partition by party_code order by sauda_date asc) as prev_sauda
from [OnlineEngine].[dbo].AS_OrderCountData
where party_code in (select distinct party_code from #nonoverlaponrwithinonr) group by party_code,sauda_date)

select top 10 * from SN_CampaignClientsConverted_FY2021

select top 10 * from [onlineengine].[dbo].[sn_clientkyc]

select ClientCode, Consentdate, sauda_date, datediff(day, ActiveFrom,consentdate)DaystoConsent, sum(brokerage)
from AM_OnR_Prepaid A,
onlineengine.dbo.AS_OrderCountData B,
onlineengine.dbo.SN_ClientKYC C
where A.Clientcode = b.Party_code
and  A.ClientCode = C.Party_Code
and sauda_date >= consentdate
group by ClientCode, Consentdate, sauda_date, datediff(day, ActiveFrom,consentdate)


select * from [OnlineEngine].[dbo].[AJ_OffersCardClick_updated] where profile_identity='V178672'


-------------- select * from #nonoverlaponrwithinonr --------------------
select top 10 * from OffersCard_Revenue_and_Conversion

------- Non Overlap Data with Suman -----------
drop table #nonoverlapcount 
select * into #nonoverlapcount from 
(select party_code,category from #nonoverlaponrwithinonr
where party_code not in (select distinct party_code from SN_CampaignClientsConverted_FY2021)) e

select * into #marchdata from 
(select party_code from #nonoverlaponrwithinonrjan
union 
select party_code from AM_OnR_B2C) ee

---- use communication select top 10 * from SN_CampaignClientsConverted_FY2021 -----
#nonoverlapcount ----

select top 10 * from AM_OnR_B2C

select * into #nonoverlapcount from 
(select a.party_code,category,brokerage from #nonoverlapcount a
left join [onlineengine].[dbo].[as_ordercountdata] b
on a.party_code=b.party_code
where b.sauda_date between '2021-03-01' and '2021-03-31') f

(select a.party_code,brokerage from AM_OnR_B2C a
left join [onlineengine].[dbo].[as_ordercountdata] b
on a.party_code=b.party_code
where b.sauda_date between '2021-02-01' and '2021-02-28'
and minsaudadate<=sauda_date)

-------------------------------------------
-- Jan and Feb Data with Revenue
-------------------------------------------

drop table #janfebactdata 
select * into #janfebactdata from 
	------B2C activation conversions------------
	(select distinct party_code,minsaudadate,category='Activation' from OffersCard_Revenue_and_Conversion
    where minsaudadate >='2021-01-01'
	and minsaudadate <'2021-02-28'
	and Owner_Name like 'Suman%'
	and CampaignName not like 'Reactivation%') a

drop table #janfebreactdata
select * into #janfebreactdata from 
	------B2C Reactivation conversions------------
	(select distinct party_code,minsaudadate,category='ReActivation' from OffersCard_Revenue_and_Conversion
    where minsaudadate >='2021-01-01'
	and minsaudadate <'2021-02-28'
	and Owner_Name like 'Suman%'
	and CampaignName like 'Reactivation%') b

drop table #janfebinappdata 
select * into #janfebinappdata from 
  (select distinct profile_identity as party_code,min_saudadate,category='Inapp' from AM_Inapp_React where 
   min_saudadate between '2021-01-01' and '2021-02-28') c

   select * from AM_Inapp_React where min_saudadate>='2021-03-01'

-- UNION DATA

drop table #janfebnonoverlaponrwithinonr
select *,ROW_NUMBER() Over (partition by party_code
order by category asc) as identical into #janfebnonoverlaponrwithinonr from 
(select * from #janfebinappdata
union ALL 
select * from #janfebreactdata
union ALL
select * from #janfebactdata) d
delete from #janfebnonoverlaponrwithinonr where identical>1

select * from #janfebnonoverlaponrwithinonr
select * from #janfebnonoverlapcount 
------- Non Overlap Data with Suman -----------
drop table #janfebnonoverlapcount 
select * into #janfebnonoverlapcount from 
(select party_code,category,min_saudadate from #janfebnonoverlaponrwithinonr
where party_code not in (select distinct party_code from SN_CampaignClientsConverted_FY2021)) e

select * from AM_OnR_B2C 

insert into AM_OnR_B2C
select party_code,min_saudadate as minsaudadate,minclick_date,minclick_datetime,clicked_on,UC,conversion_type,
owner_name,duplicate,onboarded_date,prev_sauda_any,datcat_any from  #janfebnonoverlapcount

alter table #janfebnonoverlapcount 
add minclick_date datetime, minclick_datetime datetime,clicked_on datetime,uc varchar(40),
owner_name varchar(40),onboarded_date datetime,prev_sauda_any datetime,datcat_any varchar(40)
add Conversion_Type varchar(40), duplicate varchar(40)

alter table #janfebnonoverlapcount 
add Conversion_Type varchar(40), duplicate varchar(40)
--- Updating Minsaudate and Owner_name -----
update A
owner_name = b.Owner_Name
from #janfebnonoverlapcount A, OffersCard_Revenue_and_Conversion B
where A.party_code = B.Party_code


---- Updating Minclick_date,Minclick_datetime,clicked_on data ---- 
update A
set minclick_datetime = B.clickdate, minclick_date = convert(date,left(b.clickdate,8),106)
from #janfebnonoverlapcount  A, SN_CampaignClientsConverted_FY2021 B
where A.party_code = B.Party_code

---- Updating Onboarding Date ---- 
update A
set onboarded_date = B.ActiveFrom
from #nonoverlaponrwithinonr A, [OnlineEngine].[dbo].[SN_ClientKYC] b
where A.party_code = B.Party_code



SELECT * FROM AM_OnR_B2C

INSERT INTO AM_OnR_B2C
SELECT PARTY_CODE,MIN_SAUDADATE as minsaudadate FROM #janfebnonoverlapcount

select max(minsaudadate) from AM_OnR_B2C

select max(minsaudadate) from SN_CampaignClientsConverted_FY2021

select top 10 * from OffersCard_Revenue_and_Conversion

-- REVENUE JAN & FEB -----
(select a.party_code,sauda_date,min_saudadate,brokerage from #janfebnonoverlapcount a
left join [onlineengine].[dbo].[as_ordercountdata] b
on a.party_code=b.party_code
where b.sauda_date between '2021-03-01' and '2021-03-31'
and min_saudadate<=sauda_date
AND BROKERAGE>0)


where party_code not in (select distinct party_code from SN_CampaignClientsConverted_FY2021)) e

select top 10 * from AM_OnR_B2C 

select top 10 * from [onlineengine].[dbo].[as_ordercountdata]

select top 10 * from SN_CampaignClientsConverted_FY2021

/*select * into #nonoverlapdetails from 
(select distinct party_code,sauda_date,minsaudadate,campaign,revenues,owner_name,campaignname,targetset,rowid 
from OffersCard_Revenue_and_Conversion where party_code in (select party_code from #nonoverlapcount)
and rowid='1' and minsaudadate >='2021-01-01'
	and minsaudadate <'2021-01-31')*/

--------------------------------------------------------------------------------------------------------------------
--- select top 10 * from OffersCard_Revenue_and_Conversion-----


--- Non-Overlap with Suman - Activation ------------
select month(minsaudadate), COUNT(distinct Party_code) from AM_OnR_B2C 
where datcat_any like 'Activation%'
and party_code  not in (select distinct party_code from SN_CampaignClientsConverted_FY2021 where campaigntype like 'First Activation%')
group by month(minsaudadate)
order by month(minsaudadate)

-----Overlap with Suman - Reactivation---------
select month(minsaudadate), COUNT(distinct Party_code) from AM_OnR_B2C 
where datcat_any like 'Reactivation%'	
and party_code not in (select distinct party_code from SN_CampaignClientsConverted_FY2021 where campaigntype like  'Re-Activation%')
group by month(minsaudadate)
order by month(minsaudadate)


select * from SN_CampaignClientsConverted_FY2021 where clickdate between '2021-01-01' and '2021-01-31'

select top 5 * from OffersCard_Revenue_and_Conversion


----- REVENUE --------
select ClientCode, Consentdate, sauda_date, datediff(day, ActiveFrom,consentdate)DaystoConsent, sum(brokerage)
from AM_OnR_Prepaid A,
onlineengine.dbo.AS_OrderCountData B,
onlineengine.dbo.SN_ClientKYC C
where A.Clientcode = b.Party_code
and  A.ClientCode = C.Party_Code
and sauda_date >= consentdate
group by ClientCode, Consentdate, sauda_date, datediff(day, ActiveFrom,consentdate)

SELECT TOP 10 * FROM AM_OnR_bUNDLED

select max(minsaudadate) from AM_ONR_B2CFNO

use communication
select top 10 * from OffersCard_Revenue_and_Conversion


----------- Segment Conversion Data ----- 
	select distinct party_code from OffersCard_Revenue_and_Conversion
    where minsaudadate >='2021-02-01'
	and minsaudadate <'2021-02-28'
	and Owner_Name like 'Akhilesh%'