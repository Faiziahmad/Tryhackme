use OnlineEngine

	declare @StartDate DATETIME=NULL
	set @StartDate='2020-12-01'
	Declare @ToDate Datetime = '2021-01-01'

--------------------------------- Cash Start --------------------------------------
--	PRINT @StartDate
	
--	drop table #cashpre
	SELECT sauda_date,Party_code,tmark,order_no,Qty,MarketRate,Brokerage, Order_Time, Trade_Time
	INTO #CashPre	
	FROM [196.1.115.196].Msajag.dbo. Common_contract_data WITH (NOLOCK)
	WHERE exchange in('NSE','BSE') AND Segment='capital' 		
		AND Sauda_date>=@StartDate AND Sauda_date<@ToDate	

--	drop table #Del
	SELECT DISTINCT sauda_date,Party_code,order_no
	INTO #Del
	FROM #CashPre
	WHERE Qty>=0 AND ISNULL(order_no,'')<>''
		AND tmark='D'

	UPDATE a
	SET a.tmark='D'
	FROM #CashPre a
		JOIN #Del b
		ON a.sauda_date=b.sauda_date  AND a.Party_code=b.Party_code AND a.order_no=b.order_no
	WHERE a.Qty=0 AND ISNULL(a.order_no,'')<>'' AND ISNULL(a.tmark,'')=''

--	drop table #MinSaudaTimeCash_1
	select CONVERT(DATE,sauda_date)sauda_date, Party_code, tmark, min(order_time) MinSaudaTime	
	into #MinSaudaTimeCash_1
	FROM #CashPre		
	where ISNULL(order_time,'')<>'' and order_time <> '00:00:00' 
	GROUP BY CONVERT(DATE,sauda_date), Party_code, tmark

--	drop table #MinSaudaTimeCash_2
	select CONVERT(DATE,sauda_date)sauda_date, Party_code, tmark, min(Trade_Time) MinTradeTime	
	into #MinSaudaTimeCash_2
	FROM #CashPre		
	where ISNULL(Trade_Time,'') <>'' and Trade_Time <> '00:00:00'
	GROUP BY CONVERT(DATE,sauda_date), Party_code, tmark

--	drop table #MinSaudaTimeCash_3
	select sauda_date, Party_code, tmark, min(MinSaudaTime) MinSaudaTime
	into #MinSaudaTimeCash_3
	from 
	(select sauda_date, Party_code, tmark, MinSaudaTime from #MinSaudaTimeCash_1
	UNION ALL
	select sauda_date, Party_code, tmark, MinTradeTime MinSaudaTime from #MinSaudaTimeCash_2)A
	group by sauda_date, Party_code, tmark

--	drop table #MinSaudaTimeCash_Final
	select sauda_date, Party_code, 
	CASE WHEN tmark='d' THEN 'Del' WHEN tmark='' THEN 'Intr' ELSE '' END INST_Type, MinSaudaTime
	into #MinSaudaTimeCash_Final
	from #MinSaudaTimeCash_3

	--------------------------------- Cash End --------------------------------------
	--------------------------------- FNO Start --------------------------------------

--	drop table #MinSaudaTimeFO_1
	SELECT CONVERT(DATE,sauda_date)sauda_date,Party_code, order_no, min(Order_Time) MinSaudaTime
	INTO #MinSaudaTimeFO_1
	FROM [196.1.115.196].Msajag.dbo.Common_contract_data WITH (NOLOCK)
	WHERE exchange='NSE' and Segment='Futures'
	and Sauda_date >=@StartDate and Sauda_date <@ToDate 		
	and ISNULL(Order_Time,'') <>'' and Order_Time <> '00:00:00'
	GROUP BY CONVERT(DATE,sauda_date),Party_code, order_no
	
--	drop table #MinSaudaTimeFO_2
	SELECT CONVERT(DATE,sauda_date)sauda_date,Party_code, order_no, min(Trade_Time) MinSaudaTime
	INTO #MinSaudaTimeFO_2
	FROM [196.1.115.196].Msajag.dbo.Common_contract_data WITH (NOLOCK)
	WHERE exchange='NSE' and Segment='Futures'
	and Sauda_date >=@StartDate and Sauda_date <@ToDate 		
	and ISNULL(Trade_Time,'') <>'' and Trade_Time <> '00:00:00'
	GROUP BY CONVERT(DATE,sauda_date),Party_code, order_no
	
--	drop table #MinSaudaTimeFO_3
	SELECT sauda_date, Party_code, order_no, min(MinSaudaTime) MinSaudaTime
	INTO #MinSaudaTimeFO_3
	from 
	(select sauda_date, Party_code, order_no, MinSaudaTime from #MinSaudaTimeFO_1
	UNION ALL
	select sauda_date, Party_code, order_no, MinSaudaTime from #MinSaudaTimeFO_2)F
	group by sauda_date, Party_code, order_no

--	drop table #FoSettlement2
	SELECT CONVERT(DATE,Sauda_date)Sauda_date,Party_code,Inst_type,Order_no
	INTO #FoSettlement2
	FROM
	(
		select Sauda_date,Party_code,Inst_type,Order_no
		from [196.1.115.200]. nsefo.dbo.FoSettlement a with (nolock)		
		where a.Sauda_date >=@StartDate and a.Sauda_date <@ToDate		
		union all		
		select  Sauda_date,Party_code,Inst_type ,Order_no
		from  [196.1.115.200]. pradnya.dbo. History_Fosettlement_Nsefo a with(nolock)		
		where a.Sauda_date >=@StartDate and a.Sauda_date <@ToDate		
	)dt
	GROUP BY CONVERT(DATE,Sauda_date),Party_code,Inst_type,Order_no
	
--	drop table #MinSaudaTimeFO_4
	select a.sauda_date, a.Party_code, a.order_no, a.MinSaudaTime, b.inst_type
	into #MinSaudaTimeFO_4
	from #MinSaudaTimeFO_3 a
	left outer join #FoSettlement2 b
	on a.sauda_date=b.Sauda_date
	and a.order_no = b.order_no
	and a.party_code = b.party_code

--	drop table #MinSaudaTimeFO_Final	
	select sauda_date, party_code, inst_type, min(MinSaudaTime) MinSaudaTime
	into #MinSaudaTimeFO_Final
	from #MinSaudaTimeFO_4
	group by sauda_date, party_code, inst_type
	
	--------------------------------- FNO End --------------------------------------
	--------------------------------- COMM Start --------------------------------------

--	drop table #MinSaudaTimeComm_Final
	select cast(sauda_date as date)sauda_date, Party_code, 'COMM' INST_Type, min(trade_time) MinSaudaTime
	into #MinSaudaTimeComm_Final
	from [196.1.115.204].mcdx.dbo.COMMON_CONTRACT_DATA
	where Sauda_date >=@StartDate and Sauda_date <@ToDate
	and trade_time <>''	and trade_time <> '00:00:00'
	group by cast(sauda_date as date), Party_code

	--------------------------------- COMM End --------------------------------------
	--------------------------------- Currency Start --------------------------------------
--	drop table #MinSaudaTimeCurr_1
	Select CONVERT(DATE,sauda_date) sauda_date, party_code, min(order_time) MinSaudaTime
	into #MinSaudaTimeCurr_1
	from [196.1.115.196].Msajag.dbo.Common_contract_data with (nolock)
	where  exchange='NSX' AND Segment='Futures' 
			AND	Sauda_date >=@StartDate AND Sauda_date <@ToDate
			and isnull(order_time,'') <>'' and order_time <> '00:00:00'
	group by CONVERT(DATE,sauda_date), party_code

--	drop table #MinSaudaTimeCurr_2
	Select CONVERT(DATE,sauda_date) sauda_date, party_code, min(trade_time) MinSaudaTime
	into #MinSaudaTimeCurr_2
	from [196.1.115.196].Msajag.dbo.Common_contract_data with (nolock)
	where  exchange='NSX' AND Segment='Futures' 
			AND	Sauda_date >=@StartDate AND Sauda_date <@ToDate 	
			and isnull(trade_time,'') <>'' and trade_time <> '00:00:00'
	group by CONVERT(DATE,sauda_date), party_code
	
	--drop table #MinSaudaTimeCurr_Final
	select sauda_date, Party_code, 'Currency' Inst_Type, min(MinSaudaTime) MinSaudaTime
	into #MinSaudaTimeCurr_Final
	from
		(
		select * from #MinSaudaTimeCurr_1
		UNION ALL
		select * from #MinSaudaTimeCurr_2
		) A
	group by sauda_date, Party_code

	--------------------------------- Currency End --------------------------------------
	--------------------------------- Final Insert --------------------------------------

	insert into SN_MinSaudaTime
	select sauda_date, party_code, inst_type, MinsaudaTime from #MinSaudaTimeCash_Final where sauda_date>=@StartDate
	UNION ALL
	select sauda_date, party_code, inst_type, MinsaudaTime from #MinSaudaTimeFO_Final where sauda_date>=@StartDate
	UNION ALL
	select sauda_date, party_code, inst_type, MinsaudaTime from #MinSaudaTimeComm_Final where sauda_date>=@StartDate
	UNION ALL
	select sauda_date, party_code, inst_type, MinsaudaTime from #MinSaudaTimeCurr_Final where sauda_date>=@StartDate
		

	DROP TABLE #CashPre
	DROP TABLE #Del
	DROP TABLE #MinSaudaTimeCash_1
	DROP TABLE #MinSaudaTimeCash_2	
	DROP TABLE #MinSaudaTimeCash_3
	DROP TABLE #MinSaudaTimeCash_Final
	DROP TABLE #FoSettlement2
	DROP TABLE #MinSaudaTimeFO_1
	DROP TABLE #MinSaudaTimeFO_2
	DROP TABLE #MinSaudaTimeFO_3
	DROP TABLE #MinSaudaTimeFO_4
	DROP TABLE #MinSaudaTimeFO_Final
	DROP TABLE #MinSaudaTimeComm_Final
	DROP TABLE #MinSaudaTimeCurr_1
	DROP TABLE #MinSaudaTimeCurr_2
	DROP TABLE #MinSaudaTimeCurr_Final

