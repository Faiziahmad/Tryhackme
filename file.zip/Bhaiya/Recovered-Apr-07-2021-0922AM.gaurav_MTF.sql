drop table #uniqueclicks
Select DateAdd(Day,1,EOMonth(creationdate,-1)) as Months, Count(distinct ClientCode) as Clicks
into #uniqueclicks
FROM [196.1.115.167].KYC.dbo.VW_Campaign_Consent_ALL
Where CampaignType IN ('MTFPLAN') and pushedsource = 'onr'
Group by DateAdd(Day,1,EOMonth(creationdate,-1))
Order by DateAdd(Day,1,EOMonth(creationdate,-1))
drop table #uniqueconverted
select DateAdd(Day,1,EOMonth(consentdate,-1)) as Months,
       count(case when voucherplanopted = 99 then a.ClientCode End)as Plan1,
	   count(case when voucherplanopted = 249 then a.ClientCode End)as Plan2,
	   count(case when voucherplanopted = 499 then a.ClientCode End)as Plan3,
	   count(case when voucherplanopted = 999 then a.ClientCode End)as Plan4,
	   count (a.clientcode) as Total,
	   Sum (VoucherPlanOpted) as Total_Revenue
	   into #uniqueconverted
From [onlineengine].[dbo].[VW_MTF_Plan_ClientInfo] as A 
Left join [196.1.115.167].KYC.dbo.VW_Campaign_Consent_ALL as B
on A.Clientcode = B. Clientcode
WHERE CampaignType In ('MTFPLAN') and pushedsource = 'onr'
Group by DateAdd(Day,1,EOMonth(consentdate,-1))
order by DateAdd(Day,1,EOMonth(consentdate,-1))
Select A.Months, B.Clicks, Plan1 as '99', Plan2 as '249', Plan3 as '499', Plan4 as '999', Total, Total_Revenue
From #uniqueconverted as A
inner join #uniqueclicks as B
on A.Months = B.Months



with Revenue_OnR(Clientcode, PushedSource) as
(
Select ClientCode, PushedSource
From [196.1.115.167].KYC.dbo.VW_Campaign_Consent_ALL with(nolock)
Where Clientcode in (Select clientcode from [onlineengine].[dbo].[VW_MTF_Plan_ClientInfo]) and Pushedsource = 'onr'and CampaignType = 'MTFPLAN'
)
Select B.consentDate, A.Clientcode, Pushedsource, B.VoucherPlanOpted
From Revenue_OnR as A inner join [onlineengine].[dbo].[VW_MTF_Plan_ClientInfo] as B
on A.ClientCode = B.ClientCode
Where cast(B.consentDate as Date) between '2021-03-01' and '2021-03-31'

 `	333333333                                                                               3																				we
select * from [onlineengine].[dbo].[VW_MTF_Plan_ClientInfo]

select * from [196.1.115.167].KYC.dbo.VW_Campaign_Consent_ALL/l

select distinct campaigntype from [196.1.115.167].KYC.dbo.VW_Campaign_Consent_ALL where campaigntype like 
'%MTF%'

'MTFBUNDLED'

select distinct campaigntype from [196.1.115.167].KYC.dbo.VW_Campaign_Consent_ALL 
where campaigntype like '%INT%'

with Revenue_OnR(Clientcode, PushedSource) as
(
Select ClientCode, PushedSource
From [196.1.115.167].KYC.dbo.VW_Campaign_Consent_ALL with(nolock)
Where Clientcode in (Select clientcode from [onlineengine].[dbo].[VW_MTF_Plan_ClientInfo]) and Pushedsource = 'onr'and CampaignType = 'MTFBUNDLED'
)
Select B.consentDate, A.Clientcode, Pushedsource, B.VoucherPlanOpted
From Revenue_OnR as A inner join [onlineengine].[dbo].[VW_MTF_Plan_ClientInfo] as B
on A.ClientCode = B.ClientCode
Where cast(B.consentDate as Date) between '2021-03-01' and '2021-03-31'
