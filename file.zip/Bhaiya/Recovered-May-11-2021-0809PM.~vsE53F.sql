drop table #febmarchdata 
select * into #febmarchdata from 
	------B2C activation conversions------------
	(select distinct party_code,minsaudadate,category='Activation' from OffersCard_Revenue_and_Conversion
    where minsaudadate >='2021-03-01'
	and minsaudadate <'2021-04-30'
	and Owner_Name like 'Suman%'
	and CampaignName not like 'Reactivation%') a