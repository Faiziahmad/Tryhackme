use onlineengine
select * from ipoallotment

select sauda_date,party_code,inst_type,oc,brokerage,t_o,b2c,ipo_name='Tatvan' from AS_OrderCountData
where sauda_date>='2021-07-16' and party_code in 
(select client_code from ipoallotment  where ipo_name='Tatvan')

select party_code,sum(brokerage) from AS_OrderCountData a, ipo_allot_arpu b
where sauda_date>='2021-04-01' and party_code in 
(select [client code] from ipo_allot_arpu)
group by  party_code

select party_code,sum(brokerage) from AS_OrderCountData a, ipo_allot_arpu b
where sauda_date>=convert(varchar,(First_Activation_Date),23) and party_code in 
(select client_code from ipo_allot_arpu)
group by  party_code

drop table ipo_allot_arpu

select client_code,convert(varchar,(First_Activation_Date),23) from ipo_allot_arpu

select * from ipo_allot_arpu


select distinct [client code] from ipo_allot_arpu

select * from Profile360TG

A526096, M91800

insert into Profile360TG (Party_Code,createdon) values ('M91800','2021-07-30 12:39:18.073')