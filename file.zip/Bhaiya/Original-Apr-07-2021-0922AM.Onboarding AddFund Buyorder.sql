-----------------------------------------------ADD FUND------------------------------
--select top 100 * from [dbo].[AJ_FundTransferSource]
---select * from  [OnlineEngine].[dbo].[AJ_OffersCardClick_updated] where clicked_on like 'Add your 1st fund now%'

drop table #Onboarding_addfundclicks
Select * Into #Onboarding_addfundclicks
From
(Select Distinct Clicked_on,profile_identity,ts,convert(date,left(ts,8),106) as Click_Date,
convert(datetime,stuff(stuff(stuff(ts, 9, 0, ' '), 12, 0, ':'), 15, 0, ':')) as Click_DateTime From [OnlineEngine].[dbo].[AJ_OffersCardClick_updated]
Where profile_identity is not NULL
and Clicked_on like 'Add your 1st fund now%'
and convert(date,left(ts,8),106) >= '2021-03-01'
and convert(date,left(ts,8),106) <= '2021-03-31'
)a


---select * from #Onboarding_addfundclicks
drop table #addfundtemp
select * into #addfundtemp from
(Select distinct profile_identity, click_date, requestdateTime as Convertdate,[status]
from #Onboarding_addfundclicks A, [onlineengine].[dbo].[AJ_FundTransferSource] B
where A.profile_identity = B.ClientCode
and Datediff(day,click_date,cast(requestdateTime as date)) between 0 and 1
and B.status='Success'
and click_date >='2021-03-01'
and click_date <='2021-03-31'
--and cast(requestdateTime as date)<='2020-12-31'
)a

select distinct profile_identity from #addfundtemp


--------------------------------1st BUY ORDER------------------------------
drop table #Onboarding_buyorderclicks
Select * Into #Onboarding_buyorderclicks
From
(Select Distinct Clicked_on,profile_identity,ts,convert(date,left(ts,8),106) as Click_Date,
convert(datetime,stuff(stuff(stuff(ts, 9, 0, ' '), 12, 0, ':'), 15, 0, ':')) as Click_DateTime From [OnlineEngine].[dbo].[AJ_OffersCardClick_updated]
Where profile_identity is not NULL
and Clicked_on like 'Place your 1st Trade Now%'
and convert(date,left(ts,8),106) >= '2021-03-01'
and convert(date,left(ts,8),106) <= '2021-03-31'
)a

---select * from #Onboarding_buyorderclicks
----select top 100 * from OnlineEngine.dbo.AS_OrderCountData
-----select top 100 * from OnlineEngine.[dbo].[SN_MinSaudaTime]

drop table #buyordertemp 
select * into #buyordertemp from
(Select distinct profile_identity, click_date, sauda_date as minsaudadate, MinsaudaTime
from #Onboarding_buyorderclicks A, OnlineEngine.[dbo].[SN_MinSaudaTime] B
where A.profile_identity = B.Party_code
and Datediff(DAY, cast(A.Click_DateTime as date),cast(B.sauda_date as date)) between 0 and 1
and click_date >='2021-03-01'
and sauda_date<='2021-03-31'
)a

Select distinct profile_identity from #buyordertemp
Select count(distinct(profile_identity)) from #buyordertemp


----drop table #buyordertemp
---select * from #buyordertemp
select * from AM_OnR_B2C where minclick_date >= '2020-12-01'

use onlineengine