Select offer_name ,Concat(offer_message_what,' ',offer_message_howmuch,' ',offer_message_action) as merdge,created_by 
From [OnlineEngine].[dbo].[AJ_Offers_Metadata]


select * from (select * from #AJ_OffersClick
left join #AJ_Metadata 
on clicked_on like merdge + '%' ) abc



with Revenue_OnR(Clientcode, PushedSource) as
(
Select ClientCode, PushedSource
From [196.1.115.167].KYC.dbo.VW_Campaign_Consent_ALL with(nolock)
Where Clientcode in (Select clientcode from [onlineengine].[dbo].[VW_MTF_Plan_ClientInfo]) and Pushedsource = 'onr'and CampaignType = 'MTFPLAN'
)
Select B.consentDate, A.Clientcode, Pushedsource, B.VoucherPlanOpted
From Revenue_OnR as A inner join [onlineengine].[dbo].[VW_MTF_Plan_ClientInfo] as B
on A.ClientCode = B.ClientCode
Where cast(B.consentDate as Date) between '2021-02-01' and '2021-02-15'