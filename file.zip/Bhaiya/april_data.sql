-------------------------------------------
-- april and April Data with Revenue
-------------------------------------------

drop table #aprilactdata 
select * into #aprilactdata from 
	------B2C activation conversions------------
	(select distinct party_code,minsaudadate,category='Activation' from RJ_OffersCard_Revenue_and_Conversion_2122
    where minsaudadate >='2021-04-01'
	and minsaudadate <'2021-04-30'
	and Owner_Name like 'Suman%'
	and CampaignName like 'First Activation%' or Campaignname like 'FA_%') a

drop table #aprilreactdata
select * into #aprilreactdata from 
	------B2C Reactivation conversions------------
	(select distinct party_code,minsaudadate,category='ReActivation' from RJ_OffersCard_Revenue_and_Conversion_2122
    where minsaudadate >='2021-04-01'
	and minsaudadate <'2021-04-30'
	and Owner_Name like 'Suman%'
	and CampaignName like 'Reactivation%') b

drop table #aprilinappdata 
select * into #aprilinappdata from 
  (select distinct profile_identity as party_code,min_saudadate,category='Inapp' from AM_Inapp_React where 
   min_saudadate between '2021-04-01' and '2021-04-30') c

   select max(min_saudadate) from AM_Inapp_React where min_saudadate>='2021-03-01'

-- UNION DATA

drop table #aprilnonoverlaponrwithinonr
select *,ROW_NUMBER() Over (partition by party_code
order by category asc) as identical into #aprilnonoverlaponrwithinonr from 
(select * from #aprilinappdata
union ALL 
select * from #aprilreactdata
union ALL
select * from #aprilactdata) d
delete from #aprilnonoverlaponrwithinonr where identical>1

select * from #aprilnonoverlaponrwithinonr
select * from #aprilnonoverlapcount

------- Non Overlap Data with Suman -----------
drop table #aprilnonoverlapcount
select * into #aprilnonoverlapcount from 
(select party_code,category,min_saudadate from #aprilnonoverlaponrwithinonr
where party_code not in (select distinct party_code from SN_CampaignClientsConverted_FY2022)) e


select * from AM_OnR_B2C 

insert into AM_OnR_B2C
select party_code,min_saudadate as minsaudadate,minclick_date,minclick_datetime,clicked_on,UC,conversion_type,
owner_name,duplicate,onboarded_date,prev_sauda_any,datcat_any from  #aprilnonoverlapcount

alter table #aprilnonoverlapcount 
add minclick_date datetime, minclick_datetime datetime,clicked_on datetime,uc varchar(40),
owner_name varchar(40),onboarded_date datetime,prev_sauda_any datetime,datcat_any varchar(40),
Conversion_Type varchar(40), duplicate varchar(40)

alter table #aprilnonoverlapcount 
add Conversion_Type varchar(40), duplicate varchar(40)

--- Updating Minsaudate and Owner_name -----
update A
set owner_name = b.Owner_Name
from #aprilnonoverlapcount A, OffersCard_Revenue_and_Conversion B
where A.party_code = B.Party_code


---- Updating Minclick_date,Minclick_datetime,clicked_on data ---- 
update A
set minclick_datetime = B.clickdate, minclick_date = convert(date,left(b.clickdate,8),106)
from #aprilnonoverlapcount  A, SN_CampaignClientsConverted_FY2021 B
where A.party_code = B.Party_code

---- Updating Onboarding Date ---- 
update A
set onboarded_date = B.ActiveFrom
from #nonoverlaponrwithinonr A, [OnlineEngine].[dbo].[SN_ClientKYC] b
where A.party_code = B.Party_code



SELECT * FROM AM_OnR_B2C

INSERT INTO AM_OnR_B2C
SELECT PARTY_CODE,MIN_SAUDADATE as minsaudadate FROM #aprilnonoverlapcount

select max(minsaudadate) from AM_OnR_B2C

select max(minsaudadate) from SN_CampaignClientsConverted_FY2021

select top 10 * from OffersCard_Revenue_and_Conversion

-- APRIL'21 REVENUE -----
(select a.party_code,sauda_date,min_saudadate,brokerage from #aprilnonoverlapcount a
left join [onlineengine].[dbo].[as_ordercountdata] b
on a.party_code=b.party_code
where b.sauda_date between '2021-04-01' and '2021-04-30'
and min_saudadate<=sauda_date
AND BROKERAGE>0)

(select a.party_code,sauda_date,min_saudadate,brokerage from #aprilnonoverlapcount a
left join [onlineengine].[dbo].[as_ordercountdata] b
on a.party_code=b.party_code
where b.sauda_date between '2021-04-01' and '2021-04-30'
and min_saudadate<=sauda_date
AND BROKERAGE>0)


(select a.party_code,brokerage from AM_OnR_B2C a
left join [onlineengine].[dbo].[as_ordercountdata] b
on a.party_code=b.party_code
where b.sauda_date between '2021-02-01' and '2021-02-28'
and minsaudadate<'2021-03-01'
and minsaudadate<=sauda_date
and brokerage>0)


where party_code not in (select distinct party_code from SN_CampaignClientsConverted_FY2021)) e

select top 10 * from AM_OnR_B2C 

select top 10 * from [onlineengine].[dbo].[as_ordercountdata]

select top 10 * from SN_CampaignClientsConverted_FY2021

/*select * into #nonoverlapdetails from 
(select distinct party_code,sauda_date,minsaudadate,campaign,revenues,owner_name,campaignname,targetset,rowid 
from OffersCard_Revenue_and_Conversion where party_code in (select party_code from #nonoverlapcount)
and rowid='1' and minsaudadate >='2021-01-01'
	and minsaudadate <'2021-01-31')*/

--------------------------------------------------------------------------------------------------------------------
--- select top 10 * from OffersCard_Revenue_and_Conversion-----


--- Non-Overlap with Suman - Activation ------------
select month(minsaudadate), COUNT(distinct Party_code) from AM_OnR_B2C 
where datcat_any like 'Activation%'
and party_code  not in (select distinct party_code from SN_CampaignClientsConverted_FY2021 where campaigntype like 'First Activation%')
group by month(minsaudadate)
order by month(minsaudadate)

-----Overlap with Suman - Reactivation---------
select month(minsaudadate), COUNT(distinct Party_code) from AM_OnR_B2C 
where datcat_any like 'Reactivation%'	
and party_code not in (select distinct party_code from SN_CampaignClientsConverted_FY2021 where campaigntype like  'Re-Activation%')
group by month(minsaudadate)
order by month(minsaudadate)


select * from SN_CampaignClientsConverted_FY2021 where clickdate between '2021-01-01' and '2021-01-31'

select top 5 * from OffersCard_Revenue_and_Conversion


----- REVENUE --------
select ClientCode, Consentdate, sauda_date, datediff(day, ActiveFrom,consentdate)DaystoConsent, sum(brokerage)
from AM_OnR_Prepaid A,
onlineengine.dbo.AS_OrderCountData B,
onlineengine.dbo.SN_ClientKYC C
where A.Clientcode = b.Party_code
and  A.ClientCode = C.Party_Code
and sauda_date >= consentdate
group by ClientCode, Consentdate, sauda_date, datediff(day, ActiveFrom,consentdate)

SELECT TOP 10 * FROM AM_OnR_bUNDLED

select max(minsaudadate) from AM_ONR_B2CFNO

use communication
select top 10 * from OffersCard_Revenue_and_Conversion



select top 10 * from AM_OnR_B2C

select count(party_code),minsauddate from

Select minsaudadate, Count(distinct party_code) as totalclient
from AM_OnR_B2C
group by minsaudadate
