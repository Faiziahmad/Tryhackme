--drop table ##temp_datastream


/*** Prepare Data Stream ***/
select * into #temp_datastream
from 
(select  * from AD_OnB_Campaigns_Engagement
UNION ALL
select * from AD_OnB_Other_Campaigns_Engagement
UNION ALL
select  * from AD_OnB_WA_Campaigns_Engagement) A



/*** Insert Sauda Date ***/
insert into #temp_datastream ( profile_identity, ts, utm_medium, Activefrom, TAT)
select AA.party_code, AA.MinSaudaTime, 'First Sauda',AA.ActiveFrom, Datediff(DAY, ActiveFrom, cast(minsaudatime as date))  
from
(
select A.party_code, A.MinSaudaTime, B.ActiveFrom
from
(select party_code, min(cast(sauda_date as datetime)+ cast(MinsaudaTime as datetime)) as MinSaudaTime
from SN_MinSaudaTime
where party_code in (select party_code from SN_ClientKYC where B2C = 'Y' and ActiveFrom >= '2020-01-01'
and ActiveFrom < GETDATE())
group by party_code) A
left join
(select party_code, ActiveFrom from SN_ClientKYC 
where B2C = 'Y' and ActiveFrom >= '2020-01-01' and ActiveFrom < GETDATE()) B
on A.party_code = B.Party_Code) AA 



/*** Create Last event Data stream ***/

--drop table #final_temp_datastream
select profile_identity, ts, utm_medium, Activefrom, TAT, lag(utm_medium,1) over (partition by profile_identity order by ts asc) as Last_utm_campaign,
lag(ts,1) over (partition by profile_identity order by ts asc) as Last_ts into #final_temp_datastream
from #temp_datastream



alter table #final_temp_datastream
add Day_Activated varchar(40), if_selected varchar(40)



update #final_temp_datastream
set if_selected = case when DATEDIFF(MINUTE, ts, Last_ts) <= 24*60 then 'Yes' else 'No' end

update #final_temp_datastream
set Day_Activated = case when cast(A.ts as date) = B.Day0 then 'Day0'
						when cast(A.ts as date) = B.Day1 then 'Day1'
						when cast(A.ts as date) = B.Day2 then 'Day2'
						when cast(A.ts as date) = B.Day3 then 'Day3'
						when cast(A.ts as date) = B.Day4 then 'Day4'
						when cast(A.ts as date) = B.Day5 then 'Day5'
						when cast(A.ts as date) = B.Day6 then 'Day6'
						when cast(A.ts as date) = B.Day7 then 'Day7'
						when cast(A.ts as date) = B.Day8 then 'Day8'
						when cast(A.ts as date) = B.Day9 then 'Day9'
						when cast(A.ts as date) = B.Day10 then 'Day10'
						else '>Day10' end
from #final_temp_datastream A, AD_tradingday_updated B
where A.utm_medium = 'First Sauda' and cast(A.Activefrom as date) = B.Day0

drop table AD_OnB_Converted_Users

select  * into AD_OnB_Converted_Users 
from #final_temp_datastream 
where utm_medium = 'First Sauda'



alter table AD_OnB_Converted_Users
add campaign varchar(40)

update AA
set campaign = case when BB.Campaign is null then 'Referral'
						else BB.campaign end
from AD_OnB_Converted_Users AA, 
(select Party_code, (case when Channel in ('DRA') then 'DRA' 
						when Channel in ('Referral') then 'Referral'
						when Channel in ('Online') then (case when Campaign in ('ABMA','ABMA_Organic', 'SSGoogleSearch', 'Web') then Campaign 
																else 'Other' end) end) as Campaign
from SN_SalesSource_Intent) BB
where AA.profile_identity = BB.Party_code









