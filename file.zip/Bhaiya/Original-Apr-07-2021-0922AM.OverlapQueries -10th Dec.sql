---------------My Conversions-------------
-----select top 10 * from AM_OnR_B2C
select month(minsaudadate) as month_number, count (distinct party_code) as conversions from AM_OnR_B2C
group by month(minsaudadate)
order by month(minsaudadate)

select month(minsaudadate) as month_number, count(distinct party_code) as conversions from AM_OnR_B2C
where datcat_any like 'Activation%'
group by month(minsaudadate)

select month(minsaudadate) as month_number, count(distinct party_code) as conversions from AM_OnR_B2C
where datcat_any like 'Reactivation%'
group by month(minsaudadate)


--- Non-Overlap with Suman - Activation ------------
select month(minsaudadate), COUNT(distinct Party_code) from AM_OnR_B2C 
where datcat_any like 'Activation%'
and party_code  not in (select distinct party_code from SN_CampaignClientsConverted_FY2021 where campaigntype like 'First Activation%')
group by month(minsaudadate)
order by month(minsaudadate)

select top 10 * from AM_OnR_B2C

-----Overlap with Suman - Reactivation---------
select month(minsaudadate), COUNT(distinct Party_code) from AM_OnR_B2C 
where datcat_any like 'Reactivation%'
and party_code  not in (select distinct party_code from SN_CampaignClientsConverted_FY2021 where campaigntype like  'Re-Activation%')
group by month(minsaudadate)
order by month(minsaudadate)


----------------------------------------------------------------------------------------------------
-------------------------------My Category Conversions------------------------------------------
----select * from AM_OnR_B2CFNO
select month(minsaudadate) as month_number, count(distinct party_code) as conversions from AM_OnR_B2CFNO
group by month(minsaudadate)
order by month(minsaudadate)

select month(minsaudadate) as month_number, count(distinct party_code) as conversions from AM_OnR_B2CFNO
where daycat_any like 'Activation%'
group by month(minsaudadate)

select month(minsaudadate) as month_number, count(distinct party_code) as conversions from AM_OnR_B2CFNO
where DayCat_any like 'Reactivation%'
group by month(minsaudadate)

use communication
--- Overlap with Akhilesh - Activation ------------
----select * from FNO_ConvertedClients where sauda_date>='2021-02-01' and sauda_date<='2021-02-28'
select top 10 * from AM_OnR_B2CFNO
Select month(minsaudatdate), count (distinct party_code) from FNO_ConvertedClients
where [type]='FNO (C)'
group by month(minsaudatdate)
order by month(minsaudatdate)
---select distinct FinalCampaignName from FNO_ConvertedClients
----Select distinct [type] from FNO_ConvertedClients

select month(minsaudadate), COUNT(distinct Party_code) from AM_OnR_B2CFNO 
where daycat_any like 'Activation%'
and party_code not in (select distinct party_code from FNO_ConvertedClients)
group by month(minsaudadate)
order by month(minsaudadate)

-----Overlap with Akhilesh - Reactivation---------
select month(minsaudadate), COUNT(distinct Party_code) from AM_OnR_B2CFNO 
where daycat_any like 'Reactivation%'
and party_code in (select distinct party_code from SN_CampaignClientsConverted_FY2021 where campaigntype like  'Re-Activation%')
group by month(minsaudadate)
order by month(minsaudadate)


Select * from FNO_ConvertedClients
select * from AM_OnR_B2CFNO



---------------------------------------------------------------------------------------
----STORING NON OVERLAP CLIENTS from activation, Reaction and In app reactivation Categories-----

Select * from AM_OnR_B2C
select * from AM_Inapp_Unique 

Select month(minsaudadate), count(distinct party_code) from AM_Inapp_Unique
group by month(minsaudadate)

  (select distinct profile_identity as party_code,category='Inapp' from AM_Inapp_React where 
   min_saudadate between '2021-01-01' and '2021-01-31')

drop table #ONR_B2C_Combined
Select party_code,minsaudadate, daycat_any into #ONR_B2C_Combined from
(Select distinct party_code, cast(minsaudadate as date) as minsaudadate,datcat_any as daycat_any from AM_OnR_B2C
union
Select distinct party_code, cast(minsaudadate as date) as minsaudadate, daycat_any 
from AM_Inapp_Unique where minsaudadate <'2021-01-01') a

select *,  ROW_NUMBER() Over (partition by party_code
order by minsaudadate asc) as Duplicate
into #uniqueConversions
from #ONR_B2C_Combined

Delete from #uniqueConversions where duplicate > 1

-----select * from #ONR_B2C_Combined
select * from #uniqueConversions order by minsaudadate

Select month(minsaudadate), count(distinct party_code) from #uniqueConversions
group by month(minsaudadate)

Create Table AM_ActReactInapp_unique
(party_code varchar(40), minsaudadate datetime, DayCat_any varchar(40), Duplicate int)

insert into AM_ActReactInapp_unique
select * from #uniqueConversions

------Select * from SN_CampaignClientsConverted_FY2021
select distinct party_code, minsaudadate, DayCat_any into #tempoverlap 
from AM_ActReactInapp_unique
where  party_code not in (Select distinct party_code from SN_CampaignClientsConverted_FY2021)

----select * from #tempoverlap
Select month(minsaudadate), count(distinct party_code) from #tempoverlap
group by month(minsaudadate)

Create Table AM_ActReactInapp_unique_Nonoverlap
(party_code varchar(40), minsaudadate datetime, DayCat_any varchar(40))

insert into AM_ActReactInapp_unique_Nonoverlap
select * from #tempoverlap

