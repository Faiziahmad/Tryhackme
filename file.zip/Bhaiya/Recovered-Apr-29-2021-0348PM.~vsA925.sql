select * into #obf from
(select distinct profile_identity, convert(date,left(ts,8),106) as clickdate,utm_campaign
from [onlineengine].[dbo].[CT_clicked] 
where utm_campaign in ('1617600079','1617167323','1618815183','1618210416','1619388974')
and convert(date,left(ts,8),106)>='2021-04-01' and convert(date,left(ts,8),106)<='2021-04-30') a

select top 10 * from [onlineengine].[dbo].[CT_clicked]

use OnlineEngine
select top 10 utm_campaign,campaign_type,profile_identity,profile_platform,utm_campaign,
convert(date,left(ts,8),106) as clickdate,b2c from 
[onlineengine].[dbo].[CT_clicked] a, [onlineengine].[dbo].[SN_ClientKYC] b
where a.profile_identity=b.party_code
and utm_campaign='1618575420'
and convert(date,left(ts,8),106)>='2021-04-16' and convert(date,left(ts,8),106)<='2021-04-30'


select utm_campaign,campaign_type,count(profile_identity) as count,
convert(date,left(ts,8),106) as clickdate,b2c from 
[onlineengine].[dbo].[CT_clicked] a, [onlineengine].[dbo].[SN_ClientKYC] b
where a.profile_identity=b.party_code
and utm_campaign='1618575420'
and convert(date,left(ts,8),106)>='2021-04-16' and convert(date,left(ts,8),106)<='2021-04-30'
group by utm_campaign,campaign_type,convert(date,left(ts,8),106),b2c

select sauda_date,dt,party_code,inst_type,oc,brokerage,b2c,event_id from  db_online_engine_rev.as_ordercountdata a left join  dbo_analytics_temp.sa_announcements b
on a.party_code=b.client_id
where sauda_date=dt and  dt>='2021-03-01' and party_code in (select client_id from dbo_analytics_temp.sa_announcements)
and event_id='19.20.2.1.0.0'
