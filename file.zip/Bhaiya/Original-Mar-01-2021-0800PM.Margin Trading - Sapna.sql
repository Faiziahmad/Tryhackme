--------------------MARGIN TRADE FUNDING by Sapna------------------------

select * From [onlineengine].[dbo].[VW_MTF_Plan_ClientInfo]

Select *
From [196.1.115.167].KYC.dbo.VW_Campaign_Consent_ALL with(nolock)
WHERE CampaignType IN ('MTFPLAN')

select distinct clientcode from [196.1.115.167].KYC.dbo.VW_Campaign_Consent_ALL with(nolock)
WHERE CampaignType like ('MTFPLAN') 
and pushedsource ='onr'


and cast(creationdate) >= '2020-12-01'
and cast(creationdate) <= '2020-12-31'

---------------------Conversions------
---select * from [onlineengine].[dbo].[VW_MTF_Plan_ClientInfo]

Select distinct ClientCode, PushedSource
From [196.1.115.167].KYC.dbo.VW_Campaign_Consent_ALL with(nolock)
Where Clientcode in 
(Select clientcode from [onlineengine].[dbo].[VW_MTF_Plan_ClientInfo] 
where ActivationDate>='2020-12-01' and ActivationDate<='2021-12-31'
--where ActivationDate>='2021-01-01' and ActivationDate<='2021-01-15'
) 
and Pushedsource = 'onr'and CampaignType = 'MTFPLAN'


-----Revenue------
with Revenue_OnR(Clientcode, PushedSource) as
(
Select ClientCode, PushedSource
From [196.1.115.167].KYC.dbo.VW_Campaign_Consent_ALL with(nolock)
Where Clientcode in (Select clientcode from [onlineengine].[dbo].[VW_MTF_Plan_ClientInfo]) and Pushedsource = 'onr'and CampaignType = 'MTFPLAN'
)
Select A.Clientcode, Pushedsource, B.VoucherPlanOpted
From Revenue_OnR as A inner join [onlineengine].[dbo].[VW_MTF_Plan_ClientInfo] as B
on A.ClientCode = B.ClientCode