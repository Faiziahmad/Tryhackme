--drop table #Activity_temp
--drop table #temp_with_gen_date
--drop table #temp_final



------- Get Party Code Details ------
select Party_Code, PartyCode_GenDate as Activity_time, CAST('OnBoarding' as varchar(40)) as Activity,
Cast('NULL' as varchar(40)) as Channel into #Activity_temp
from SN_ClientKYC
where B2C = 'Y' and cast(PartyCode_GenDate as date) >= '2020-12-01'
and cast(PartyCode_GenDate as date) <= '2020-12-31'

----- Get First Funding Details -----
insert into #Activity_temp
select ClientCode, min(RequestDateTime) , CAST('First_Funding' as varchar(40)),
Cast('NULL' as varchar(40)) as Channel 
from AJ_FundTransferSource
where [Status] = 'Success' and ClientCode in (select party_code from #Activity_temp)
group by ClientCode

----- Get First Sauda Details -----
insert into #Activity_temp
select party_code, min(cast(sauda_date as datetime) + cast(MinsaudaTime as datetime)), 
CAST('First_Sauda' as varchar(40)) ,
Cast('NULL' as varchar(40)) 
from SN_MinSaudaTime
where party_code in (select party_code from #Activity_temp)
group by party_code


----- Get Email & Push Click Details -----
insert into #Activity_temp
select profile_identity, convert(datetime,stuff(stuff(stuff(ts, 9, 0, ' '), 12, 0, ':'), 15, 0, ':')),
CAST(CONCAT((case when utm_campaign in (select CampaignID from CT_campaign where ActionID = 2) then  'Add_Fund_'
			      when utm_campaign in (select CampaignID from CT_campaign where ActionID = 3) then  'Buy_Stock_' 
				  when utm_campaign in (select CampaignID from CT_campaign where ActionID = 1) then  'App_Download_' end),utm_medium, '_Click') as varchar(40)),utm_medium
from CT_clicked
where profile_identity in (select party_code from #Activity_temp) 
and (utm_campaign in (select campaignid from CT_Campaign where ActionID in (1,2,3))
or utm_campaign in (select campaignid from [OnlineEngine].[dbo].[AD_OnB_other_Campaigns]))

---- Get OnR Clicks -----
insert into #Activity_temp
SELECT  profile_identity, convert(datetime,stuff(stuff(stuff(ts, 9, 0, ' '), 12, 0, ':'), 15, 0, ':')),
(case when Clicked_on like  'Add your 1st fund now%' then 'OnR_Add_Fund_Click'
     when Clicked_on like 'Place your 1st Trade Now%' then 'OnR_Trade_Click'
	 end ), Cast('OnR' as varchar(40)) 
  FROM [OnlineEngine].[dbo].[AJ_OffersCardClick_updated]
  where (Clicked_on like  'Add your 1st fund now%' or Clicked_on like 'Place your 1st Trade Now%')
  and (profile_identity is not null or profile_identity not in ('NULL')) and 
  (profile_identity in (select party_code from #Activity_temp))

----- get whatsapp clicks ------
insert into #Activity_temp
Select Party_code, URLClickDate, CAST(CONCAT(MsgIdentity, '_WA_Click') as varchar(40)),
Cast('WhatsApp' as varchar(40)) 
FROM [Communication].[dbo].[KP_WA_OB_Messages_Clicks_Logs]
where IsURLClicked='Y' and Party_code in (select party_code from #Activity_temp)
 --and MSGIdentity not like '%Download%'


----- join party code gen date -----
select A.Party_Code, B.PartyCode_GenDate, A.Activity, A.Activity_time, A.Channel into #temp_with_gen_date
from #Activity_temp A left join SN_ClientKYC B
on A.Party_Code = B.Party_Code


----- join trading day -----
select A.Party_Code, A.PartyCode_GenDate, A.Channel, A.Activity, A.Activity_time, B.Day0, B.Day1, B.Day2, B.Day3,
cast('NULL' as varchar(40)) as Funding_Category, cast('NULL' as varchar(40)) as Buy_Category
into #temp_final
from #temp_with_gen_date A left join AD_Trading_Day B
on cast(A.PartyCode_GenDate as Date) = b.OnBDate


---- update funding flag ------
update #temp_final
set Funding_Category = case when datediff(DAY, cast(PartyCode_GenDate as date), Activity_time) = 0 then 'Day0'
							when datediff(DAY, cast(PartyCode_GenDate as date), Activity_time) = 1 then 'Day1'
							when datediff(DAY, cast(PartyCode_GenDate as date), Activity_time) = 2 then 'Day2'
							when datediff(DAY, cast(PartyCode_GenDate as date), Activity_time) > 2 then 'Day2+'
							end
where Activity = 'First_Funding'


----- update trading flag ------
update #temp_final
set Buy_Category = case when cast(Activity_time as date) = Day0 then 'Day0'
						when cast(Activity_time as date) = Day1 then 'Day1'
						when cast(Activity_time as date) = Day2 then 'Day2'
						when cast(Activity_time as date) > Day2 then 'Day2+'
							end
where Activity = 'First_Sauda'




---- Buy Journey Conversion -----
select Last_Channel, COUNT(party_code) as Converted_User
from 
(select Party_Code, PartyCode_GenDate,Lag(Activity,1) over(partition by party_code order by Activity_time asc) as Last_Activity,
Lag(Activity_time,1) over(partition by party_code order by Activity_time asc) as Last_Activity_time,
Lag(Channel,1) over(partition by party_code order by Activity_time asc) as Last_Channel,
Activity, Activity_time, Funding_Category, Buy_Category
from #temp_final) A
where Activity = 'First_Sauda' and Last_Activity not in ('OnBoarding') 
and datediff(second, Last_Activity_time, Activity_time) <= 24*60*60 
group by   Last_Channel

select Channel, COUNT(distinct Party_Code) as Users
from #temp_final
where  Channel is not null and Channel != 'NULL'
group by Channel



 



