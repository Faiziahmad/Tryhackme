use onlineengine

INSERT INTO Profile360TG (PARTY_CODE,CREATEDON) VALUES ('S516409','2021-04-20 12:39:18.073')

delete from Profile360TG  where party_code='A196014'