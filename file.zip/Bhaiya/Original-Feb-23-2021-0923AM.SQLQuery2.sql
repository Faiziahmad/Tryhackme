use onlineengine
select * from AJ_Offers_Metadata where expiry_date>='2021-02-17'
--where expiry_date>='T'

select count(*) as count,created_by from aj_offers_metadata
group by created_by
order by count desc

use onlineengine

select top 10 * from aj_fundtransfersource

select distinct status from aj_fundtransfersource

select * from aj_offers_metadata