select convert(date,left(ts,8),106),utm_campaign,count(profile_identity) as count,
--convert(date,left(ts,8),106) as clickdate,
from
[onlineengine].[dbo].[CT_clicked] a
left join [onlineengine].[dbo].[SN_ClientKYC] b
on a.profile_identity=b.party_code
where utm_campaign in ('1617271661','1617247352','1617185453')
and convert(date,left(ts,8),106)>='2021-04-07' and convert(date,left(ts,8),106)<='2021-04-30'
group by utm_campaign,campaign_type,b2c,convert(date,left(ts,8),106)
order by utm_campaign


select top 10 * from [onlineengine].[dbo].[CT_clicked]
select top 10 * from [onlineengine].[dbo].[CT_campaign_map_daily] where [message id]='1617271661'

use onlineengine
select utm_campaign,count(profile_identity)as viewed,utm_medium
from [onlineengine].[dbo].[CT_clicked]
where utm_campaign in ('1617271661','1617247352','1617185453') 
and convert(date,left(ts,8),106)>='2021-03-01' and convert(date,left(ts,8),106)<='2021-04-30'
group by utm_campaign,utm_medium

select [message id],message_name,start_date,sent,viewed,clicked,errors
from [onlineengine].[dbo].[CT_campaign_map_daily]
where convert(date,(start_date),106)>='2021-03-01' and convert(date,(start_date),106)<='2021-04-30'
and [message_name]='Market Update' 
OR [message_name]='MarketUpdateConsole'
order by convert(date,(start_date),106)

order by convert(date,(start_date),106)

select top 10 convert(date,(start_date),106) from [onlineengine].[dbo].[CT_campaign_map_daily] 

select top 10 * from [onlineengine].[dbo].[CT_campaign_map_daily] 
, install

daily1

create table testing
values channel(varchar),messageid(numeric,5,2),message_name(varchar),start_date(timestamp),sent(numeric,5,0)

insert into testing

delete from testing
where messageid=221
and channel=push
and start_date==22131
and sent>10000


drop table #sgbcampaignseries2
select * into #sgbcampaignseries2 from
(select channel,[message id],message_name,start_date,sent,viewed,clicked,errors
from [onlineengine].[dbo].[CT_campaign_map_daily]
where convert(date,(start_date),106)>='2021-05-24' and convert(date,(start_date),106)<='2021-05-30'
and [message_name] like 'SGB_Series_II%') a
--and message_name not like '%Rejection%'
--and message_name like '%Sovereign%'
--order by convert(date,(start_date),106)) a

insert into #sgbcampaignseries2
select channel,[message id],message_name,start_date,sent,viewed,clicked,errors
from [onlineengine].[dbo].[CT_campaign_map_daily]
where convert(date,(start_date),106)>='2021-05-24' and convert(date,(start_date),106)<='2021-05-30'
and [message_name] like 'Sovereign%'

delete from #sgbcampaignseries2 where message_name like '%Rejection%'
delete from #sgbcampaignseries2 where sent=0

select * from #sgbcampaignseries2 order by start_date


select utm_campaign,campaign_type,profile_identity,profile_platform,convert(date,left(ts,8),106) as date from [onlineengine].[dbo].[CT_clicked] where utm_campaign in 
(select [message id] from #sgbcampaignseries2) 
and convert(date,left(ts,8),106)>='2021-05-24' and convert(date,left(ts,8),106)<='2021-05-28'


--and message_name like '%Sovereign%'
order by convert(date,(start_date),106)


select utm_campaign,count(profile_identity)as viewed,utm_medium
select distinct from [onlineengine].[dbo].[CT_clicked]
where utm_campaign in ('1621685675','1621931963') 
and convert(date,left(ts,8),106)>='2021-05-24' and convert(date,left(ts,8),106)<='2021-05-27'
group by utm_campaign,utm_medium

use onlineengine
select top 10 * from SB_clickstream

select action_id,action,section,tag,[order],flag from AJ_profile360_action where section=3



select utm_campaign,campaign_type,profile_identity,profile_platform,convert(date,left(ts,8),106) as date from [onlineengine].[dbo].[CT_click_hourly] where 
utm_campaign='1626152532'and convert(date,left(ts,8),106)>='2021-07-13'

select top 10 * from [onlineengine].[dbo].[CT_clicked] where utm_campaign='1626152532'

select top 10 convert(date,left(ts,8),106) as date from [onlineengine].[dbo].[CT_clicked] 
order by date desc


select distinct(client_code) from [onlineengine].[dbo].[CT_click_hourly] 
where utm_campaign='1626152532'
