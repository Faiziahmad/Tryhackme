SELECT count(*) from public.user_offer_map_archive;
SELECT * from public.user_offer_map_archive limit 100;



-----------Offer Client Count Query----------
select count(distinct client_code) from public.user_offer_map_archive 
where cast(expiry_date as date) >='2020-11-02'
and cast (activation_date as date)<= '2020-11-01'

---------
------------Offers that have gone live for the month view--------------
select distinct cast(activation_date as date), count(distinct client_code) from public.user_offer_map_archive 
where cast(activation_date as date) >= '2020-10-01'
group by cast(activation_date as date)


-----------------Offers Seen for yesterday--------------------
select count(distinct client_code) from public.user_offer_map_archive 
where cast(expiry_date as date) >= now() - interval '2 days'


-----------
----------------Daywise offers seen breakup--------------
Select count(AA.client_code) as users,
(case when AA.offer_count = 1 then '1 offer'
 when AA.offer_count = 2 then '2 offer'
 when AA.offer_count = 3 then '3 offer'
 when AA.offer_count = 4 then '4 offer'
 when AA.offer_count > 4 then 'More than 4 offer' END) as category
from											
(Select client_code,count(client_code) as offer_count from public.user_offer_map_archive 
where cast(expiry_date as date) >='2020-10-06'
and cast (activation_date as date)<= '2020-10-05'
group by client_code) AA
group by
(case when AA.offer_count = 1 then '1 offer'
 when AA.offer_count = 2 then '2 offer'
 when AA.offer_count = 3 then '3 offer'
 when AA.offer_count = 4 then '4 offer'
 when AA.offer_count > 4 then 'More than 4 offer' END)



--group by cast(expiry_date as date)



--------Active Clients with Angel------

select count(distinct party_code) from OnlineEngine.[dbo].[SN_ClientKYC] with(nolock)
where convert(date,ActiveFrom,105) <='2021-04-30'
and InactiveFrom > '2021-04-30'

select top 10 * from OnlineEngine.[dbo].[SN_ClientKYC] with(nolock)

------OnR Page Visits------
SELECT cast(clickdate as date),count(distinct client_code) 
	FROM public.offer_nav_click_log
	where cast(clickdate as date) >= '2021-01-01'
	group by cast(clickdate as date)

select dt,count(distinct(client_id)),event_id,event_name from 
dbo_clickstream_data.dp_clickstream_abma_android
where event_id in ('9.0.0.151.0.0')
and dt>= '2021-03-01'
and dt<= '2021-03-31'
group by 1,3,4
order by 1

-------Clicks per day on Onr-----
select top 10 * from [OnlineEngine].[dbo].[AJ_OffersCardClick_updated]

Select convert(date,left(ts,8),106) as Click_Date,count(distinct profile_identity) 
from [OnlineEngine].[dbo].[AJ_OffersCardClick_updated]
where  convert(date,left(ts,8),106) >='2021-04-01'
and convert(date,left(ts,8),106) <='2021-04-30'
group by convert(date,left(ts,8),106)

select * from [OnlineEngine].[dbo].[AJ_OffersCardClick_updated]
where convert(date,left(ts,8),106)= '2020-11-04'


Select * From [196.1.115.167].KYC.dbo.VW_Campaign_Consent_ALL with (nolock)
WHERE clientcode ='S516409'

Select convert(date,left(creationdate,8),106) as Click_Date,count(distinct clientcode),campaigntype 
from [196.1.115.167].KYC.dbo.VW_Campaign_Consent_ALL with (nolock)
where  convert(date,left(creationdate,8),106) >='2021-04-01'
and convert(date,left(creationdate,8),106) <='2021-04-30'
group by convert(date,left(creationdate,8),106),campaigntype
