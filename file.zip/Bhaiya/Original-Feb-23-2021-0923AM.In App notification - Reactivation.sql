---------------------------------------------------
-------------In app Notification tracking----------
USE Communication
select top 10 * from OnlineEngine.dbo.AS_OrderCountData
select top 10 * from [onlineengine].[dbo].[CT_clicked]
select * from [OnlineEngine].[dbo].[AJ_OffersCardClick_updated] order by ts desc


-------UTM Campaign Clicks-----
Campaign1 : 1605158966
select convert(date,left(ts,8),106) as clickdate, count (distinct profile_identity) as client_count,utm_campaign
from [onlineengine].[dbo].[CT_clicked] 
where utm_campaign in ('1613374400','1612164203','1613022928')
group by convert(date,left(ts,8),106),utm_campaign
order by convert(date,left(ts,8),106)

select top 10 * from [onlineengine].[dbo].[CT_clicked] where campaign_type='InApp'


---------- Daywise Data ------------
drop table #obf
select * into #obf from
(select distinct profile_identity, convert(date,left(ts,8),106) as clickdate
from [onlineengine].[dbo].[CT_clicked] 
where utm_campaign in ('1613374400','1612164203','1613022928')) a

and convert(date,left(ts,8),106)>='2021-02-01' and convert(date,left(ts,8),106)>='2021-02-15') a

use communication
select * from #obf

insert into AM_Inapp_React 
select distinct profile_identity,utmcampaign='1613374400',sauda_date,contype='Reactivation'
from #obf a, [onlineengine].[dbo].[as_ordercountdata] b
where a.profile_identity=b.party_code
--and Datediff(day,click_date,cast(requestdateTime as date)) between 0 and 1
and sauda_date >='2021-02-15'
and sauda_date <='2021-02-20'
and sauda_date is not NULL

---insert----
Insert into AM_Inapp_React (profile_identity,utm_campaign,min_saudadate,Contype)

--- select AM_Inapp_React  --- 

select * from AM_Inapp_React order by min_saudadate desc

use onlineengine
select top 5 * from as_ordercountdata


order by clickdate

--group by convert(date,left(ts,8),106)
--order by convert(date,left(ts,8),106)


------------------------------------------------------------------
--------Campaign Clicks mapped with OrderCount--------USE THIS !-----------
 

1610434610,1610962358

-----select * from #temp
-----select distinct profile_identity from #temp
----drop table #temp
-------select distinct profile_identity from #temp

--Create Table AM_Inapp_React (profile_identity varchar(10) ,utm_campaign varchar(22),min_saudadate datetime,Contype varchar(22))
Insert into AM_Inapp_React (profile_identity,utm_campaign,min_saudadate,Contype)
(select distinct * from #temp)

use Communication
select * from AM_Inapp_React order by min_saudaDate desc

---------------------REMOVE DUPLICATES-----------------
select *,  ROW_NUMBER() Over (partition by profile_identity
order by min_saudadate asc) as Duplicate
into #uniqueConversions
from AM_Inapp_React
---select * from #uniqueConversions
----drop table #uniqueConversions

Delete from #uniqueConversions where duplicate > 1

---------------------------------------------------------------------
select month(min_saudadate), count( distinct profile_identity) from #uniqueConversions
group by month(min_saudadate)

select distinct profile_identity from AM_Inapp_React where min_saudadate >= '2020-12-01'
select distinct utm_campaign from AM_Inapp_React


select *,  ROW_NUMBER() Over (partition by profile_identity,utm_campaign
order by Min_saudadate asc) as Duplicate
into #tempB
from AM_Inapp_React
----USE THIS WHILE UPDATING where min_saudadate > '2021-01-04'
----select * from #tempB
----drop table #tempB
delete from #tempB where Duplicate > 1
select * from #tempB


--------Campaign Clicks Mapped with Card Clicks-----
Select * into #temp2 from
(Select A.profile_identity, A.utm_campaign, A.ts, B.Clicked_on
from [onlineengine].[dbo].[CT_clicked] A, [OnlineEngine].[dbo].[AJ_OffersCardClick_updated] B
where A.profile_identity = B.profile_identity
and A.utm_campaign = '1613022928' 
and convert(date,left(A.ts,8),106) = convert(date,left(B.ts,8),106))xy

select distinct convert(date,left(ts,8),106) as cardclickdt,count(distinct profile_identity)
from #temp2 
group by convert(date,left(ts,8),106)
order by convert(date,left(ts,8),106)

-- select * from #temp2


-------Campaign Click vs Card Clicks vs Traded
select * into #cardclicktrade from
(Select A.profile_identity, A.utm_campaign, A.ts,A.Clicked_on, B.sauda_date, B.party_code, B.inst_type, B.OC, B.Brokerage
from #temp2 A, OnlineEngine.dbo.AS_OrderCountData B
where A.profile_identity =  B.party_code
and B.sauda_date >= convert(date,left(A.ts,8),106)) cct

select distinct convert(date,left(ts,8),106) as Conversiondt,count(distinct profile_identity) as ConversionCount
from  #cardclicktrade
group by convert(date,left(ts,8),106)
order by convert(date,left(ts,8),106)

select * from #cardclicktrade

Select * from [communication].[dbo].[RG_CampaignSet] 
where table_name ='SN_Targetset_Reactivation_30DaysInactive'
and is_offer = '1'
order by execution_date desc


--------------------------------------------
------In App Targeting---------------

Select * into #reactivationset from
(Select distinct party_code, ReactivationType='30 days' from SN_Targetset_Reactivation_30DaysInactive where profilechanged = '0'
union
Select distinct party_code, ReactivationType='60 days' from SN_Targetset_Reactivation_60DaysInactive where profilechanged = '0'
union
Select distinct party_code, ReactivationType='90 days' from SN_Targetset_Reactivation_90DaysInactive where profilechanged = '0'
union
Select distinct party_code, ReactivationType='180 days' from SN_Targetset_Reactivation_180DaysInactive where profilechanged = '0'
) abc

select * from [onlineengine].[dbo].[CT_clicked] where utm_campaign = '1605158966'

select * from #reactivationset

select distinct profile_identity  from [onlineengine].[dbo].[CT_clicked] where utm_campaign = '1605158966'

Select distinct Table_Name from [communication].[dbo].[RG_CampaignSet] where Owner_Name like 'suman%'

use OnlineEngine
select top 10 * from dbo.AJ_campign_Map where channel='InApp'

-----------------------Remove overlap with Suman and Akhilesh----------------
drop table #AM_OnR_B2C_React
drop table #AM_OnR_B2CFNO2_React
Select * into #AM_OnR_B2C_React from 
(select distinct minsaudadate, party_code from AM_OnR_B2C where datcat_any like 'Reactivation%') ab

Select * into #AM_OnR_B2CFNO2_React from 
(select distinct minsaudadate, party_code from AM_OnR_B2CFNO2 where daycat_any like 'Reactivation%') ab

Select * into #AM_Reactivation_All from 
(select distinct * from #AM_OnR_B2C_React 
union
select distinct * from #AM_OnR_B2CFNO2_React) a

-----Select * from #AM_Reactivation_All



select month(minsaudadate) as month_number, count(distinct party_code) as conversions from AM_OnR_B2C
where datcat_any like 'Reactivation%'
group by month(minsaudadate)




------------------------------------------------------------------------
-------------------30-60-90-180 breakup FOR IN APP CONVERSIONS--------------------------------


-----Select * from AM_Inapp_React
/*select month(min_saudadate), count(distinct profile_identity) from AM_Inapp_React
group by month(min_saudadate)
*/
drop table #inapp_unique
drop table #uniqueConversions

Select * into #inapp_unique from
(select * from AM_Inapp_React ) ab


Select * from #inapp_unique

select *,  ROW_NUMBER() Over (partition by profile_identity
order by min_saudadate asc) as Duplicate
into #uniqueConversions
from #inapp_unique

Delete from #uniqueConversions where duplicate > 1


select party_code, LAG(sauda_date, 1) over(partition by party_code order by Row_No asc) as Prev_Sauda, sauda_date into #Any_Trade
from
(select party_code,sauda_date , ROW_NUMBER() Over (partition by party_code order by sauda_date asc) as Row_No
from [OnlineEngine].[dbo].AS_OrderCountData
where party_code in (select distinct profile_identity from #uniqueConversions)) A

-------Select * from #Any_Trade order by party_code,sauda_date

----select * from #AM_Inapp_React
----select * from #uniqueConversions

alter table #uniqueConversions
add  Prev_Sauda_Any datetime, DayCat_any varchar(40)


update A
set Prev_Sauda_Any = B.Prev_Sauda
from #uniqueConversions A, #Any_Trade B
where A.profile_identity = B.Party_code and A.min_saudadate = B.sauda_date

update #uniqueConversions
set DayCat_any = case when DATEDIFF (day,prev_sauda_any,min_saudadate) between 0 and 60 then 'Reactivation 30-60days'
					  when DATEDIFF (day,prev_sauda_any,min_saudadate) between 61 and 90 then 'Reactivation 60-90days'
					  when DATEDIFF (day,prev_sauda_any,min_saudadate) between 91 and 180 then 'Reactivation 90-180days'
					  when DATEDIFF (day,prev_sauda_any,min_saudadate) > 180 then 'Reactivation >180days'
					  END

insert into AM_Inapp_Unique 
select * from #uniqueConversions

Create Table AM_Inapp_Unique
(party_code varchar(40),utm_campaign int, minsaudadate datetime,contype varchar(40),duplicate int,
prev_sauda_any datetime, DayCat_any varchar(40))

---drop table AM_Inapp_Unique

insert into AM_Inapp_Unique 
select * from #uniqueConversions

select * from AM_Inapp_Unique

select distinct daycat_any from AM_Inapp_Unique

select count(distinct party_code) from AM_Inapp_Unique where daycat_any like 'Reactivation 30-60days'
select count(distinct party_code) from AM_Inapp_Unique where daycat_any like 'Reactivation 60-90days'
select count(distinct party_code) from AM_Inapp_Unique where daycat_any like 'Reactivation 90-180days'
select count(distinct party_code) from AM_Inapp_Unique where daycat_any like 'Reactivation >180days'


use communication
select * from [Communication].[dbo].[RG_CampaignSet]