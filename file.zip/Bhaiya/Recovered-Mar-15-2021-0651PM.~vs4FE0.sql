
use onlineengine
select  * from Internationa_Investing_updated

drop table Internationa_Investing_updated


