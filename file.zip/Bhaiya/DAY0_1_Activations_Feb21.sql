--Drop Table #temp_KYC
Select * into #temp_KYC 
from
(Select party_code, activefrom, 
Client_Type = Case When Branch_cd in ('RFRL') then 'DRA' else 'B2C' End,
firsttrade, acqmonth = DateAdd(Day,1,EOMonth(activefrom,-1)) ,
Tradediff = cast(100 as int), 
TradingDay_R = cast(0 as int),
Source_Name = cast('NA' as varchar(100))
from SN_ClientKYC where B2C = 'y' and activefrom >= 'Apr 01 2018'
and activefrom < 'Mar 01 2021')AAA


Update A 
Set TradeDiff = DayofTrading
from #temp_KYC A,  DK_DaysoftradingfromDate B
where convert(date,Datelist,106) = convert(date,activefrom,106)
and convert(date,tradingday,106) = convert(date,firsttrade,106)

Update A 
Set TradingDay_R = 1 
from #temp_KYC A, OnlineEngine.dbo.SN_TradingDays B
Where convert(date,activefrom,106) = convert(date,TradingDay,106)

Update A
Set Source_Name = case when Campaign is null then Channel else Campaign end
from #temp_KYC A, OnlineEngine.dbo.SN_SalesSource_Intent B (nolock) 
where A.Party_Code = B.Party_code

Select ACqMonth, Source_Name, TradeDiff-TradingDay_R+1,
Count(distinct(Party_code)) clients
from #temp_KYC 
where 
TradeDiff-TradingDay_R+1 < 21
Group by ACqMonth, Source_Name, TradeDiff-TradingDay_R+1
order by ACqMonth desc, Source_Name, TradeDiff-TradingDay_R+1


Select ACqMonth, Source_Name, Count(distinct(Party_code)) clients
from #temp_KYC 
Group by ACqMonth, Source_Name
order by ACqMonth desc, Source_Name
