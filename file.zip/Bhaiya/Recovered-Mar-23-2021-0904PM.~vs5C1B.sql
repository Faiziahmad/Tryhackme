/****** Script for SelectTopNRows command from SSMS  ******/
SELECT TOP (1000) [action_id]
      ,[action]
      ,[name]
      ,[section]
      ,[display_text]
      ,[button_text]
      ,[redirection]
      ,[EF]
      ,[flag]
      ,[order]
  FROM [OnlineEngine].[dbo].[AJ_profile360_action]

update [OnlineEngine].[dbo].[AJ_profile360_action] set flag=0 where action_id in (2,4,18,19,20)