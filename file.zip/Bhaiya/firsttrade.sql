use onlineengine
--Drop Table #temp
Select * into #temp from 
(
Select convert(date,Firstsauda,106) Firstsauda, SCRIPNAME,inst_type, 
case when cast(Firstsauda as time)>= '00:00:00' and cast(Firstsauda as time)< '09:00:00' then '1.PreMarket-AMO'
when cast(Firstsauda as time)>= '09:00:00' and cast(Firstsauda as time)< '09:15:00' then '2.PMO'
when cast(Firstsauda as time)>= '09:15:00' and cast(Firstsauda as time)< '10:00:00' then '3.Mark_9_10'
when cast(Firstsauda as time)>= '10:00:00' and cast(Firstsauda as time)< '14:00:00' then '4.Mark_10_14'
when cast(Firstsauda as time)>= '14:00:00' and cast(Firstsauda as time)<= '15:30:00' then '5.Mark_14_end'
when cast(Firstsauda as time)> '15:30:00' and cast(Firstsauda as time)< '23:59:59.9999999' then '6.AfterMarketAMO' end as order_time,
case when [MARKETAMT] >= '1' and [MARKETAMT]<='100' then '1.within_100'
when [MARKETAMT] > '100' and [MARKETAMT]<='1000' then '2.101_1000'
when [MARKETAMT] > '1000' and [MARKETAMT]<='5000' then '3.1001_5000'
when [MARKETAMT] > '5000' and [MARKETAMT]<='10000' then '4.5001_10000'
when [MARKETAMT] > '10000' then '5.10000+' end as [MARKETAMT],
count(distinct Clientid) as users
from KD_Contract_analysis
where SCRIPNAME not in ('NA') 
--and [Activation] not in ('Not Activated','Day10+') 
--and [MARKETAMT] not in (null,'') 
group by Firstsauda, SCRIPNAME,inst_type, 
	case when cast(Firstsauda as time)>= '00:00:00' and cast(Firstsauda as time)< '09:00:00' then '1.PreMarket-AMO'
	when cast(Firstsauda as time)>= '09:00:00' and cast(Firstsauda as time)< '09:15:00' then '2.PMO'
	when cast(Firstsauda as time)>= '09:15:00' and cast(Firstsauda as time)< '10:00:00' then '3.Mark_9_10'
	when cast(Firstsauda as time)>= '10:00:00' and cast(Firstsauda as time)< '14:00:00' then '4.Mark_10_14'
	when cast(Firstsauda as time)>= '14:00:00' and cast(Firstsauda as time)<= '15:30:00' then '5.Mark_14_end'
	when cast(Firstsauda as time)> '15:30:00' and cast(Firstsauda as time)< '23:59:59.9999999' then '6.AfterMarketAMO' end,
	case when [MARKETAMT] >= '1' and [MARKETAMT]<='100' then '1.within_100'
	when [MARKETAMT] > '100' and [MARKETAMT]<='1000' then '2.101_1000'
	when [MARKETAMT] > '1000' and [MARKETAMT]<='5000' then '3.1001_5000'
	when [MARKETAMT] > '5000' and [MARKETAMT]<='10000' then '4.5001_10000'
	when [MARKETAMT] > '10000' then '5.10000+' end 
)AA
--select top 5 * from KD_Contract_analysis

Select convert(date,Firstsauda,106) Firstsauda, 
Scripname = case when inst_type = 'FOC' then substring(Scripname, 8,charindex(' ',substring(Scripname, 8,30))) else Scripname end , 
inst_type = case when inst_type = 'FOC' then left(scripname,6) else inst_type end , order_time, marketamt, sum(users) users
--DateAdd(Day,1,EOMonth(onbdate,-1)) as onbdate, sum(users) 
from #temp
where DateAdd(Day,1,EOMonth(Firstsauda,-1)) in ('2021-01-01', '2021-02-01')
--and inst_type = 'FOC'
group by convert(date,Firstsauda,106) , 
case when inst_type = 'FOC' then substring(Scripname, 8,charindex(' ',substring(Scripname, 8,30))) else Scripname end 
, case when inst_type = 'FOC' then left(scripname,6) else inst_type end, order_time, marketamt
--group by DateAdd(Day,1,EOMonth(onbdate,-1))
--order by DateAdd(Day,1,EOMonth(onbdate,-1))

Select DateAdd(Day,1,EOMonth(activefrom,-1)) as ACqMonth, 
count(distinct(party_code)) clients, 
sum(Case when Datediff(day,activefrom, firsttrade) < 15 then 1 else 0 end) tradeclients
from SN_ClientKYC with (nolock)
where b2c ='y'
and activefrom >= 'Jan 01 2021'
and activefrom < 'Jul 01 2021'
group by DateAdd(Day,1,EOMonth(activefrom,-1))
order by DateAdd(Day,1,EOMonth(activefrom,-1)) asc
