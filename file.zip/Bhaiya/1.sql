"insert into [dbo].[CT_Campaign](CampaignID, CampaignName, JourneyID, Channel, ActionID, CampaignIntent, StartDate, Comments, DayTag)
values ('15704','DAY 9 Email Reonboarding Buy Stock Journey','150','Email','3','Buy Order','44204','Part of journey 150','Day9'"
"insert into [dbo].[CT_Campaign](CampaignID, CampaignName, JourneyID, Channel, ActionID, CampaignIntent, StartDate, Comments, DayTag)
values ('15705','DAY 9 Push Reonboarding Buy Stock Journey','150','Push','3','Buy Order','44204','Part of journey 150','Day9'"
"insert into [dbo].[CT_Campaign](CampaignID, CampaignName, JourneyID, Channel, ActionID, CampaignIntent, StartDate, Comments, DayTag)
values ('15706','DAY 10 Email Reonboarding Buy Stock Journey','150','Email','3','Buy Order','44204','Part of journey 150','Day10'"
"insert into [dbo].[CT_Campaign](CampaignID, CampaignName, JourneyID, Channel, ActionID, CampaignIntent, StartDate, Comments, DayTag)
values ('15707','DAY 10 Push Reonboarding Buy Stock Journey','150','Push','3','Buy Order','44204','Part of journey 150','Day10'"
"insert into [dbo].[CT_Campaign](CampaignID, CampaignName, JourneyID, Channel, ActionID, CampaignIntent, StartDate, Comments, DayTag)
values ('15708','DAY 11 Email Reonboarding Buy Stock Journey','150','Email','3','Buy Order','44204','Part of journey 150','Day11'"
"insert into [dbo].[CT_Campaign](CampaignID, CampaignName, JourneyID, Channel, ActionID, CampaignIntent, StartDate, Comments, DayTag)
values ('15709','DAY 11 Push Reonboarding Buy Stock Journey','150','Push','3','Buy Order','44204','Part of journey 150','Day11'"
"insert into [dbo].[CT_Campaign](CampaignID, CampaignName, JourneyID, Channel, ActionID, CampaignIntent, StartDate, Comments, DayTag)
values ('15718','DAY 9 Email Reonboarding Add Fund Journey','151','Email','2','Add Fund','44204','Part of journey 151','Day9'"
"insert into [dbo].[CT_Campaign](CampaignID, CampaignName, JourneyID, Channel, ActionID, CampaignIntent, StartDate, Comments, DayTag)
values ('15719','DAY 9 Push Reonboarding Add Fund Journey','151','Push','2','Add Fund','44204','Part of journey 151','Day9'"
"insert into [dbo].[CT_Campaign](CampaignID, CampaignName, JourneyID, Channel, ActionID, CampaignIntent, StartDate, Comments, DayTag)
values ('15720','DAY 10 Email Reonboarding Add Fund Journey','151','Email','2','Add Fund','44204','Part of journey 151','Day10'"
"insert into [dbo].[CT_Campaign](CampaignID, CampaignName, JourneyID, Channel, ActionID, CampaignIntent, StartDate, Comments, DayTag)
values ('15721','DAY 10 Push Reonboarding Add Fund Journey','151','Push','2','Add Fund','44204','Part of journey 151','Day10'"
"insert into [dbo].[CT_Campaign](CampaignID, CampaignName, JourneyID, Channel, ActionID, CampaignIntent, StartDate, Comments, DayTag)
values ('15722','DAY 11 Email Reonboarding Add Fund Journey','151','Email','2','Add Fund','44204','Part of journey 151','Day11'"
"insert into [dbo].[CT_Campaign](CampaignID, CampaignName, JourneyID, Channel, ActionID, CampaignIntent, StartDate, Comments, DayTag)
values ('15723','DAY 11 Push Reonboarding Add Fund Journey','151','Push','2','Add Fund','44204','Part of journey 151','Day11'"
"insert into [dbo].[CT_Campaign](CampaignID, CampaignName, JourneyID, Channel, ActionID, CampaignIntent, StartDate, Comments, DayTag)
values ('7187','DAY 0 Email Add Fund Journey','191','Email','2','Add Fund','44204','AB Testing','Day0'"
"insert into [dbo].[CT_Campaign](CampaignID, CampaignName, JourneyID, Channel, ActionID, CampaignIntent, StartDate, Comments, DayTag)
values ('7188','DAY 0 Push Add Fund Journey','191','Push','2','Add Fund','44204','AB Testing','Day0'"
"insert into [dbo].[CT_Campaign](CampaignID, CampaignName, JourneyID, Channel, ActionID, CampaignIntent, StartDate, Comments, DayTag)
values ('7189','DAY 1 Email Add Fund Journey','191','Email','2','Add Fund','44204','AB Testing','Day1'"
"insert into [dbo].[CT_Campaign](CampaignID, CampaignName, JourneyID, Channel, ActionID, CampaignIntent, StartDate, Comments, DayTag)
values ('7190','DAY 1 Push Add Fund Journey','191','Push','2','Add Fund','44204','AB Testing','Day1'"
"insert into [dbo].[CT_Campaign](CampaignID, CampaignName, JourneyID, Channel, ActionID, CampaignIntent, StartDate, Comments, DayTag)
values ('7191','DAY 2 Email Add Fund Journey','191','Email','2','Add Fund','44204','AB Testing','Day2'"
"insert into [dbo].[CT_Campaign](CampaignID, CampaignName, JourneyID, Channel, ActionID, CampaignIntent, StartDate, Comments, DayTag)
values ('7192','DAY 2 Push Add Fund Journey','191','Push','2','Add Fund','44204','AB Testing','Day2'"
"insert into [dbo].[CT_Campaign](CampaignID, CampaignName, JourneyID, Channel, ActionID, CampaignIntent, StartDate, Comments, DayTag)
values ('7193','DAY 3 Push Add Fund Journey','191','Push','2','Add Fund','44204','AB Testing','Day3'"
"insert into [dbo].[CT_Campaign](CampaignID, CampaignName, JourneyID, Channel, ActionID, CampaignIntent, StartDate, Comments, DayTag)
values ('7194','DAY 4 Push Add Fund Journey','191','Push','2','Add Fund','44204','AB Testing','Day4'"
"insert into [dbo].[CT_Campaign](CampaignID, CampaignName, JourneyID, Channel, ActionID, CampaignIntent, StartDate, Comments, DayTag)
values ('7265','DAY 9 Email Reonboarding Buy Stock Journey','195','Email','3','Buy Order','44204','AB Testing','Day9'"
"insert into [dbo].[CT_Campaign](CampaignID, CampaignName, JourneyID, Channel, ActionID, CampaignIntent, StartDate, Comments, DayTag)
values ('7266','DAY 9 Push Reonboarding Buy Stock Journey','195','Push','3','Buy Order','44204','AB Testing','Day9'"
"insert into [dbo].[CT_Campaign](CampaignID, CampaignName, JourneyID, Channel, ActionID, CampaignIntent, StartDate, Comments, DayTag)
values ('7267','DAY 10 Email Reonboarding Buy Stock Journey','195','Email','3','Buy Order','44204','AB Testing','Day10'"
"insert into [dbo].[CT_Campaign](CampaignID, CampaignName, JourneyID, Channel, ActionID, CampaignIntent, StartDate, Comments, DayTag)
values ('7268','DAY 10 Push Reonboarding Buy Stock Journey','195','Push','3','Buy Order','44204','AB Testing','Day10'"
"insert into [dbo].[CT_Campaign](CampaignID, CampaignName, JourneyID, Channel, ActionID, CampaignIntent, StartDate, Comments, DayTag)
values ('7269','DAY 11 Email Reonboarding Buy Stock Journey','195','Email','3','Buy Order','44204','AB Testing','Day11'"
"insert into [dbo].[CT_Campaign](CampaignID, CampaignName, JourneyID, Channel, ActionID, CampaignIntent, StartDate, Comments, DayTag)
values ('7270','DAY 11 Push Reonboarding Buy Stock Journey','195','Push','3','Buy Order','44204','AB Testing','Day11'"