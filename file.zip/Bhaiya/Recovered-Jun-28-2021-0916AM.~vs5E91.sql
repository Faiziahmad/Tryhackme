Select * Into #AJ_OffersClick
From
(Select Distinct Clicked_on,profile_identity,ts,convert(date,left(ts,8),106) as Click_Date,
convert(datetime,stuff(stuff(stuff(ts, 9, 0, ' '), 12, 0, ':'), 15, 0, ':')) as Click_DateTime From [OnlineEngine].[dbo].[AJ_OffersCardClick_updated]
Where profile_identity is not NULL
--and Clicked_on like '%30 Days Brokerage%'
and clicked_on like '%prepaid%'
and convert(date,left(ts,8),106) >= '2021-06-01'
and convert(date,left(ts,8),106) <= '2021-06-20'
)a


select top 10 * from [172.31.12.226].[RevenueProduct].[dbo].[Tbl_ScratchCard_campaign_clicks]