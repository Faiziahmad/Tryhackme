use OnlineEngine
select top 1000 * from tbl_common_contract_data_Cash
select distinct segment from tbl_common_contract_data_Cash

-------B2C Scriptwise trades-----------
select top 10 * from tbl_common_contract_data_Cash 
Select top 10 * from tbl_common_contract_data_Comm

[dbo].[AJ_TB_action_type_master]
[dbo].[AJ_TB_analytics]
[dbo].[AJ_TB_content_collection]
[dbo].[AJ_TB_content_type_master]
[dbo].[AJ_TB_cs_advise_content]
[dbo].[AJ_TB_cs_content]
[dbo].[AJ_TB_cs_content_tag]
[dbo].[AJ_TB_cs_link]
[dbo].[AJ_TB_cs_tag]
[dbo].[AJ_TB_reported]
[dbo].[AJ_TB_token_map]
[dbo].[AJ_TB_uas_reply]
[dbo].[AJ_TB_us_user]
[dbo].[AJ_TB_user_action]
[dbo].[AJ_TB_user_action_count]
[dbo].[AJ_TB_user_follower]

Use OnlineEngine

Select top 1000 * from [dbo].[AJ_TB_analytics] order by created_date desc
Select * from [dbo].[AJ_TB_action_type_master]
Select * from [dbo].[AJ_TB_user_action]
Select * from [dbo].[AJ_TB_cs_advise_content]
Select * from [dbo].[AJ_TB_cs_content]
Select * from [dbo].[AJ_TB_content_type_master]

use OnlineEngine
drop table #adviseclicks
Select A.content_id,A.clicked_by,A.created_date as Clickdate, B.user_id, B.title,B.symbol,B.created_date, B.expiry_date,B.entry_date  
into #adviseclicks
from [dbo].[AJ_TB_analytics] A,[dbo].[AJ_TB_cs_advise_content] B
where A.content_id = B.content_id

select * from #adviseclicks

select top 10 * from [dbo].[AJ_TB_analytics]
select top 10 * from [dbo].[AJ_TB_cs_advise_content]


-----monthwise unique clients----------
select *,  ROW_NUMBER() Over (partition by clicked_by
order by clickdate asc) as Duplicate
into #uniqueClicks
from #adviseclicks

Delete from #uniqueClicks where duplicate > 1
---select * from #uniqueClicks

select * from tbl_common_contract_data_Cash_feb21 where party_code='S225700'

select * from AS_OrderCountData where party_code='S225700' and sauda_date between '2021-02-01' and '2021-02-28'

----direct map with contract data-----

SELECT TOP 10 * FROM tbl_common_contract_data_Cash_feb21

select distinct scripname from tbl_common_contract_data_Cash_feb21

select * from #adviseclicks A, tbl_common_contract_data_Cash_feb21 B with (nolock)
where A.clicked_by = B.PARTY_CODE
and replace(a.symbol,' ','')= replace(b.SCRIPNAME,' ','')
and cast(A.Clickdate as date)=cast(B.SAUDA_DATE as date)
and cast(A.Clickdate as date) >='2021-02-01'
and cast(A.Clickdate as date) <='2021-02-28'

---
select * from #adviseclicks A, as_ordercountdata B with (nolock)
where A.clicked_by = B.PARTY_CODE
and cast(A.Clickdate as date)=cast(B.SAUDA_DATE as date)
and cast(A.Clickdate as date) >='2021-02-01'
and cast(A.Clickdate as date) <='2021-02-28'


---select * from #adviseclicks
----select distinct sauda_date from tbl_common_contract_data_Cash order by SAUDA_DATE 
SELECT TOP 10 * FROM [196.1.115.132].EBroking.dbo.tbl_all_tradeFile_hist WITH (NOLOCK) order by sauda_date desc
----select distinct segment from tbl_common_contract_data_Cash
---select * from [Advisory].[dbo].[angelScrip]

---------Actual Trades----------
drop table #isin
select * into #ISIN from
(select distinct A.content_id,A.clicked_by,A.created_date as Clickdate, A.user_id, A.title,A.symbol,A.created_date, A.expiry_date,A.entry_date, B.Isin
from #adviseclicks A left join [Advisory].[dbo].[angelScrip] B
on A.symbol=B.NseScrip_Cd ) a


select * from #isin A, tbl_common_contract_data_Cash B with (nolock)
where A.clicked_by = B.PARTY_CODE
and A.isin= B.ISIN
and cast(A.Clickdate as date)=cast(B.SAUDA_DATE as date)
and cast(A.Clickdate as date) >='2021-01-01'
and cast(A.Clickdate as date) <='2021-01-31'

select top 10 * from [dbo].[angelScrip]


-------mapped with ALL_trade File ------
Select * into #temp from [196.1.115.132].EBroking.dbo.tbl_all_tradeFile_hist
where sauda_date between '2021-01-01' and '2021-03-03'
and party_code in 
(select distinct party_code from #adviseclicks)

select * from #adviseclicks A,#temp B WITH (NOLOCK)
where A.clicked_by = B.PARTY_CODE
and replace(a.symbol,' ','')= replace(b.symbol,' ','')
and cast(A.Clickdate as date)=cast(B.SAUDA_DATE as date)
and cast(A.Clickdate as date) >='2021-01-01'
and cast(A.Clickdate as date) <='2021-01-07'
and B.sauda_date between '2021-01-01' and '2021-01-07'

SELECT LTRIM('   techonthenet.com   ');

select top 10 party_code,sauda_date,symbol,col10,col24 from [196.1.115.132].EBroking.dbo.tbl_all_tradeFile_hist with (NOLOCK)
where sdate='01/03/2021' and 
ltrim(rtrim(party_code))='S517442'

select top 10 * from as_ordercountdata where sauda_date='2021-03-01' and party_code='S517442'

select top 10 * from [196.1.115.132].EBroking.dbo.tbl_all_tradeFile_hist with (NOLOCK) where sdate='01/03/2021'
USE OnlineEngine
use onlineengine
select top 100 * from AJ_OffersCardClick_updated where profile_identity='S516409'

select top 10 * from aj_fundtransfersource

REVENUE

SELECT TOP 10 * FROM DBO.AS_TradeData ORDER BY SAUDA_DATE desc