use communication

Use Communication
Create table NN_Targetset_NonMTFActiveClients(
           Party_code varchar(255), 
      	   TargetSet varchar(255),
	   Firsttrade date, 
	   Lasttrade date, 
	   SubTargetSet_1 varchar(255),
	   ProfileChanged int,
	   addedby varchar(255),
	   activefrom date,
	   inactivefrom date,
	   B2C varchar(50),
	   Scheme_Name varchar(255) 
)

drop table NN_Targetset_NonMTFActiveClients


select * From [OnlineEngine].[dbo].[AJ_Offers_Metadata]

select * From [OnlineEngine].[dbo].[RJ_CampaignSet]

use Communication