use communication
drop table #actdata
drop table #reactdata

select * into #actdata from 
	------B2C activation conversions------------
	(select distinct party_code,category='Activation' from OffersCard_Revenue_and_Conversion
    where minsaudadate >='2021-01-01'
	and minsaudadate <'2021-01-31'
	and Owner_Name like 'Suman%'
	and CampaignName not like 'Reactivation%') a


select * into #reactdata from 
	------B2C Reactivation conversions------------
	(select distinct party_code,category='ReActivation' from OffersCard_Revenue_and_Conversion
    where minsaudadate >='2021-01-01'
	and minsaudadate <'2021-01-31'
	and Owner_Name like 'Suman%'
	and CampaignName like 'Reactivation%') b

drop table #inappdata 
select * into #inappdata from 
  (select distinct profile_identity as party_code,category='Inapp' from AM_Inapp_React where 
   min_saudadate between '2021-01-01' and '2021-01-31') c

drop table #nonoverlaponrwithinonr 

select *,ROW_NUMBER() Over (partition by party_code
order by category asc) as identical into #nonoverlaponrwithinonr from 
(select party_code,category from #inappdata
union ALL 
select party_code,category from #reactdata
union ALL
select party_code,category from #actdata) d
delete from #nonoverlaponrwithinonr where identical>1

-------------- select * from #nonoverlaponrwithinonr --------------------

------- Non Overlap Data with Suman -----------
select * into #nonoverlapcount from 
(select party_code,category from #nonoverlaponrwithinonr 
where party_code not in (select distinct party_code from SN_CampaignClientsConverted_FY2021)) e

---- use communication select top 10 * from SN_CampaignClientsConverted_FY2021 -----
#nonoverlapcount ----

select * into #nonoverlapcount from 
(select a.party_code,category,brokerage from #nonoverlaponrwithinonr a
left join [onlineengine].[dbo].[as_ordercountdata] b
on a.party_code=b.party_code
where b.sauda_date between '2021-01-01' and '2021-01-31')

(select a.party_code,brokerage from AM_OnR_B2C a
left join [onlineengine].[dbo].[as_ordercountdata] b
on a.party_code=b.party_code
where b.sauda_date between '2021-01-01' and '2021-01-31'
and minsaudadate<=sauda_date)


where party_code not in (select distinct party_code from SN_CampaignClientsConverted_FY2021)) e


select top 10 * from [onlineengine].[dbo].[as_ordercountdata]

select top 10 * from SN_CampaignClientsConverted_FY2021

/*select * into #nonoverlapdetails from 
(select distinct party_code,sauda_date,minsaudadate,campaign,revenues,owner_name,campaignname,targetset,rowid 
from OffersCard_Revenue_and_Conversion where party_code in (select party_code from #nonoverlapcount)
and rowid='1' and minsaudadate >='2021-01-01'
	and minsaudadate <'2021-01-31')*/

--------------------------------------------------------------------------------------------------------------------
--- select top 10 * from OffersCard_Revenue_and_Conversion-----


--- Non-Overlap with Suman - Activation ------------
select month(minsaudadate), COUNT(distinct Party_code) from AM_OnR_B2C 
where datcat_any like 'Activation%'
and party_code  not in (select distinct party_code from SN_CampaignClientsConverted_FY2021 where campaigntype like 'First Activation%')
group by month(minsaudadate)
order by month(minsaudadate)

-----Overlap with Suman - Reactivation---------
select month(minsaudadate), COUNT(distinct Party_code) from AM_OnR_B2C 
where datcat_any like 'Reactivation%'	
and party_code not in (select distinct party_code from SN_CampaignClientsConverted_FY2021 where campaigntype like  'Re-Activation%')
group by month(minsaudadate)
order by month(minsaudadate)


select * from SN_CampaignClientsConverted_FY2021 where clickdate between '2021-01-01' and '2021-01-31'

select top 5 * from OffersCard_Revenue_and_Conversion


----- REVENUE --------
select ClientCode, Consentdate, sauda_date, datediff(day, ActiveFrom,consentdate)DaystoConsent, sum(brokerage)
from AM_OnR_Prepaid A,
onlineengine.dbo.AS_OrderCountData B,
onlineengine.dbo.SN_ClientKYC C
where A.Clientcode = b.Party_code
and  A.ClientCode = C.Party_Code
and sauda_date >= consentdate
group by ClientCode, Consentdate, sauda_date, datediff(day, ActiveFrom,consentdate)

SELECT TOP 10 * FROM AM_OnR_bUNDLED

select max(minsaudadate) from AM_ONR_B2CFNO

use communication
select top 10 * from OffersCard_Revenue_and_Conversion